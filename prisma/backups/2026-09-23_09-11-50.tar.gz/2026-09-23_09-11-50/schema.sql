


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";






CREATE EXTENSION IF NOT EXISTS "supabase_vault" WITH SCHEMA "vault";






CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";






CREATE OR REPLACE FUNCTION "public"."rls_auto_enable"() RETURNS "event_trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'pg_catalog'
    AS $$
DECLARE
  cmd record;
BEGIN
  FOR cmd IN
    SELECT *
    FROM pg_event_trigger_ddl_commands()
    WHERE command_tag IN ('CREATE TABLE', 'CREATE TABLE AS', 'SELECT INTO')
      AND object_type IN ('table','partitioned table')
  LOOP
     IF cmd.schema_name IS NOT NULL AND cmd.schema_name IN ('public') AND cmd.schema_name NOT IN ('pg_catalog','information_schema') AND cmd.schema_name NOT LIKE 'pg_toast%' AND cmd.schema_name NOT LIKE 'pg_temp%' THEN
      BEGIN
        EXECUTE format('alter table if exists %s enable row level security', cmd.object_identity);
        RAISE LOG 'rls_auto_enable: enabled RLS on %', cmd.object_identity;
      EXCEPTION
        WHEN OTHERS THEN
          RAISE LOG 'rls_auto_enable: failed to enable RLS on %', cmd.object_identity;
      END;
     ELSE
        RAISE LOG 'rls_auto_enable: skip % (either system schema or not in enforced list: %.)', cmd.object_identity, cmd.schema_name;
     END IF;
  END LOOP;
END;
$$;


ALTER FUNCTION "public"."rls_auto_enable"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."AvailabilityRules" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "DayOfWeek" integer NOT NULL,
    "StartTime" "text" NOT NULL,
    "EndTime" "text" NOT NULL
);


ALTER TABLE "public"."AvailabilityRules" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."AvailabilitySessionTypes" (
    "AvailabilityRuleId" "text" NOT NULL,
    "SessionTypeId" "text" NOT NULL,
    "TherapistId" "text" NOT NULL
);


ALTER TABLE "public"."AvailabilitySessionTypes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."BlockedDates" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "Date" "date" NOT NULL,
    "Reason" "text"
);


ALTER TABLE "public"."BlockedDates" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Bookings" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "StartTime" timestamp with time zone NOT NULL,
    "EndTime" timestamp with time zone NOT NULL,
    "Status" "text" NOT NULL,
    "StripePaymentId" "text",
    "CancelToken" "text",
    "CancellationReason" "text",
    "FeeInPence" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "ReminderSentAt" timestamp with time zone,
    "IsPaid" boolean DEFAULT false NOT NULL,
    "GoogleEventId" "text",
    "SessionTypeId" "text",
    "StripeInvoiceId" "text",
    "NonPaymentNoticeSentAt" timestamp with time zone,
    "VideoCallUrl" "text",
    "ClientId" "text" DEFAULT ''::"text" NOT NULL,
    "InvoiceSentAt" timestamp with time zone,
    "IsLateCancellation" boolean DEFAULT false NOT NULL,
    "IsRefunded" boolean DEFAULT false NOT NULL,
    "RefundedAmountInPence" integer,
    "InvoiceNumber" "text",
    "InvoicePaidAt" timestamp with time zone,
    "IsInvoiceVoided" boolean DEFAULT false NOT NULL,
    "InvoiceReminderSentAt" timestamp with time zone,
    "InvoiceDueDate" timestamp with time zone,
    "SessionNotes" "text",
    "BookedBy" "text",
    "ClinicalNotesCiphertext" "bytea",
    "ClinicalNotesUpdatedAt" timestamp with time zone,
    "ProcessNotesCiphertext" "bytea",
    "ProcessNotesUpdatedAt" timestamp with time zone,
    "ClinicalNotesFormat" character varying(10) DEFAULT 'text'::character varying NOT NULL,
    "ProcessNotesFormat" character varying(10) DEFAULT 'text'::character varying NOT NULL,
    CONSTRAINT "CK_Bookings_ClinicalNotesFormat" CHECK ((("ClinicalNotesFormat")::"text" = ANY ((ARRAY['text'::character varying, 'html'::character varying])::"text"[]))),
    CONSTRAINT "CK_Bookings_ProcessNotesFormat" CHECK ((("ProcessNotesFormat")::"text" = ANY ((ARRAY['text'::character varying, 'html'::character varying])::"text"[])))
);


ALTER TABLE "public"."Bookings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Breaks" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "Label" "text",
    "StartTime" timestamp with time zone NOT NULL,
    "EndTime" timestamp with time zone NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone
);


ALTER TABLE "public"."Breaks" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."CalendarPrefs" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "Calendar" "text" NOT NULL
);


ALTER TABLE "public"."CalendarPrefs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ClientIdentities" (
    "Id" "text" NOT NULL,
    "ClientId" "text" NOT NULL,
    "ClientIdentityTypeId" "text" DEFAULT '8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02'::"text" NOT NULL
);


ALTER TABLE "public"."ClientIdentities" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ClientIdentityTypes" (
    "Id" "text" NOT NULL,
    "Name" character varying(50) NOT NULL
);


ALTER TABLE "public"."ClientIdentityTypes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ClientUnsubscribes" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "ClientId" "text" NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE "public"."ClientUnsubscribes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Clients" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "Name" "text" NOT NULL,
    "Email" "text" NOT NULL,
    "Phone" "text",
    "Notes" "text",
    "GpName" "text",
    "GpPractice" "text",
    "GpPhone" "text",
    "EmergencyContactName" "text",
    "EmergencyContactPhone" "text",
    "EmergencyContactRelationship" "text",
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "NegotiatedFeeInPence" integer,
    "PreferredSessionTypeId" "text",
    "OtpCode" "text",
    "OtpExpiresAt" timestamp with time zone,
    "VideoLinksJson" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "DoNotEmail" boolean DEFAULT false NOT NULL,
    "PreviousSessions" integer DEFAULT 0 NOT NULL,
    "ClientIdentifier" character varying(50),
    "AgeYears" integer,
    "GenderTypeId" "text"
);


ALTER TABLE "public"."Clients" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."DeliveryTypes" (
    "Id" "text" NOT NULL,
    "Code" character varying(50) NOT NULL,
    "Label" character varying(50) NOT NULL,
    "SortOrder" integer NOT NULL,
    "AvailableForIntroCalls" boolean NOT NULL,
    "AvailableForSessions" boolean NOT NULL,
    "AvailableForSupervision" boolean NOT NULL,
    "RequiresLink" boolean NOT NULL,
    "IsActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."DeliveryTypes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Emails" (
    "Id" "text" NOT NULL,
    "Type" "text" NOT NULL,
    "Subject" "text" NOT NULL,
    "Body" "text" NOT NULL,
    "SentByTherapistId" "text",
    "RecipientCount" integer NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "BodyFormat" character varying(10) DEFAULT 'text'::character varying NOT NULL,
    CONSTRAINT "CK_Emails_BodyFormat" CHECK ((("BodyFormat")::"text" = ANY ((ARRAY['text'::character varying, 'html'::character varying])::"text"[])))
);


ALTER TABLE "public"."Emails" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Enquiries" (
    "Id" "text" NOT NULL,
    "ClientId" "text" NOT NULL,
    "Details" "text",
    "EnquiryOrigin" character varying(200),
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone
);


ALTER TABLE "public"."Enquiries" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Feedbacks" (
    "Id" "text" NOT NULL,
    "UserId" "text" NOT NULL,
    "Token" "text" NOT NULL,
    "Question1Answer" "text",
    "Question2Answer" "text",
    "Question3Answer" "text",
    "CompletedAt" timestamp with time zone,
    "CreatedAt" timestamp with time zone NOT NULL,
    "Comments" "text"
);


ALTER TABLE "public"."Feedbacks" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."GenderTypes" (
    "Id" "text" NOT NULL,
    "Code" character varying(50) NOT NULL,
    "Label" character varying(50) NOT NULL,
    "SortOrder" integer NOT NULL,
    "IsActive" boolean DEFAULT true NOT NULL
);


ALTER TABLE "public"."GenderTypes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."HelpAnswers" (
    "Id" "text" NOT NULL,
    "QuestionId" "text" NOT NULL,
    "Content" "text" NOT NULL,
    "SortOrder" integer NOT NULL
);


ALTER TABLE "public"."HelpAnswers" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."HelpQuestions" (
    "Id" "text" NOT NULL,
    "Section" "text" NOT NULL,
    "SectionOrder" integer NOT NULL,
    "Slug" "text" NOT NULL,
    "QuestionText" "text" NOT NULL,
    "SortOrder" integer NOT NULL
);


ALTER TABLE "public"."HelpQuestions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."IntroCallSettings" (
    "TherapistId" "text" NOT NULL,
    "SelfBookingEnabled" boolean NOT NULL,
    "Heading" character varying(120),
    "Description" character varying(1000),
    "DurationMins" integer NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "DefaultVideoUrl" character varying(2048),
    "DefaultDeliveryTypeId" "text"
);


ALTER TABLE "public"."IntroCallSettings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."IntroCalls" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "Name" "text" NOT NULL,
    "StartTime" timestamp with time zone NOT NULL,
    "EndTime" timestamp with time zone NOT NULL,
    "Outcome" "text",
    "Email" "text",
    "Phone" "text",
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "GoogleEventId" "text",
    "ReminderSentAt" timestamp with time zone,
    "VideoUrl" character varying(2048),
    "ClientId" "text",
    "DeliveryTypeId" "text"
);


ALTER TABLE "public"."IntroCalls" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Newsletters" (
    "Id" "text" NOT NULL,
    "FirstName" "text" NOT NULL,
    "Email" "text" NOT NULL,
    "ConsentGiven" boolean NOT NULL,
    "ConsentText" "text" NOT NULL,
    "ConfirmToken" "text" NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "EmailConsentGiven" boolean NOT NULL,
    "EmailConsentText" "text",
    "EmailConsentDateTime" timestamp with time zone
);


ALTER TABLE "public"."Newsletters" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."PlatformSettings" (
    "Id" integer NOT NULL,
    "UpgradeMode" "text" DEFAULT 'Stripe'::"text" NOT NULL,
    "UpgradeRequestEmail" "text",
    "ContactEmail" "text",
    "ContactName" "text",
    "ProTrialDays" integer DEFAULT 14 NOT NULL
);


ALTER TABLE "public"."PlatformSettings" OWNER TO "postgres";


ALTER TABLE "public"."PlatformSettings" ALTER COLUMN "Id" ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME "public"."PlatformSettings_Id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);



CREATE TABLE IF NOT EXISTS "public"."SessionTypeConfigs" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "Name" "text" NOT NULL,
    "Description" "text",
    "DurationMins" integer NOT NULL,
    "FeeInPence" integer NOT NULL,
    "SortOrder" integer NOT NULL,
    "IsActive" boolean NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "Color" "text" DEFAULT ''::"text" NOT NULL,
    "BufferMins" integer DEFAULT 0 NOT NULL,
    "EnableOnlineVideoLink" boolean DEFAULT false NOT NULL,
    "VideoLinkUrl" "text",
    "HideFromClients" boolean DEFAULT false NOT NULL,
    "BookingAvailability" "text" DEFAULT 'Any'::"text" NOT NULL,
    "DeliveryTypeId" "text"
);


ALTER TABLE "public"."SessionTypeConfigs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."SupervisionAdditionalNotes" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "SupervisionBookingId" "text" NOT NULL,
    "NotesCiphertext" "bytea",
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "NotesFormat" character varying(10) DEFAULT 'text'::character varying NOT NULL,
    CONSTRAINT "CK_SupervisionAdditionalNotes_NotesFormat" CHECK ((("NotesFormat")::"text" = ANY ((ARRAY['text'::character varying, 'html'::character varying])::"text"[])))
);


ALTER TABLE "public"."SupervisionAdditionalNotes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."SupervisionBookings" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "SupervisorName" "text" NOT NULL,
    "StartTime" timestamp with time zone NOT NULL,
    "EndTime" timestamp with time zone NOT NULL,
    "Notes" "text",
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "GoogleEventId" "text",
    "ReminderSentAt" timestamp with time zone,
    "Format" character varying(20) DEFAULT 'individual'::character varying NOT NULL,
    "NumberInGroup" integer,
    "SignedBySupervisorAt" timestamp with time zone,
    "DeliveryTypeId" "text",
    CONSTRAINT "CK_SupervisionBookings_Format" CHECK ((("Format")::"text" = ANY ((ARRAY['individual'::character varying, 'group'::character varying])::"text"[]))),
    CONSTRAINT "CK_SupervisionBookings_NumberInGroup" CHECK ((((("Format")::"text" = 'group'::"text") AND ("NumberInGroup" IS NOT NULL) AND ("NumberInGroup" >= 2)) OR ((("Format")::"text" = 'individual'::"text") AND ("NumberInGroup" IS NULL))))
);


ALTER TABLE "public"."SupervisionBookings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."SupervisionNotes" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "SupervisionBookingId" "text" NOT NULL,
    "ClientId" "text" NOT NULL,
    "NotesCiphertext" "bytea",
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "NotesFormat" character varying(10) DEFAULT 'text'::character varying NOT NULL,
    CONSTRAINT "CK_SupervisionNotes_NotesFormat" CHECK ((("NotesFormat")::"text" = ANY ((ARRAY['text'::character varying, 'html'::character varying])::"text"[])))
);


ALTER TABLE "public"."SupervisionNotes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."TermsAndConditions" (
    "Id" "text" NOT NULL,
    "Version" integer NOT NULL,
    "Url" "text" NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE "public"."TermsAndConditions" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."Therapists" (
    "Id" "text" NOT NULL,
    "AuthId" "text" NOT NULL,
    "Name" "text" NOT NULL,
    "Email" "text" NOT NULL,
    "Timezone" "text" NOT NULL,
    "FeeInPence" integer NOT NULL,
    "Bio" "text",
    "StripeAccountId" "text",
    "IsActive" boolean NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL,
    "UpdatedAt" timestamp with time zone,
    "MaxAdvanceUnit" "text",
    "MaxAdvanceValue" integer,
    "MinNoticeUnit" "text",
    "MinNoticeValue" integer,
    "CancellationPolicy" "text",
    "ReminderUnit" "text",
    "ReminderValue" integer,
    "RemindersEnabled" boolean DEFAULT false NOT NULL,
    "GoogleRefreshToken" "text",
    "OpeningClientHours" numeric DEFAULT 0.0 NOT NULL,
    "OpeningSupervisionHours" numeric DEFAULT 0.0 NOT NULL,
    "CancelNoticeUnit" "text",
    "CancelNoticeValue" integer,
    "FlagGapWeeks" integer,
    "ReviewAfterSessions" integer,
    "Role" "text" DEFAULT 'User'::"text" NOT NULL,
    "InvoiceDueBeforeSession" boolean DEFAULT false NOT NULL,
    "InvoiceDueDays" integer,
    "InvoiceMemo" "text",
    "InvoiceReminderDays" integer,
    "InvoiceReminderTiming" "text",
    "InvoicingEnabled" boolean DEFAULT false NOT NULL,
    "CancelUnpaidBookings" boolean DEFAULT false NOT NULL,
    "NonPaymentHours" integer,
    "NonPaymentPolicyEnabled" boolean DEFAULT false NOT NULL,
    "NonPaymentPolicyText" "text",
    "DefaultOnlineVideoLink" "text",
    "Slug" "text",
    "Qualifications" "text",
    "TermsAcceptedAt" timestamp with time zone,
    "HasProfessionalInsurance" boolean DEFAULT false NOT NULL,
    "MembershipBody" "text",
    "MembershipNumber" "text",
    "Modality" "text",
    "TermsAcceptedIp" "text",
    "TermsAcceptedVersion" integer,
    "WelcomeEmailSent" boolean DEFAULT false NOT NULL,
    "Plan" "text" DEFAULT 'Free'::"text" NOT NULL,
    "StripeCustomerId" "text",
    "StripeSubscriptionId" "text",
    "LogoUrl" "text",
    "PhotoUrl" "text",
    "IntroCallReminderUnit" "text",
    "IntroCallReminderValue" integer,
    "IntroCallRemindersEnabled" boolean DEFAULT false NOT NULL,
    "SupervisionReminderUnit" "text",
    "SupervisionReminderValue" integer,
    "SupervisionRemindersEnabled" boolean DEFAULT false NOT NULL,
    "VerificationSubmittedAt" timestamp with time zone,
    "VerifiedAt" timestamp with time zone,
    "ProTrialStartedAt" timestamp with time zone,
    "ProTrialEndsAt" timestamp with time zone,
    "ProTrialEndingEmailSentAt" timestamp with time zone,
    "ProTrialEndedEmailSentAt" timestamp with time zone,
    "SignupLandingPath" character varying(500),
    "SignupReferrer" character varying(500),
    "GridEndTime" "text" DEFAULT '23:00'::"text" NOT NULL,
    "GridStartTime" "text" DEFAULT '06:00'::"text" NOT NULL
);


ALTER TABLE "public"."Therapists" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."UserUnsubscribes" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE "public"."UserUnsubscribes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."WaitlistEntries" (
    "Id" "text" NOT NULL,
    "TherapistId" "text" NOT NULL,
    "ClientName" "text" NOT NULL,
    "ClientEmail" "text" NOT NULL,
    "PreferredDays" "jsonb" NOT NULL,
    "Notes" "text",
    "CreatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE "public"."WaitlistEntries" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."__EFMigrationsHistory" (
    "MigrationId" character varying(150) NOT NULL,
    "ProductVersion" character varying(32) NOT NULL
);


ALTER TABLE "public"."__EFMigrationsHistory" OWNER TO "postgres";


ALTER TABLE ONLY "public"."AvailabilityRules"
    ADD CONSTRAINT "AK_AvailabilityRules_Id_TherapistId" UNIQUE ("Id", "TherapistId");



ALTER TABLE ONLY "public"."Clients"
    ADD CONSTRAINT "AK_Clients_Id_TherapistId" UNIQUE ("Id", "TherapistId");



ALTER TABLE ONLY "public"."SessionTypeConfigs"
    ADD CONSTRAINT "AK_SessionTypeConfigs_Id_TherapistId" UNIQUE ("Id", "TherapistId");



ALTER TABLE ONLY "public"."SupervisionBookings"
    ADD CONSTRAINT "AK_SupervisionBookings_Id_TherapistId" UNIQUE ("Id", "TherapistId");



ALTER TABLE ONLY "public"."AvailabilityRules"
    ADD CONSTRAINT "PK_AvailabilityRules" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."AvailabilitySessionTypes"
    ADD CONSTRAINT "PK_AvailabilitySessionTypes" PRIMARY KEY ("AvailabilityRuleId", "SessionTypeId");



ALTER TABLE ONLY "public"."BlockedDates"
    ADD CONSTRAINT "PK_BlockedDates" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Bookings"
    ADD CONSTRAINT "PK_Bookings" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Breaks"
    ADD CONSTRAINT "PK_Breaks" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."CalendarPrefs"
    ADD CONSTRAINT "PK_CalendarPrefs" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."ClientIdentities"
    ADD CONSTRAINT "PK_ClientIdentities" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."ClientIdentityTypes"
    ADD CONSTRAINT "PK_ClientIdentityTypes" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."ClientUnsubscribes"
    ADD CONSTRAINT "PK_ClientUnsubscribes" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Clients"
    ADD CONSTRAINT "PK_Clients" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."DeliveryTypes"
    ADD CONSTRAINT "PK_DeliveryTypes" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Emails"
    ADD CONSTRAINT "PK_Emails" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Enquiries"
    ADD CONSTRAINT "PK_Enquiries" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Feedbacks"
    ADD CONSTRAINT "PK_Feedbacks" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."GenderTypes"
    ADD CONSTRAINT "PK_GenderTypes" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."HelpAnswers"
    ADD CONSTRAINT "PK_HelpAnswers" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."HelpQuestions"
    ADD CONSTRAINT "PK_HelpQuestions" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."IntroCallSettings"
    ADD CONSTRAINT "PK_IntroCallSettings" PRIMARY KEY ("TherapistId");



ALTER TABLE ONLY "public"."IntroCalls"
    ADD CONSTRAINT "PK_IntroCalls" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Newsletters"
    ADD CONSTRAINT "PK_Newsletters" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."PlatformSettings"
    ADD CONSTRAINT "PK_PlatformSettings" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."SessionTypeConfigs"
    ADD CONSTRAINT "PK_SessionTypeConfigs" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."SupervisionAdditionalNotes"
    ADD CONSTRAINT "PK_SupervisionAdditionalNotes" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."SupervisionBookings"
    ADD CONSTRAINT "PK_SupervisionBookings" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."SupervisionNotes"
    ADD CONSTRAINT "PK_SupervisionNotes" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."TermsAndConditions"
    ADD CONSTRAINT "PK_TermsAndConditions" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."Therapists"
    ADD CONSTRAINT "PK_Therapists" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."UserUnsubscribes"
    ADD CONSTRAINT "PK_UserUnsubscribes" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."WaitlistEntries"
    ADD CONSTRAINT "PK_WaitlistEntries" PRIMARY KEY ("Id");



ALTER TABLE ONLY "public"."__EFMigrationsHistory"
    ADD CONSTRAINT "PK___EFMigrationsHistory" PRIMARY KEY ("MigrationId");



CREATE INDEX "IX_AvailabilityRules_TherapistId" ON "public"."AvailabilityRules" USING "btree" ("TherapistId");



CREATE INDEX "IX_AvailabilitySessionTypes_AvailabilityRuleId_TherapistId" ON "public"."AvailabilitySessionTypes" USING "btree" ("AvailabilityRuleId", "TherapistId");



CREATE INDEX "IX_AvailabilitySessionTypes_SessionTypeId_TherapistId" ON "public"."AvailabilitySessionTypes" USING "btree" ("SessionTypeId", "TherapistId");



CREATE INDEX "IX_BlockedDates_TherapistId" ON "public"."BlockedDates" USING "btree" ("TherapistId");



CREATE UNIQUE INDEX "IX_Bookings_CancelToken" ON "public"."Bookings" USING "btree" ("CancelToken");



CREATE INDEX "IX_Bookings_ClientId_TherapistId" ON "public"."Bookings" USING "btree" ("ClientId", "TherapistId");



CREATE INDEX "IX_Bookings_SessionTypeId" ON "public"."Bookings" USING "btree" ("SessionTypeId");



CREATE INDEX "IX_Bookings_StripePaymentId" ON "public"."Bookings" USING "btree" ("StripePaymentId");



CREATE INDEX "IX_Bookings_TherapistId" ON "public"."Bookings" USING "btree" ("TherapistId");



CREATE INDEX "IX_Breaks_TherapistId" ON "public"."Breaks" USING "btree" ("TherapistId");



CREATE INDEX "IX_CalendarPrefs_TherapistId" ON "public"."CalendarPrefs" USING "btree" ("TherapistId");



CREATE UNIQUE INDEX "IX_ClientIdentities_ClientId_ClientIdentityTypeId" ON "public"."ClientIdentities" USING "btree" ("ClientId", "ClientIdentityTypeId");



CREATE INDEX "IX_ClientIdentities_ClientIdentityTypeId" ON "public"."ClientIdentities" USING "btree" ("ClientIdentityTypeId");



CREATE UNIQUE INDEX "IX_ClientIdentityTypes_Name" ON "public"."ClientIdentityTypes" USING "btree" ("Name");



CREATE INDEX "IX_Clients_GenderTypeId" ON "public"."Clients" USING "btree" ("GenderTypeId");



CREATE INDEX "IX_Clients_TherapistId" ON "public"."Clients" USING "btree" ("TherapistId");



CREATE UNIQUE INDEX "IX_DeliveryTypes_Code" ON "public"."DeliveryTypes" USING "btree" ("Code");



CREATE INDEX "IX_Enquiries_ClientId" ON "public"."Enquiries" USING "btree" ("ClientId");



CREATE UNIQUE INDEX "IX_Feedbacks_Token" ON "public"."Feedbacks" USING "btree" ("Token");



CREATE UNIQUE INDEX "IX_GenderTypes_Code" ON "public"."GenderTypes" USING "btree" ("Code");



CREATE INDEX "IX_HelpAnswers_QuestionId" ON "public"."HelpAnswers" USING "btree" ("QuestionId");



CREATE UNIQUE INDEX "IX_HelpQuestions_Slug" ON "public"."HelpQuestions" USING "btree" ("Slug");



CREATE INDEX "IX_IntroCallSettings_DefaultDeliveryTypeId" ON "public"."IntroCallSettings" USING "btree" ("DefaultDeliveryTypeId");



CREATE INDEX "IX_IntroCalls_ClientId" ON "public"."IntroCalls" USING "btree" ("ClientId");



CREATE INDEX "IX_IntroCalls_DeliveryTypeId" ON "public"."IntroCalls" USING "btree" ("DeliveryTypeId");



CREATE INDEX "IX_IntroCalls_TherapistId" ON "public"."IntroCalls" USING "btree" ("TherapistId");



CREATE UNIQUE INDEX "IX_Newsletters_ConfirmToken" ON "public"."Newsletters" USING "btree" ("ConfirmToken");



CREATE UNIQUE INDEX "IX_Newsletters_Email" ON "public"."Newsletters" USING "btree" ("Email");



CREATE INDEX "IX_SessionTypeConfigs_DeliveryTypeId" ON "public"."SessionTypeConfigs" USING "btree" ("DeliveryTypeId");



CREATE INDEX "IX_SessionTypeConfigs_TherapistId" ON "public"."SessionTypeConfigs" USING "btree" ("TherapistId");



CREATE UNIQUE INDEX "IX_SupervisionAdditionalNotes_SupervisionBookingId" ON "public"."SupervisionAdditionalNotes" USING "btree" ("SupervisionBookingId");



CREATE INDEX "IX_SupervisionAdditionalNotes_SupervisionBookingId_TherapistId" ON "public"."SupervisionAdditionalNotes" USING "btree" ("SupervisionBookingId", "TherapistId");



CREATE INDEX "IX_SupervisionAdditionalNotes_TherapistId" ON "public"."SupervisionAdditionalNotes" USING "btree" ("TherapistId");



CREATE INDEX "IX_SupervisionBookings_DeliveryTypeId" ON "public"."SupervisionBookings" USING "btree" ("DeliveryTypeId");



CREATE INDEX "IX_SupervisionBookings_TherapistId" ON "public"."SupervisionBookings" USING "btree" ("TherapistId");



CREATE INDEX "IX_SupervisionNotes_ClientId_TherapistId" ON "public"."SupervisionNotes" USING "btree" ("ClientId", "TherapistId");



CREATE UNIQUE INDEX "IX_SupervisionNotes_SupervisionBookingId_ClientId" ON "public"."SupervisionNotes" USING "btree" ("SupervisionBookingId", "ClientId");



CREATE INDEX "IX_SupervisionNotes_SupervisionBookingId_TherapistId" ON "public"."SupervisionNotes" USING "btree" ("SupervisionBookingId", "TherapistId");



CREATE INDEX "IX_SupervisionNotes_TherapistId" ON "public"."SupervisionNotes" USING "btree" ("TherapistId");



CREATE UNIQUE INDEX "IX_TermsAndConditions_Version" ON "public"."TermsAndConditions" USING "btree" ("Version");



CREATE UNIQUE INDEX "IX_Therapists_AuthId" ON "public"."Therapists" USING "btree" ("AuthId");



CREATE UNIQUE INDEX "IX_Therapists_Email" ON "public"."Therapists" USING "btree" ("Email");



CREATE UNIQUE INDEX "IX_Therapists_Slug" ON "public"."Therapists" USING "btree" ("Slug") WHERE ("Slug" IS NOT NULL);



ALTER TABLE ONLY "public"."AvailabilityRules"
    ADD CONSTRAINT "FK_AvailabilityRules_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."AvailabilitySessionTypes"
    ADD CONSTRAINT "FK_AvailabilitySessionTypes_AvailabilityRules_AvailabilityRule~" FOREIGN KEY ("AvailabilityRuleId", "TherapistId") REFERENCES "public"."AvailabilityRules"("Id", "TherapistId") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."AvailabilitySessionTypes"
    ADD CONSTRAINT "FK_AvailabilitySessionTypes_SessionTypeConfigs_SessionTypeId_T~" FOREIGN KEY ("SessionTypeId", "TherapistId") REFERENCES "public"."SessionTypeConfigs"("Id", "TherapistId") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."BlockedDates"
    ADD CONSTRAINT "FK_BlockedDates_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."Bookings"
    ADD CONSTRAINT "FK_Bookings_Clients_ClientId_TherapistId" FOREIGN KEY ("ClientId", "TherapistId") REFERENCES "public"."Clients"("Id", "TherapistId") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."Bookings"
    ADD CONSTRAINT "FK_Bookings_SessionTypeConfigs_Owner" FOREIGN KEY ("SessionTypeId", "TherapistId") REFERENCES "public"."SessionTypeConfigs"("Id", "TherapistId") ON DELETE SET NULL ("SessionTypeId");



ALTER TABLE ONLY "public"."Bookings"
    ADD CONSTRAINT "FK_Bookings_SessionTypeConfigs_SessionTypeId" FOREIGN KEY ("SessionTypeId") REFERENCES "public"."SessionTypeConfigs"("Id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."Bookings"
    ADD CONSTRAINT "FK_Bookings_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."Breaks"
    ADD CONSTRAINT "FK_Breaks_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."CalendarPrefs"
    ADD CONSTRAINT "FK_CalendarPrefs_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ClientIdentities"
    ADD CONSTRAINT "FK_ClientIdentities_ClientIdentityTypes_ClientIdentityTypeId" FOREIGN KEY ("ClientIdentityTypeId") REFERENCES "public"."ClientIdentityTypes"("Id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."ClientIdentities"
    ADD CONSTRAINT "FK_ClientIdentities_Clients_ClientId" FOREIGN KEY ("ClientId") REFERENCES "public"."Clients"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."Clients"
    ADD CONSTRAINT "FK_Clients_GenderTypes_GenderTypeId" FOREIGN KEY ("GenderTypeId") REFERENCES "public"."GenderTypes"("Id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."Clients"
    ADD CONSTRAINT "FK_Clients_SessionTypeConfigs_Preferred_Owner" FOREIGN KEY ("PreferredSessionTypeId", "TherapistId") REFERENCES "public"."SessionTypeConfigs"("Id", "TherapistId") ON DELETE SET NULL ("PreferredSessionTypeId");



ALTER TABLE ONLY "public"."Clients"
    ADD CONSTRAINT "FK_Clients_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."Enquiries"
    ADD CONSTRAINT "FK_Enquiries_Clients_ClientId" FOREIGN KEY ("ClientId") REFERENCES "public"."Clients"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."HelpAnswers"
    ADD CONSTRAINT "FK_HelpAnswers_HelpQuestions_QuestionId" FOREIGN KEY ("QuestionId") REFERENCES "public"."HelpQuestions"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."IntroCallSettings"
    ADD CONSTRAINT "FK_IntroCallSettings_DeliveryTypes_DefaultDeliveryTypeId" FOREIGN KEY ("DefaultDeliveryTypeId") REFERENCES "public"."DeliveryTypes"("Id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."IntroCallSettings"
    ADD CONSTRAINT "FK_IntroCallSettings_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."IntroCalls"
    ADD CONSTRAINT "FK_IntroCalls_Clients_ClientId" FOREIGN KEY ("ClientId") REFERENCES "public"."Clients"("Id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."IntroCalls"
    ADD CONSTRAINT "FK_IntroCalls_Clients_ClientId_Owner" FOREIGN KEY ("ClientId", "TherapistId") REFERENCES "public"."Clients"("Id", "TherapistId") ON DELETE SET NULL ("ClientId");



ALTER TABLE ONLY "public"."IntroCalls"
    ADD CONSTRAINT "FK_IntroCalls_DeliveryTypes_DeliveryTypeId" FOREIGN KEY ("DeliveryTypeId") REFERENCES "public"."DeliveryTypes"("Id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."IntroCalls"
    ADD CONSTRAINT "FK_IntroCalls_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."SessionTypeConfigs"
    ADD CONSTRAINT "FK_SessionTypeConfigs_DeliveryTypes_DeliveryTypeId" FOREIGN KEY ("DeliveryTypeId") REFERENCES "public"."DeliveryTypes"("Id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."SessionTypeConfigs"
    ADD CONSTRAINT "FK_SessionTypeConfigs_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."SupervisionAdditionalNotes"
    ADD CONSTRAINT "FK_SupervisionAdditionalNotes_SupervisionBookings_SupervisionB~" FOREIGN KEY ("SupervisionBookingId", "TherapistId") REFERENCES "public"."SupervisionBookings"("Id", "TherapistId") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."SupervisionAdditionalNotes"
    ADD CONSTRAINT "FK_SupervisionAdditionalNotes_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."SupervisionBookings"
    ADD CONSTRAINT "FK_SupervisionBookings_DeliveryTypes_DeliveryTypeId" FOREIGN KEY ("DeliveryTypeId") REFERENCES "public"."DeliveryTypes"("Id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."SupervisionBookings"
    ADD CONSTRAINT "FK_SupervisionBookings_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."SupervisionNotes"
    ADD CONSTRAINT "FK_SupervisionNotes_Clients_ClientId_TherapistId" FOREIGN KEY ("ClientId", "TherapistId") REFERENCES "public"."Clients"("Id", "TherapistId") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."SupervisionNotes"
    ADD CONSTRAINT "FK_SupervisionNotes_SupervisionBookings_SupervisionBookingId_T~" FOREIGN KEY ("SupervisionBookingId", "TherapistId") REFERENCES "public"."SupervisionBookings"("Id", "TherapistId") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."SupervisionNotes"
    ADD CONSTRAINT "FK_SupervisionNotes_Therapists_TherapistId" FOREIGN KEY ("TherapistId") REFERENCES "public"."Therapists"("Id") ON DELETE CASCADE;



ALTER TABLE "public"."AvailabilityRules" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."AvailabilitySessionTypes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."BlockedDates" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Bookings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Breaks" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."CalendarPrefs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ClientIdentities" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ClientIdentityTypes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."ClientUnsubscribes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Clients" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."DeliveryTypes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Emails" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Enquiries" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Feedbacks" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."GenderTypes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."HelpAnswers" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."HelpQuestions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."IntroCallSettings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."IntroCalls" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Newsletters" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."PlatformSettings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."SessionTypeConfigs" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."SupervisionAdditionalNotes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."SupervisionBookings" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."SupervisionNotes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."TermsAndConditions" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."Therapists" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."UserUnsubscribes" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."WaitlistEntries" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."__EFMigrationsHistory" ENABLE ROW LEVEL SECURITY;




ALTER PUBLICATION "supabase_realtime" OWNER TO "postgres";


GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";






















































































































































GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "anon";
GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."rls_auto_enable"() TO "service_role";


















GRANT ALL ON TABLE "public"."AvailabilityRules" TO "anon";
GRANT ALL ON TABLE "public"."AvailabilityRules" TO "authenticated";
GRANT ALL ON TABLE "public"."AvailabilityRules" TO "service_role";



GRANT ALL ON TABLE "public"."AvailabilitySessionTypes" TO "anon";
GRANT ALL ON TABLE "public"."AvailabilitySessionTypes" TO "authenticated";
GRANT ALL ON TABLE "public"."AvailabilitySessionTypes" TO "service_role";



GRANT ALL ON TABLE "public"."BlockedDates" TO "anon";
GRANT ALL ON TABLE "public"."BlockedDates" TO "authenticated";
GRANT ALL ON TABLE "public"."BlockedDates" TO "service_role";



GRANT ALL ON TABLE "public"."Bookings" TO "anon";
GRANT ALL ON TABLE "public"."Bookings" TO "authenticated";
GRANT ALL ON TABLE "public"."Bookings" TO "service_role";



GRANT ALL ON TABLE "public"."Breaks" TO "anon";
GRANT ALL ON TABLE "public"."Breaks" TO "authenticated";
GRANT ALL ON TABLE "public"."Breaks" TO "service_role";



GRANT ALL ON TABLE "public"."CalendarPrefs" TO "anon";
GRANT ALL ON TABLE "public"."CalendarPrefs" TO "authenticated";
GRANT ALL ON TABLE "public"."CalendarPrefs" TO "service_role";



GRANT ALL ON TABLE "public"."ClientIdentities" TO "anon";
GRANT ALL ON TABLE "public"."ClientIdentities" TO "authenticated";
GRANT ALL ON TABLE "public"."ClientIdentities" TO "service_role";



GRANT ALL ON TABLE "public"."ClientIdentityTypes" TO "anon";
GRANT ALL ON TABLE "public"."ClientIdentityTypes" TO "authenticated";
GRANT ALL ON TABLE "public"."ClientIdentityTypes" TO "service_role";



GRANT ALL ON TABLE "public"."ClientUnsubscribes" TO "anon";
GRANT ALL ON TABLE "public"."ClientUnsubscribes" TO "authenticated";
GRANT ALL ON TABLE "public"."ClientUnsubscribes" TO "service_role";



GRANT ALL ON TABLE "public"."Clients" TO "anon";
GRANT ALL ON TABLE "public"."Clients" TO "authenticated";
GRANT ALL ON TABLE "public"."Clients" TO "service_role";



GRANT ALL ON TABLE "public"."DeliveryTypes" TO "anon";
GRANT ALL ON TABLE "public"."DeliveryTypes" TO "authenticated";
GRANT ALL ON TABLE "public"."DeliveryTypes" TO "service_role";



GRANT ALL ON TABLE "public"."Emails" TO "anon";
GRANT ALL ON TABLE "public"."Emails" TO "authenticated";
GRANT ALL ON TABLE "public"."Emails" TO "service_role";



GRANT ALL ON TABLE "public"."Enquiries" TO "anon";
GRANT ALL ON TABLE "public"."Enquiries" TO "authenticated";
GRANT ALL ON TABLE "public"."Enquiries" TO "service_role";



GRANT ALL ON TABLE "public"."Feedbacks" TO "anon";
GRANT ALL ON TABLE "public"."Feedbacks" TO "authenticated";
GRANT ALL ON TABLE "public"."Feedbacks" TO "service_role";



GRANT ALL ON TABLE "public"."GenderTypes" TO "anon";
GRANT ALL ON TABLE "public"."GenderTypes" TO "authenticated";
GRANT ALL ON TABLE "public"."GenderTypes" TO "service_role";



GRANT ALL ON TABLE "public"."HelpAnswers" TO "anon";
GRANT ALL ON TABLE "public"."HelpAnswers" TO "authenticated";
GRANT ALL ON TABLE "public"."HelpAnswers" TO "service_role";



GRANT ALL ON TABLE "public"."HelpQuestions" TO "anon";
GRANT ALL ON TABLE "public"."HelpQuestions" TO "authenticated";
GRANT ALL ON TABLE "public"."HelpQuestions" TO "service_role";



GRANT ALL ON TABLE "public"."IntroCallSettings" TO "anon";
GRANT ALL ON TABLE "public"."IntroCallSettings" TO "authenticated";
GRANT ALL ON TABLE "public"."IntroCallSettings" TO "service_role";



GRANT ALL ON TABLE "public"."IntroCalls" TO "anon";
GRANT ALL ON TABLE "public"."IntroCalls" TO "authenticated";
GRANT ALL ON TABLE "public"."IntroCalls" TO "service_role";



GRANT ALL ON TABLE "public"."Newsletters" TO "anon";
GRANT ALL ON TABLE "public"."Newsletters" TO "authenticated";
GRANT ALL ON TABLE "public"."Newsletters" TO "service_role";



GRANT ALL ON TABLE "public"."PlatformSettings" TO "anon";
GRANT ALL ON TABLE "public"."PlatformSettings" TO "authenticated";
GRANT ALL ON TABLE "public"."PlatformSettings" TO "service_role";



GRANT ALL ON SEQUENCE "public"."PlatformSettings_Id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."PlatformSettings_Id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."PlatformSettings_Id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."SessionTypeConfigs" TO "anon";
GRANT ALL ON TABLE "public"."SessionTypeConfigs" TO "authenticated";
GRANT ALL ON TABLE "public"."SessionTypeConfigs" TO "service_role";



GRANT ALL ON TABLE "public"."SupervisionAdditionalNotes" TO "anon";
GRANT ALL ON TABLE "public"."SupervisionAdditionalNotes" TO "authenticated";
GRANT ALL ON TABLE "public"."SupervisionAdditionalNotes" TO "service_role";



GRANT ALL ON TABLE "public"."SupervisionBookings" TO "anon";
GRANT ALL ON TABLE "public"."SupervisionBookings" TO "authenticated";
GRANT ALL ON TABLE "public"."SupervisionBookings" TO "service_role";



GRANT ALL ON TABLE "public"."SupervisionNotes" TO "anon";
GRANT ALL ON TABLE "public"."SupervisionNotes" TO "authenticated";
GRANT ALL ON TABLE "public"."SupervisionNotes" TO "service_role";



GRANT ALL ON TABLE "public"."TermsAndConditions" TO "anon";
GRANT ALL ON TABLE "public"."TermsAndConditions" TO "authenticated";
GRANT ALL ON TABLE "public"."TermsAndConditions" TO "service_role";



GRANT ALL ON TABLE "public"."Therapists" TO "anon";
GRANT ALL ON TABLE "public"."Therapists" TO "authenticated";
GRANT ALL ON TABLE "public"."Therapists" TO "service_role";



GRANT ALL ON TABLE "public"."UserUnsubscribes" TO "anon";
GRANT ALL ON TABLE "public"."UserUnsubscribes" TO "authenticated";
GRANT ALL ON TABLE "public"."UserUnsubscribes" TO "service_role";



GRANT ALL ON TABLE "public"."WaitlistEntries" TO "anon";
GRANT ALL ON TABLE "public"."WaitlistEntries" TO "authenticated";
GRANT ALL ON TABLE "public"."WaitlistEntries" TO "service_role";



GRANT ALL ON TABLE "public"."__EFMigrationsHistory" TO "anon";
GRANT ALL ON TABLE "public"."__EFMigrationsHistory" TO "authenticated";
GRANT ALL ON TABLE "public"."__EFMigrationsHistory" TO "service_role";









ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";



































