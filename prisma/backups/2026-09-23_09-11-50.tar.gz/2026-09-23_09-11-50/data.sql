SET session_replication_role = replica;

--
-- PostgreSQL database dump
--

-- \restrict 41v7YjZQZQZKoQqYkoRv4hgdpn0LxJfTp0vJwQAa6ckJ9rTlI3QwcLCyxqlg6zh

-- Dumped from database version 17.6
-- Dumped by pg_dump version 17.6

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: audit_log_entries; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."audit_log_entries" ("instance_id", "id", "payload", "created_at", "ip_address") FROM stdin;
\.


--
-- Data for Name: custom_oauth_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."custom_oauth_providers" ("id", "provider_type", "identifier", "name", "client_id", "client_secret", "acceptable_client_ids", "scopes", "pkce_enabled", "attribute_mapping", "authorization_params", "enabled", "email_optional", "issuer", "discovery_url", "skip_nonce_check", "cached_discovery", "discovery_cached_at", "authorization_url", "token_url", "userinfo_url", "jwks_uri", "created_at", "updated_at", "custom_claims_allowlist") FROM stdin;
\.


--
-- Data for Name: flow_state; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."flow_state" ("id", "user_id", "auth_code", "code_challenge_method", "code_challenge", "provider_type", "provider_access_token", "provider_refresh_token", "created_at", "updated_at", "authentication_method", "auth_code_issued_at", "invite_token", "referrer", "oauth_client_state_id", "linking_target_id", "email_optional") FROM stdin;
54f4640e-cb56-4128-afe0-ef5b5c126a41	468cade7-1d68-497e-9aa0-57e79722996e	18887d40-11f1-4e91-af52-fdf62f664aaa	s256	fs0wPBYW52yGPtG8uFLmOemIGpjtYi2bJ998ioTUrSA	email			2026-05-12 20:41:27.910552+00	2026-05-12 20:42:23.665805+00	email/signup	2026-05-12 20:42:23.665756+00	\N	\N	\N	\N	f
764f612b-13eb-4cf0-9b7c-c77fbaf250d3	86958bf5-8429-4f3c-a52e-c3fe6105345c	a11e926a-f71c-457b-83a4-dd40e55d613c	s256	v7FMGrv1BQWgbuRd0SiUgobVu8Xt8c2Vyq64eIOPngk	email			2026-05-13 16:12:54.156666+00	2026-05-13 16:13:08.465869+00	email/signup	2026-05-13 16:13:08.465821+00	\N	\N	\N	\N	f
8b07c355-aa22-4291-bcc4-ad9e83bc8665	6d8f5903-d12b-4975-92cf-d369b8d18dcb	1a643965-2d7c-40ef-ac62-4641f66112de	s256	B6G8mWMFGNCo6MqclXGh6LfNdxZj5EDuQZ1aLFLY1Ho	email			2026-05-13 16:47:03.054041+00	2026-05-13 16:47:28.911277+00	email/signup	2026-05-13 16:47:28.911227+00	\N	\N	\N	\N	f
2cdfba07-2b02-4956-b9ae-205c836b3378	1b0f8fb3-2aab-4d82-8d0f-06a5a4fdc2cd	a168d6d1-ee63-4ed9-a206-b0c380b09514	s256	W2lgfRnLVA5uMzoXBHIZMDNHJF0U3KKEINqQn20M9Ok	email			2026-05-21 16:29:01.765776+00	2026-05-21 16:39:20.373529+00	email/signup	2026-05-21 16:39:20.373481+00	\N	\N	\N	\N	f
8b203339-33c0-486e-bc12-5ac15aed1563	b9130b01-332f-485f-8386-1c784f8bebd1	99d5a3ca-307c-41e5-8ee0-e480cc42aa18	s256	Obn_FAB8aKCn2cbv91SukAUe-TmMI9-GdHaR9EqE2Ec	email			2026-05-21 16:50:21.957702+00	2026-05-21 16:50:46.376016+00	email/signup	2026-05-21 16:50:46.375945+00	\N	\N	\N	\N	f
a919bdeb-eabf-4374-9a75-271d526cb880	a401eb22-b920-42b0-86ab-b447f7bf0ac4	34a7f984-6904-4ea8-a9c2-0bdae0d23a79	s256	Fi1qXPSYtnr4d5M_CiQc0iTJtroIXSxSRhuilfacmG4	email			2026-05-21 16:53:22.313821+00	2026-05-21 16:53:35.099672+00	email/signup	2026-05-21 16:53:35.099622+00	\N	\N	\N	\N	f
7d5a4dbb-4d25-4102-9677-52f43840fc50	e2fda882-2762-47dd-818d-27074389ae2c	9a64a072-8d7f-437d-9531-af4a5e839c3c	s256	_vpjTO4v_NW8LqQ8TTFI1oKBMLDXOC_pTiOsuJ22iUY	email			2026-05-21 17:05:04.088151+00	2026-05-21 17:05:04.088151+00	email/signup	\N	\N	\N	\N	\N	f
d78208a8-5c92-453d-91ee-5451d2cde944	94526dac-d78a-431a-b7d6-5f57ac229b28	5b5b11ef-0b5e-4522-9113-02b1a790311f	s256	qjvXjHHxm7b8YpzTVrxt2bidcLSIIa6fMIr15R2CaI8	email			2026-05-21 20:09:11.966427+00	2026-05-21 20:09:11.966427+00	email/signup	\N	\N	\N	\N	\N	f
784bacf1-d984-4f87-9e3f-7abab19ce01e	ade2d668-8166-4482-87a2-bd308d2c7153	cf87a4f9-06ab-4cbd-a3b2-e5d38fce2c78	s256	zI0siDazE_q-KaO9OfQWR2um0oAWzmJZm_QjIglo2LM	email			2026-05-21 20:27:20.98914+00	2026-05-21 20:27:20.98914+00	email/signup	\N	\N	\N	\N	\N	f
07fe1d31-a291-4ad3-90dd-cedfb4c0e876	20408f82-f38d-4784-b8db-1dbe0aa3a992	ea156e50-a84a-4569-ac62-18c5db818c75	s256	7RUpM_8NmVYizLvD-S0RmOLJUbvKyUuk6gcaVKHKeDQ	email			2026-05-21 20:42:59.060461+00	2026-05-21 20:42:59.060461+00	email/signup	\N	\N	\N	\N	\N	f
1fae08c2-c0f2-4f5c-92fb-e7df863237cf	80c210e1-5f90-494c-a13f-05277033dde5	2f9bc437-ba60-4528-b673-36649aa2f605	s256	xAK5_B06HL7ljmVtM2Y0D-Sj75xzM9UUrWfAknG_ojE	email			2026-05-22 07:28:32.223501+00	2026-05-22 07:28:32.223501+00	email/signup	\N	\N	\N	\N	\N	f
d1130725-2cca-4b30-87a9-169057323670	7db5ba07-e7fd-4795-844d-e59035681949	1450530d-97fe-4116-9054-d89694a02d25	s256	vQICJ903_9dcqTNzQBQRVv2pbzaomZdgb-b4d0zjxu4	email			2026-05-26 08:22:42.560044+00	2026-05-26 08:22:42.560044+00	email/signup	\N	\N	\N	\N	\N	f
918cc895-6742-4540-8b57-a0b52d1fc861	c4467f4c-aad8-4430-bdda-1b004fe4cf53	b675c1da-91d0-45c3-8e54-dfb2bfe8e3f7	s256	fYbnkoEgoNvSwYasKraQskUOjU0jR09o_dr6jo9eafo	email			2026-05-26 12:47:41.092679+00	2026-05-26 12:47:41.092679+00	email/signup	\N	\N	\N	\N	\N	f
c4200b73-be90-4e16-8aeb-c74a6816a1cc	91fdfc3e-ff09-4c78-b411-31489487fd68	e7b474bb-d63f-4bbe-a6af-227ecc00a016	s256	VJuzDpbhNCkAnGx_QnLsYrqBu4QElIIy5_qpFmsfhZM	email			2026-06-02 09:22:29.22539+00	2026-06-02 09:22:29.22539+00	email/signup	\N	\N	\N	\N	\N	f
6861f76b-8ce8-45f2-9ed3-f7b68c7a859d	bd7b8095-f9e0-4f3b-8894-a22d061af337	7749cc2f-c0ec-48d9-9c78-4079ffdfe3f1	s256	r0hI0EbE7jBSZt5o5aiNbmpKyBr5wESrxKkj0nmlgVI	email			2026-06-02 13:13:28.986393+00	2026-06-02 13:13:28.986393+00	email/signup	\N	\N	\N	\N	\N	f
569661ef-d036-4a9e-b99f-ac8998a79869	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	19248521-6d0b-404a-b77b-03887503002f	s256	_pzXao2r9ffPUivIqCHFVC4oswzdhm8_rcQVHNZTMho	email			2026-06-03 07:44:01.831239+00	2026-06-03 07:44:01.831239+00	email/signup	\N	\N	\N	\N	\N	f
a6a1911f-447d-4556-b8d2-b092da1f3024	8a9a9cc3-91ca-429d-893c-4fca61f02479	d79b39dc-aed9-4ebf-a608-a58ee51ba6ed	s256	V9XfNe2CHRXfe9hg6uhGYJAl84QFkvZ_ymxzf3ziWUo	email			2026-06-04 11:22:55.779132+00	2026-06-04 11:22:55.779132+00	email/signup	\N	\N	\N	\N	\N	f
9dbdf011-afd7-46be-af7c-78e56a7e019b	be20a8d7-d8e8-457e-bc94-828592ac9ab3	851adb93-4f06-4ef5-9fb2-4e7f7b419a6e	s256	LNaHTFdneEa97auhD8IxV0Js5qD9VuYtxPZjW21zMjI	email			2026-06-04 13:04:33.148769+00	2026-06-04 13:04:33.148769+00	email/signup	\N	\N	\N	\N	\N	f
287f358c-7229-4ea1-b1aa-417d765e483a	e6e44d92-1a53-4123-9aec-c05dd825f974	c8c4e74d-c3d3-4f5c-86fb-ffb1e2c6adcb	s256	mC5kH3fmhH3MNH-lC1TSAsa1b0mQbxMw2vseEKQg0mc	email			2026-06-04 18:43:20.223478+00	2026-06-04 18:43:20.223478+00	email/signup	\N	\N	\N	\N	\N	f
088939c6-e91c-489c-9e22-546055088324	223c9b39-49e8-4e7b-86e4-59eb1d3e90d8	96701d52-414d-4f62-b0a2-5c29a288d9b0	s256	EnDzuaJ0VgNqnQfxYzInN4UyqQgCm9p82VvVJ1tsu2w	email			2026-06-05 08:45:45.159374+00	2026-06-05 09:40:36.184831+00	email/signup	2026-06-05 09:40:36.184779+00	\N	\N	\N	\N	f
7d7243a1-cae3-46ee-99a1-e7d1f1073a41	223c9b39-49e8-4e7b-86e4-59eb1d3e90d8	27b8396a-13ad-40d8-8800-64f73edbbdb4	s256	L8Bzq5K4a2WeLFZ2Csab6ruNOIRdq1E_BqOwOSLP5PY	recovery			2026-06-05 09:46:57.660575+00	2026-06-05 09:46:57.660575+00	recovery	\N	\N	\N	\N	\N	f
b78e4792-0fe0-48db-bb2c-42b51c7c7797	e3a3a741-691f-47ec-972b-bf8e8a6ca5d4	05fe5024-701a-4984-8a92-77f1f62a4a12	s256	KjBCmNaCBRSfAw_uueIYme1LTtZgJmZgDPOsmRjvqY4	email			2026-06-23 08:29:43.207866+00	2026-06-23 08:29:43.207866+00	email/signup	\N	\N	\N	\N	\N	f
e9545280-0c8b-4b84-ab09-f76d6e52d6fc	c10877d2-280b-482b-a908-19be79f4b3bd	ca6de4bb-cced-4989-bcae-723bb19d485a	s256	I_xVfCZtxBdhQ0BENOptLbhnqrFMYKK2p3Bcd-jIw6I	email			2026-06-23 08:35:00.467934+00	2026-06-23 08:35:00.467934+00	email/signup	\N	\N	\N	\N	\N	f
b51f2d3a-ff46-4027-8d68-b5d081d90804	90b9a33d-fa23-47d5-a02b-3b7570fb9d8f	49295afd-c32a-4c66-b0c4-ef517ff4f815	s256	NsJ2yRMopvr5WlZR_HRXFDjiBkIkjIzXbbrVxLlyxNw	email			2026-06-23 09:01:49.528056+00	2026-06-23 09:01:49.528056+00	email/signup	\N	\N	\N	\N	\N	f
57e02d5c-2e6b-41c1-8d50-3f07e0348d01	117262d7-15c7-4dc4-9c5e-0d3a979b1102	d540ddf1-1ecc-46fb-b043-aed858114efb	s256	rVTVBd-Yh8Y3jU7ZoctNG6DkGEyZO3ccqgaMWpaoXzg	email			2026-06-23 09:07:05.775292+00	2026-06-23 09:07:05.775292+00	email/signup	\N	\N	\N	\N	\N	f
80132ff2-fbf9-4cbd-a3b9-b67cbb43baa3	25631b3c-4921-421a-8b13-7e2d72e0dbf0	9e89f330-8e63-44ca-8afe-5de0800e7f2b	s256	kyrJ-WiLTHtMpBtQeZguJMdiS4hp8RlhUdrElqbm6oc	email			2026-06-23 09:10:58.840579+00	2026-06-23 09:10:58.840579+00	email/signup	\N	\N	\N	\N	\N	f
985b958b-7707-4f29-97a3-12cfb5904ab1	a0296447-63d6-4dd6-9924-55cccc0f0a29	e074837f-7d47-438d-a0d7-1c4b99d4f1b2	s256	SzXPpxZcCdXMeDeggoKCWQMiijpYR9RYMYpCtkwhK6U	email			2026-06-23 20:18:53.957392+00	2026-06-23 20:18:53.957392+00	email/signup	\N	\N	\N	\N	\N	f
39e66c12-d476-45ed-bca7-732930fd016d	e3ac4379-668d-410e-82a4-62064fdbaba6	565102a6-c7b8-477e-bef7-0b383934f453	s256	9jWMGC1H_lxs2nk51iwHVDUglPWxhdVx6uCUSkGSTFs	email			2026-06-23 20:58:05.826641+00	2026-06-23 20:58:05.826641+00	email/signup	\N	\N	\N	\N	\N	f
6139c5c2-ef56-4464-be84-0b9fb783777c	36252019-fac0-4514-91df-23eb5fdc3a5f	0f72367a-b3d3-4eaa-9120-69206feae699	s256	BAYipKOnYWAr9OfjAWIr-LeHLv_iMLWMJruZpsuKRCo	email			2026-06-24 07:18:10.613557+00	2026-06-24 07:18:10.613557+00	email/signup	\N	\N	\N	\N	\N	f
3853b023-8bf0-4fd5-88e8-f0537b5f44a5	2e01e063-789f-4c1e-ad09-180781c35411	e2289c44-f8d9-4db2-a7dd-e3af40b0875a	s256	xedSgIDKYg5b2qMonkoNkCRKoO_KbomeRRkOizgVl4Y	email			2026-06-24 07:34:15.679711+00	2026-06-24 07:34:15.679711+00	email/signup	\N	\N	\N	\N	\N	f
9ddd90fe-0ee7-4411-b134-d69a7b65a1b1	33206a78-c324-45b5-a09b-ecd6d3a89052	f87fbe9a-8218-4a0d-b2e7-32dff848ba30	s256	R-YqrN77VtYXrDrbaySVYksGeZJqwMXWWy3FQiDSmLY	email			2026-06-24 09:04:30.018004+00	2026-06-24 09:04:30.018004+00	email/signup	\N	\N	\N	\N	\N	f
56611fe6-6075-4abc-82ba-2be7a24f531e	889b3064-f9c0-42ea-9800-6cd4d1078f1a	3ae003b4-2854-4eeb-b9b6-190f49ba10d7	s256	OrXQBxFJ-6ZIu2iWsmMBDT5bZ_jCnpH0cIar4WPhBCI	email			2026-06-24 13:33:09.035376+00	2026-06-24 13:33:09.035376+00	email/signup	\N	\N	\N	\N	\N	f
80a56cb1-295e-489b-ae48-c2a2d1d76f0f	1ef8cb01-2813-4203-b05d-52ad47f7c8de	57bef741-4688-4bfe-8d23-a93a1165b4ff	s256	g-9a4mYR3xTRgJ3GniS3VHWmvSkNyLoIVH6C0LT3yNo	email			2026-06-25 14:49:54.984373+00	2026-06-25 14:49:54.984373+00	email/signup	\N	\N	\N	\N	\N	f
a9ccc822-cab0-4093-9fa8-54dd219883bb	1ef8cb01-2813-4203-b05d-52ad47f7c8de	969cf734-dbe8-4bcd-b085-1caa98d3cc19	s256	A8JvaFgcB3bAHg0_Xk5L6ThCRFqftfRxdNo-SUrK2zY	recovery			2026-06-25 21:20:08.661027+00	2026-06-25 21:20:08.661027+00	recovery	\N	\N	\N	\N	\N	f
98b2c966-314f-4a81-823a-18fbee7fb23a	161a1b83-eb22-4b34-bd39-54fede8d5a41	ced93ba2-0bc2-4ddc-ad94-0dab8def86c3	s256	cYIM2cQA8MWBRLOpG-bxxbF-v4KNnybgAoJDB1jUicM	email			2026-06-26 06:13:19.760828+00	2026-06-26 06:13:19.760828+00	email/signup	\N	\N	\N	\N	\N	f
2ea03b1f-46e3-4958-8352-06cf8e39cb70	fe247a05-1e3e-44f2-8537-1365cd368019	faf74bf2-f661-4746-82d5-28df10c45923	s256	IVwIg-BKaJUmlGtga6eWudeRYlCOhlRGfBPLAUeuNdk	email			2026-06-26 06:22:35.780646+00	2026-06-26 06:22:35.780646+00	email/signup	\N	\N	\N	\N	\N	f
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."users" ("instance_id", "id", "aud", "role", "email", "encrypted_password", "email_confirmed_at", "invited_at", "confirmation_token", "confirmation_sent_at", "recovery_token", "recovery_sent_at", "email_change_token_new", "email_change", "email_change_sent_at", "last_sign_in_at", "raw_app_meta_data", "raw_user_meta_data", "is_super_admin", "created_at", "updated_at", "phone", "phone_confirmed_at", "phone_change", "phone_change_token", "phone_change_sent_at", "email_change_token_current", "email_change_confirm_status", "banned_until", "reauthentication_token", "reauthentication_sent_at", "is_sso_user", "deleted_at", "is_anonymous") FROM stdin;
00000000-0000-0000-0000-000000000000	8a9a9cc3-91ca-429d-893c-4fca61f02479	authenticated	authenticated	ncbobbittent@yahoo.com	$2a$10$BIHUKtB/t37C10qVTSM6VuIJi.NdZERPxHHTgPQrX/DYOs/TfmNk.	\N	\N	c8d7e1dbcce76609eade6e5b9cdea394a9412ee7150ab1f7538a2520	2026-06-04 11:23:01.321493+00	ded25e7a4966e84029c1a633260a1964c5520acba936d35a081ad653	2026-06-26 10:13:15.945559+00			\N	\N	{"provider": "email", "providers": ["email"]}	{"sub": "8a9a9cc3-91ca-429d-893c-4fca61f02479", "email": "ncbobbittent@yahoo.com", "email_verified": false, "phone_verified": false}	\N	2026-06-04 11:22:55.740078+00	2026-06-26 10:13:15.946035+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	bd7b8095-f9e0-4f3b-8894-a22d061af337	authenticated	authenticated	helen.jennings1@yahoo.co.uk	$2a$10$hYXbgHnWhxES8EjdUw3bUe5FbIAqZttuVXmUd8SY5kAT2VxxloeuK	\N	\N	355b2169941a9fb3fe01e1cc9dd8f7b3f1a50f9491be0f0ed4dfe4fd	2026-06-02 13:13:32.512152+00	4f336c06f2d299c960c7a0c4380a244847678ec3b371bdfd897e7f81	2026-06-26 10:13:24.243581+00			\N	\N	{"provider": "email", "providers": ["email"]}	{"sub": "bd7b8095-f9e0-4f3b-8894-a22d061af337", "email": "helen.jennings1@yahoo.co.uk", "email_verified": false, "phone_verified": false}	\N	2026-06-02 13:13:28.95986+00	2026-06-26 10:13:24.244064+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	468cade7-1d68-497e-9aa0-57e79722996e	authenticated	authenticated	houliston.david@gmail.com	$2a$10$2Qtsdd8DgySF7u9nq7ykTewMtOFfRkNnSFfQysDFcFDqAA0bFCQdu	2026-05-12 20:42:23.653537+00	\N		\N		2026-05-21 13:27:57.621152+00			\N	2026-09-22 13:35:51.866667+00	{"provider": "email", "providers": ["email"]}	{"sub": "468cade7-1d68-497e-9aa0-57e79722996e", "email": "houliston.david@gmail.com", "email_verified": true, "phone_verified": false}	\N	2026-05-12 20:41:27.87437+00	2026-09-22 15:04:46.441319+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	7db5ba07-e7fd-4795-844d-e59035681949	authenticated	authenticated	therapy@davidhoulistoncounselling.com	$2a$10$KwvlSuUf000fAdp7kZ8pn.nbFheD4QOdTCjBqS315w6lSFS2I7HD2	2026-05-26 08:23:56.422109+00	\N		2026-05-26 08:22:47.467074+00		\N			\N	2026-09-22 15:06:22.845459+00	{"provider": "email", "providers": ["email"]}	{"sub": "7db5ba07-e7fd-4795-844d-e59035681949", "email": "therapy@davidhoulistoncounselling.com", "email_verified": true, "phone_verified": false}	\N	2026-05-26 08:22:42.519851+00	2026-09-23 07:40:02.980267+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	889b3064-f9c0-42ea-9800-6cd4d1078f1a	authenticated	authenticated	hrisamitreva@gmail.com	$2a$10$ZeEhqM5OD8HtwPM281/zAORonisGbEMOB2KwFWcPAuOQAewNUbV82	2026-06-24 13:33:29.738581+00	\N		2026-06-24 13:33:14.963331+00		\N			\N	2026-06-24 13:33:31.752363+00	{"provider": "email", "providers": ["email"]}	{"sub": "889b3064-f9c0-42ea-9800-6cd4d1078f1a", "email": "hrisamitreva@gmail.com", "email_verified": true, "phone_verified": false}	\N	2026-06-24 13:33:09.00555+00	2026-06-25 19:45:28.784744+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	e6e44d92-1a53-4123-9aec-c05dd825f974	authenticated	authenticated	rreewith@gmail.com	$2a$10$7SUsfWLftdVDyPFfk5gDZOTwPyC.ucruemxakyyGJUVl8NUgoCUg.	2026-06-04 18:44:36.123556+00	\N		2026-06-04 18:43:29.563106+00		\N			\N	2026-06-09 09:29:33.511242+00	{"provider": "email", "providers": ["email"]}	{"sub": "e6e44d92-1a53-4123-9aec-c05dd825f974", "email": "rreewith@gmail.com", "email_verified": true, "phone_verified": false}	\N	2026-06-04 18:43:20.182765+00	2026-06-09 09:29:33.573333+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	223c9b39-49e8-4e7b-86e4-59eb1d3e90d8	authenticated	authenticated	gladysmabongiwemokebisa@gmail.com	$2a$10$Gg5TP2vSOM6f3GhzFN6xK.BN.lOZRa6NandL8ayb7v5naLIgkP.ym	2026-06-05 09:40:36.166594+00	\N		2026-06-05 08:45:45.171097+00	pkce_fb381a81febdc1bc796493b7697d77e711e9b011b2f5757d65961f08	2026-06-05 09:46:57.671585+00			\N	\N	{"provider": "email", "providers": ["email"]}	{"sub": "223c9b39-49e8-4e7b-86e4-59eb1d3e90d8", "email": "gladysmabongiwemokebisa@gmail.com", "email_verified": true, "phone_verified": false}	\N	2026-06-05 08:45:45.121436+00	2026-06-05 09:46:59.033868+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	5711310a-b42c-4b02-8420-c0818e98d748	authenticated	authenticated	sarah.olds@gmail.com	$2a$10$zUAbsVbGcJJ55v6xMOzDyeL5AIYmXkZ/7zm19qZGqMWsRMqztfaei	2026-06-27 10:02:39.441696+00	\N		2026-06-27 10:02:24.582581+00		\N			\N	2026-06-27 10:02:39.447707+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-06-27 10:02:24.665333+00	2026-06-27 10:02:39.466443+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	be20a8d7-d8e8-457e-bc94-828592ac9ab3	authenticated	authenticated	mb.therapy@outlook.com	$2a$10$JRCaZAI2piBAQOLP4PtkKe751a1l9udan7vDI/LYOrlI47jNRcmC6	2026-06-04 13:06:51.348847+00	\N		2026-06-04 13:04:35.751734+00		\N			\N	2026-07-10 13:25:10.053652+00	{"provider": "email", "providers": ["email"]}	{"sub": "be20a8d7-d8e8-457e-bc94-828592ac9ab3", "email": "mb.therapy@outlook.com", "email_verified": true, "phone_verified": false}	\N	2026-06-04 13:04:33.104133+00	2026-09-16 19:38:24.968482+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	2e01e063-789f-4c1e-ad09-180781c35411	authenticated	authenticated	nigelsmall1952@gmail.com	$2a$10$XteVS5/zkiwAJ16sizIVMuvqSAcZXD.gl/xjxsMTe7Xs6WUDY40WG	2026-06-24 07:34:26.202198+00	\N		2026-06-24 07:34:17.680474+00		\N			\N	2026-06-24 07:34:36.481742+00	{"provider": "email", "providers": ["email"]}	{"sub": "2e01e063-789f-4c1e-ad09-180781c35411", "email": "nigelsmall1952@gmail.com", "email_verified": true, "phone_verified": false}	\N	2026-06-24 07:34:15.647087+00	2026-06-24 10:26:54.344934+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	25c0e60d-93ac-4ba4-a8c3-46c097cdc973	authenticated	authenticated	a@example.com	$2a$10$7VI0cs9iRxXgc/Gbo6IgQOaMuWFQHQCsm8rSBvw7JFHEJZSmAY3AC	\N	\N	303b31aec575765592097421b738423a901fa9e739ca4e1e43baf36d	2026-09-15 11:03:04.060498+00		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{}	\N	2026-09-15 11:03:04.146014+00	2026-09-15 11:03:04.211238+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	authenticated	authenticated	55serving_coops@icloud.com	$2a$10$H9RGjqNHP94VFpNTCECLeuF1a3Jmnth21LT2V8LktPZ1Bg/a8mI2S	2026-06-03 07:44:51.610512+00	\N		2026-06-03 07:44:05.046551+00		\N			\N	2026-06-03 07:45:05.613532+00	{"provider": "email", "providers": ["email"]}	{"sub": "03fae691-1b92-4f37-bfa7-e6a3f7e68e32", "email": "55serving_coops@icloud.com", "email_verified": true, "phone_verified": false}	\N	2026-06-03 07:44:01.78277+00	2026-06-03 07:45:05.615691+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	baefdd0b-521d-4090-8021-1c39c7614608	authenticated	authenticated	test1@bookmytherapy.co.uk	$2a$10$nAM9Q2Yl7idJbKiVmqeZQergjKQr1htAI0SHWoaooSXA0KAz43VPm	\N	\N	e509e3bb0910b42dabd7e7705b89b6bc21bc281e4abb86efd180ffbb	2026-09-19 08:03:06.866048+00		\N			\N	\N	{"provider": "email", "providers": ["email"]}	{}	\N	2026-09-19 08:03:06.949188+00	2026-09-19 08:03:07.014702+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	a0296447-63d6-4dd6-9924-55cccc0f0a29	authenticated	authenticated	contactkatescounselling@gmail.com	$2a$10$ZrAn3vUYjjHgvN6RbLG78.XbfxaeNFYZQiGFc7aybYseSYO78oLXm	2026-06-23 20:19:44.764802+00	\N		2026-06-23 20:18:57.067408+00		\N			\N	2026-06-23 20:20:18.444838+00	{"provider": "email", "providers": ["email"]}	{"sub": "a0296447-63d6-4dd6-9924-55cccc0f0a29", "email": "contactkatescounselling@gmail.com", "email_verified": true, "phone_verified": false}	\N	2026-06-23 20:18:53.918327+00	2026-06-23 20:20:18.450769+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	33206a78-c324-45b5-a09b-ecd6d3a89052	authenticated	authenticated	jomobi@hotmail.co.uk	$2a$10$Aa.XnIN1eX1KovMGCKdnkeRPYHMenj3ioDzSOVXrBTOaxSJ/0HSOm	\N	\N	8a3b136a19132a5d37bfe8d27920df4fdfd44b2d4aa4728a60c7890c	2026-06-24 09:04:33.687597+00	acae3ab740ad93dcae19ab978fa34149710789425d5465dae294878b	2026-06-26 10:11:03.453261+00			\N	\N	{"provider": "email", "providers": ["email"]}	{"sub": "33206a78-c324-45b5-a09b-ecd6d3a89052", "email": "jomobi@hotmail.co.uk", "email_verified": false, "phone_verified": false}	\N	2026-06-24 09:04:29.968307+00	2026-06-26 10:11:03.45368+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	authenticated	authenticated	general.orenge@gmail.com	$2a$10$o6T3eKGIdvJTmsNpwiNy.uVV33z03yy/QIsRioJI/zhjTdt1YaVFq	2026-06-26 19:28:43.775232+00	\N		2026-06-26 19:28:05.497539+00		\N			\N	2026-08-25 18:38:59.882635+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-06-26 19:28:05.581812+00	2026-08-25 18:38:59.884897+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	9a796c66-37fe-4446-b279-468fb6ac3dfd	authenticated	authenticated	info@evacounselling.com	$2a$10$8NR2hYE6ayW35SNC9Sf7oe8N8jlLb/k3ZIM7yU9fmiODbLKod0f42	2026-06-26 10:05:21.788914+00	\N		2026-06-26 10:03:29.593002+00		\N			\N	2026-07-01 19:53:54.931306+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-06-26 10:03:29.681727+00	2026-07-19 16:32:48.548593+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	67e74856-ce44-4e06-837c-cb7a9e813959	authenticated	authenticated	sharon@bettertomorrowscounselling.com	$2a$10$L1ENJwE6FfM2APY93wOlYuHBHHu5d0nrZctoxpef0AlYRL4QA0NSK	2026-06-27 17:25:30.490851+00	\N		2026-06-27 17:24:06.070757+00		\N			\N	2026-08-14 18:04:27.891069+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-06-27 17:24:06.152586+00	2026-09-11 17:40:29.815778+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c4467f4c-aad8-4430-bdda-1b004fe4cf53	authenticated	authenticated	davidchefoo@gmail.com	$2a$10$/Y/h1UyM4NkwdBa871NOie/E9/WMpWHoIbBKtKsDuL6RfWyW7sIAm	2026-05-26 12:48:26.728821+00	\N		2026-05-26 12:47:45.582203+00		\N			\N	2026-09-20 14:02:46.74154+00	{"provider": "email", "providers": ["email", "google"]}	{"iss": "https://accounts.google.com", "sub": "116527584480606787108", "name": "David Houliston", "email": "davidchefoo@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIJVrMHzZDnQJ78EbZeFUqEkOjiTiCZg9sKm-3spjBClvdRWg=s96-c", "full_name": "David Houliston", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIJVrMHzZDnQJ78EbZeFUqEkOjiTiCZg9sKm-3spjBClvdRWg=s96-c", "provider_id": "116527584480606787108", "email_verified": true, "phone_verified": false}	\N	2026-05-26 12:47:41.069277+00	2026-09-20 15:02:02.733006+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	1ef8cb01-2813-4203-b05d-52ad47f7c8de	authenticated	authenticated	marymccabecounselling@gmail.com	$2a$10$0LPidH/fVjUNYCvHG3eJd.sjNrZFE5DuY.oM7s.ls2I5RLmnULdM2	2026-06-26 10:30:22.861612+00	\N		2026-06-25 14:50:00.287123+00		2026-06-26 10:10:51.210285+00			\N	2026-06-26 10:30:22.870365+00	{"provider": "email", "providers": ["email"]}	{"sub": "1ef8cb01-2813-4203-b05d-52ad47f7c8de", "email": "marymccabecounselling@gmail.com", "email_verified": true, "phone_verified": false}	\N	2026-06-25 14:49:54.928363+00	2026-06-26 20:39:03.457112+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	c4233153-ba79-4596-a447-7c979056fd33	authenticated	authenticated	debi@abetterselftherapies.co.uk	$2a$10$tCEUzda0kL6zAN1o7J.iqOLlLhxLO5ldDrSC/Y/FvMbkCgOHa2XzG	2026-07-06 12:38:07.30278+00	\N		2026-07-06 12:37:35.600584+00		\N			\N	2026-07-06 20:23:36.791628+00	{"provider": "email", "providers": ["email"]}	{"email_verified": true}	\N	2026-07-06 12:37:35.684663+00	2026-09-19 16:55:02.108673+00	\N	\N			\N		0	\N		\N	f	\N	f
00000000-0000-0000-0000-000000000000	36252019-fac0-4514-91df-23eb5fdc3a5f	authenticated	authenticated	nwwb@outlook.com	$2a$10$ENXDwPPrsbFgHkKO1Zh5yOUGV0OAt4xJcxWRIkrV1G3SvsuD7Ngb2	2026-06-24 07:19:11.41526+00	\N		2026-06-24 07:18:13.507074+00		\N			\N	2026-09-04 12:31:15.477514+00	{"provider": "email", "providers": ["email"]}	{"sub": "36252019-fac0-4514-91df-23eb5fdc3a5f", "email": "nwwb@outlook.com", "email_verified": true, "phone_verified": false}	\N	2026-06-24 07:18:10.589052+00	2026-09-04 12:31:15.556414+00	\N	\N			\N		0	\N		\N	f	\N	f
\.


--
-- Data for Name: identities; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."identities" ("provider_id", "user_id", "identity_data", "provider", "last_sign_in_at", "created_at", "updated_at", "id") FROM stdin;
468cade7-1d68-497e-9aa0-57e79722996e	468cade7-1d68-497e-9aa0-57e79722996e	{"sub": "468cade7-1d68-497e-9aa0-57e79722996e", "email": "houliston.david@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-05-12 20:41:27.90049+00	2026-05-12 20:41:27.900552+00	2026-05-12 20:41:27.900552+00	f0a0aa21-2ae4-49db-b89f-275e252d3d64
bd7b8095-f9e0-4f3b-8894-a22d061af337	bd7b8095-f9e0-4f3b-8894-a22d061af337	{"sub": "bd7b8095-f9e0-4f3b-8894-a22d061af337", "email": "helen.jennings1@yahoo.co.uk", "email_verified": false, "phone_verified": false}	email	2026-06-02 13:13:28.982025+00	2026-06-02 13:13:28.982077+00	2026-06-02 13:13:28.982077+00	89a34e5a-6311-486a-b82e-7502d62f5050
03fae691-1b92-4f37-bfa7-e6a3f7e68e32	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	{"sub": "03fae691-1b92-4f37-bfa7-e6a3f7e68e32", "email": "55serving_coops@icloud.com", "email_verified": true, "phone_verified": false}	email	2026-06-03 07:44:01.820321+00	2026-06-03 07:44:01.820374+00	2026-06-03 07:44:01.820374+00	61c24772-604c-4752-a653-11609ed75690
8a9a9cc3-91ca-429d-893c-4fca61f02479	8a9a9cc3-91ca-429d-893c-4fca61f02479	{"sub": "8a9a9cc3-91ca-429d-893c-4fca61f02479", "email": "ncbobbittent@yahoo.com", "email_verified": false, "phone_verified": false}	email	2026-06-04 11:22:55.768444+00	2026-06-04 11:22:55.768493+00	2026-06-04 11:22:55.768493+00	ef8a14d3-175b-4f68-ae56-8d9b5e1a2085
baefdd0b-521d-4090-8021-1c39c7614608	baefdd0b-521d-4090-8021-1c39c7614608	{"sub": "baefdd0b-521d-4090-8021-1c39c7614608", "email": "test1@bookmytherapy.co.uk", "email_verified": false, "phone_verified": false}	email	2026-09-19 08:03:06.996981+00	2026-09-19 08:03:06.99706+00	2026-09-19 08:03:06.99706+00	a3781932-db5e-4b4c-89b7-2e389c453c32
be20a8d7-d8e8-457e-bc94-828592ac9ab3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	{"sub": "be20a8d7-d8e8-457e-bc94-828592ac9ab3", "email": "mb.therapy@outlook.com", "email_verified": true, "phone_verified": false}	email	2026-06-04 13:04:33.140021+00	2026-06-04 13:04:33.140073+00	2026-06-04 13:04:33.140073+00	7d77434f-b34d-451c-8a95-a004dbad08c5
7db5ba07-e7fd-4795-844d-e59035681949	7db5ba07-e7fd-4795-844d-e59035681949	{"sub": "7db5ba07-e7fd-4795-844d-e59035681949", "email": "therapy@davidhoulistoncounselling.com", "email_verified": true, "phone_verified": false}	email	2026-05-26 08:22:42.55323+00	2026-05-26 08:22:42.553284+00	2026-05-26 08:22:42.553284+00	96e23531-5036-4163-8bb3-598b269ffcce
c4467f4c-aad8-4430-bdda-1b004fe4cf53	c4467f4c-aad8-4430-bdda-1b004fe4cf53	{"sub": "c4467f4c-aad8-4430-bdda-1b004fe4cf53", "email": "davidchefoo@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-05-26 12:47:41.086506+00	2026-05-26 12:47:41.08656+00	2026-05-26 12:47:41.08656+00	f0ea8641-e213-4095-846d-3869f268acdc
2e01e063-789f-4c1e-ad09-180781c35411	2e01e063-789f-4c1e-ad09-180781c35411	{"sub": "2e01e063-789f-4c1e-ad09-180781c35411", "email": "nigelsmall1952@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-06-24 07:34:15.674673+00	2026-06-24 07:34:15.674721+00	2026-06-24 07:34:15.674721+00	eed0d9d3-d908-408c-933a-1de0c1a0086a
e6e44d92-1a53-4123-9aec-c05dd825f974	e6e44d92-1a53-4123-9aec-c05dd825f974	{"sub": "e6e44d92-1a53-4123-9aec-c05dd825f974", "email": "rreewith@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-06-04 18:43:20.216898+00	2026-06-04 18:43:20.216963+00	2026-06-04 18:43:20.216963+00	e3029f8a-0843-45fe-b6b2-fcd7467eb3ef
223c9b39-49e8-4e7b-86e4-59eb1d3e90d8	223c9b39-49e8-4e7b-86e4-59eb1d3e90d8	{"sub": "223c9b39-49e8-4e7b-86e4-59eb1d3e90d8", "email": "gladysmabongiwemokebisa@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-06-05 08:45:45.151261+00	2026-06-05 08:45:45.151312+00	2026-06-05 08:45:45.151312+00	bf7e161f-9ac3-4d93-be76-32b2bcaf3154
33206a78-c324-45b5-a09b-ecd6d3a89052	33206a78-c324-45b5-a09b-ecd6d3a89052	{"sub": "33206a78-c324-45b5-a09b-ecd6d3a89052", "email": "jomobi@hotmail.co.uk", "email_verified": false, "phone_verified": false}	email	2026-06-24 09:04:30.003882+00	2026-06-24 09:04:30.003936+00	2026-06-24 09:04:30.003936+00	6672af50-cdd7-49ce-a9f4-103dbc7bf3aa
889b3064-f9c0-42ea-9800-6cd4d1078f1a	889b3064-f9c0-42ea-9800-6cd4d1078f1a	{"sub": "889b3064-f9c0-42ea-9800-6cd4d1078f1a", "email": "hrisamitreva@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-06-24 13:33:09.02731+00	2026-06-24 13:33:09.027364+00	2026-06-24 13:33:09.027364+00	781f8dea-e685-4c80-bb03-8c37dcfd8bbc
1ef8cb01-2813-4203-b05d-52ad47f7c8de	1ef8cb01-2813-4203-b05d-52ad47f7c8de	{"sub": "1ef8cb01-2813-4203-b05d-52ad47f7c8de", "email": "marymccabecounselling@gmail.com", "email_verified": false, "phone_verified": false}	email	2026-06-25 14:49:54.971116+00	2026-06-25 14:49:54.971165+00	2026-06-25 14:49:54.971165+00	c0205f2a-ff50-41a4-8aaf-d65dd3337605
a0296447-63d6-4dd6-9924-55cccc0f0a29	a0296447-63d6-4dd6-9924-55cccc0f0a29	{"sub": "a0296447-63d6-4dd6-9924-55cccc0f0a29", "email": "contactkatescounselling@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-06-23 20:18:53.945229+00	2026-06-23 20:18:53.945281+00	2026-06-23 20:18:53.945281+00	c4ec25cd-549e-4802-8512-36682af6863c
36252019-fac0-4514-91df-23eb5fdc3a5f	36252019-fac0-4514-91df-23eb5fdc3a5f	{"sub": "36252019-fac0-4514-91df-23eb5fdc3a5f", "email": "nwwb@outlook.com", "email_verified": true, "phone_verified": false}	email	2026-06-24 07:18:10.606621+00	2026-06-24 07:18:10.606669+00	2026-06-24 07:18:10.606669+00	fe215ede-eaee-4cb2-b220-0144729b0410
3e433d1e-3feb-48b9-a7cc-73b5d546dd73	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	{"sub": "3e433d1e-3feb-48b9-a7cc-73b5d546dd73", "email": "general.orenge@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-06-26 19:28:05.608309+00	2026-06-26 19:28:05.608359+00	2026-06-26 19:28:05.608359+00	a09453b2-a2cc-41e2-95f9-4b2e6c2cd18b
9a796c66-37fe-4446-b279-468fb6ac3dfd	9a796c66-37fe-4446-b279-468fb6ac3dfd	{"sub": "9a796c66-37fe-4446-b279-468fb6ac3dfd", "email": "info@evacounselling.com", "email_verified": true, "phone_verified": false}	email	2026-06-26 10:03:29.7356+00	2026-06-26 10:03:29.735668+00	2026-06-26 10:03:29.735668+00	c6bf7dbc-a364-4673-b0a4-308824bd62c1
5711310a-b42c-4b02-8420-c0818e98d748	5711310a-b42c-4b02-8420-c0818e98d748	{"sub": "5711310a-b42c-4b02-8420-c0818e98d748", "email": "sarah.olds@gmail.com", "email_verified": true, "phone_verified": false}	email	2026-06-27 10:02:24.71016+00	2026-06-27 10:02:24.710211+00	2026-06-27 10:02:24.710211+00	d1cfbd40-a42d-46a0-8953-f2140f899be0
67e74856-ce44-4e06-837c-cb7a9e813959	67e74856-ce44-4e06-837c-cb7a9e813959	{"sub": "67e74856-ce44-4e06-837c-cb7a9e813959", "email": "sharon@bettertomorrowscounselling.com", "email_verified": true, "phone_verified": false}	email	2026-06-27 17:24:06.194687+00	2026-06-27 17:24:06.194738+00	2026-06-27 17:24:06.194738+00	19c8db3e-b8fd-4c75-a226-70b7fff68391
c4233153-ba79-4596-a447-7c979056fd33	c4233153-ba79-4596-a447-7c979056fd33	{"sub": "c4233153-ba79-4596-a447-7c979056fd33", "email": "debi@abetterselftherapies.co.uk", "email_verified": true, "phone_verified": false}	email	2026-07-06 12:37:35.726036+00	2026-07-06 12:37:35.726087+00	2026-07-06 12:37:35.726087+00	5403fdce-f2a8-4534-ab25-99f1f81f24ff
25c0e60d-93ac-4ba4-a8c3-46c097cdc973	25c0e60d-93ac-4ba4-a8c3-46c097cdc973	{"sub": "25c0e60d-93ac-4ba4-a8c3-46c097cdc973", "email": "a@example.com", "email_verified": false, "phone_verified": false}	email	2026-09-15 11:03:04.200012+00	2026-09-15 11:03:04.200071+00	2026-09-15 11:03:04.200071+00	1e689397-f64a-400e-a7bb-5d029c388dc1
116527584480606787108	c4467f4c-aad8-4430-bdda-1b004fe4cf53	{"iss": "https://accounts.google.com", "sub": "116527584480606787108", "name": "David Houliston", "email": "davidchefoo@gmail.com", "picture": "https://lh3.googleusercontent.com/a/ACg8ocIJVrMHzZDnQJ78EbZeFUqEkOjiTiCZg9sKm-3spjBClvdRWg=s96-c", "full_name": "David Houliston", "avatar_url": "https://lh3.googleusercontent.com/a/ACg8ocIJVrMHzZDnQJ78EbZeFUqEkOjiTiCZg9sKm-3spjBClvdRWg=s96-c", "provider_id": "116527584480606787108", "email_verified": true, "phone_verified": false}	google	2026-09-20 08:52:24.920505+00	2026-09-20 08:52:24.92056+00	2026-09-20 08:54:29.310385+00	91c3bfba-9519-4942-b0ab-fc8642ef9876
\.


--
-- Data for Name: instances; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."instances" ("id", "uuid", "raw_base_config", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: oauth_clients; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_clients" ("id", "client_secret_hash", "registration_type", "redirect_uris", "grant_types", "client_name", "client_uri", "logo_uri", "created_at", "updated_at", "deleted_at", "client_type", "token_endpoint_auth_method") FROM stdin;
\.


--
-- Data for Name: sessions; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sessions" ("id", "user_id", "created_at", "updated_at", "factor_id", "aal", "not_after", "refreshed_at", "user_agent", "ip", "tag", "oauth_client_id", "refresh_token_hmac_key", "refresh_token_counter", "scopes") FROM stdin;
34c5b6d7-d524-4153-8b7e-cd7c07ed2da1	be20a8d7-d8e8-457e-bc94-828592ac9ab3	2026-06-09 14:28:11.089069+00	2026-06-09 14:28:11.089069+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	152.71.162.86	\N	\N	\N	\N	\N
826e623b-ea48-4b4f-8ac2-7f312b3d5b01	5711310a-b42c-4b02-8420-c0818e98d748	2026-06-27 10:02:39.448933+00	2026-06-27 10:02:39.448933+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36	86.139.112.239	\N	\N	\N	\N	\N
c3fdd87f-0415-4077-86b3-15022ec9af5f	7db5ba07-e7fd-4795-844d-e59035681949	2026-09-22 15:06:20.724425+00	2026-09-22 15:06:20.724425+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	5.68.158.85	\N	\N	\N	\N	\N
d21c89e0-b361-464c-a4cf-5a063e2454ed	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	2026-06-26 19:46:49.303391+00	2026-06-26 19:46:49.303391+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	80.3.27.217	\N	\N	\N	\N	\N
26c54547-be28-4e89-91a6-c21d1237b820	be20a8d7-d8e8-457e-bc94-828592ac9ab3	2026-06-04 13:06:51.361191+00	2026-06-04 13:06:51.361191+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36	152.71.207.142	\N	\N	\N	\N	\N
e17ae44e-7a67-408e-a062-9de65e3d7537	a0296447-63d6-4dd6-9924-55cccc0f0a29	2026-06-23 20:19:44.777007+00	2026-06-23 20:19:44.777007+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36	46.64.82.170	\N	\N	\N	\N	\N
f0e1ddfc-1010-4073-82c4-19e2782c7495	a0296447-63d6-4dd6-9924-55cccc0f0a29	2026-06-23 20:20:18.444937+00	2026-06-23 20:20:18.444937+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) SamsungBrowser/30.0 Chrome/143.0.0.0 Mobile Safari/537.36	46.64.82.170	\N	\N	\N	\N	\N
62524521-8963-4485-bf25-e20142929fbf	7db5ba07-e7fd-4795-844d-e59035681949	2026-09-22 15:06:22.845582+00	2026-09-23 07:40:02.99859+00	\N	aal1	\N	2026-09-23 07:40:02.99848	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	5.68.158.85	\N	\N	\N	\N	\N
dc8fefbb-0367-4285-8acf-86e0f26301c5	2e01e063-789f-4c1e-ad09-180781c35411	2026-06-24 07:34:36.481832+00	2026-06-24 10:26:54.356459+00	\N	aal1	\N	2026-06-24 10:26:54.356348	Mozilla/5.0 (iPhone; CPU iPhone OS 18_5 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/18.5 Mobile/15E148 Safari/604.1	92.207.129.21	\N	\N	\N	\N	\N
6b4434c7-6b4e-4235-a70d-d0946b839613	be20a8d7-d8e8-457e-bc94-828592ac9ab3	2026-06-05 16:41:44.198936+00	2026-06-09 20:54:50.016541+00	\N	aal1	\N	2026-06-09 20:54:50.016432	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	109.157.207.89	\N	\N	\N	\N	\N
f9aa7fbe-9925-4d59-ac5e-1a6d1ca7ac0f	1ef8cb01-2813-4203-b05d-52ad47f7c8de	2026-06-26 10:30:22.878048+00	2026-06-26 20:39:03.467253+00	\N	aal1	\N	2026-06-26 20:39:03.467141	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	90.215.97.56	\N	\N	\N	\N	\N
e0a484fa-8e54-4822-8eb0-046c39bf5b40	9a796c66-37fe-4446-b279-468fb6ac3dfd	2026-07-01 09:41:24.599139+00	2026-07-19 16:32:48.558284+00	\N	aal1	\N	2026-07-19 16:32:48.558166	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5.2 Safari/605.1.15	80.176.82.233	\N	\N	\N	\N	\N
481ae52d-5570-481d-abec-0e505fe9ea67	be20a8d7-d8e8-457e-bc94-828592ac9ab3	2026-06-28 16:25:26.475737+00	2026-06-28 18:23:33.853886+00	\N	aal1	\N	2026-06-28 18:23:33.853777	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	109.157.206.156	\N	\N	\N	\N	\N
19e898d3-d68a-4ff9-8c4c-c1af00c4dcfa	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	2026-06-26 19:28:43.791358+00	2026-06-26 19:28:43.791358+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	80.3.27.217	\N	\N	\N	\N	\N
e01b3ab1-9120-44b4-b8f2-2644e640b97c	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	2026-06-26 19:54:34.751778+00	2026-06-26 21:37:11.56402+00	\N	aal1	\N	2026-06-26 21:37:11.563206	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	80.3.27.217	\N	\N	\N	\N	\N
db97d4ac-8c99-4817-aceb-791f8ed49c0f	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	2026-06-26 21:38:14.173651+00	2026-06-26 21:38:14.173651+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Safari/605.1.15	104.28.30.127	\N	\N	\N	\N	\N
9c3c73e6-6fc4-47f2-ac74-1435d035446b	e6e44d92-1a53-4123-9aec-c05dd825f974	2026-06-09 09:29:33.51239+00	2026-06-09 09:29:33.51239+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36 OPR/131.0.0.0	102.252.80.2	\N	\N	\N	\N	\N
5401fcff-a126-4078-a1c7-a6a5e9d76c77	c4233153-ba79-4596-a447-7c979056fd33	2026-07-06 20:23:36.791754+00	2026-09-19 16:55:02.122432+00	\N	aal1	\N	2026-09-19 16:55:02.122313	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Mobile Safari/537.36	88.97.210.35	\N	\N	\N	\N	\N
ae6e6ea6-5d7a-401f-bfa4-c252bf613f56	be20a8d7-d8e8-457e-bc94-828592ac9ab3	2026-07-10 13:25:10.053755+00	2026-08-14 07:27:33.435714+00	\N	aal1	\N	2026-08-14 07:27:33.435613	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/151.0.0.0 Safari/537.36	152.71.183.113	\N	\N	\N	\N	\N
ec3e22ea-ae51-4958-b97b-41bddfae478c	889b3064-f9c0-42ea-9800-6cd4d1078f1a	2026-06-24 13:33:29.743181+00	2026-06-24 13:33:29.743181+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	94.72.215.137	\N	\N	\N	\N	\N
059170df-6abe-40d1-a717-9e951ee4f5a1	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	2026-08-22 18:52:12.018232+00	2026-08-22 18:52:12.018232+00	\N	aal1	\N	\N	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Mobile/15E148 Safari/604.1	148.252.160.78	\N	\N	\N	\N	\N
27743ecc-d21e-4528-a7bb-19b0c6ac0b22	e6e44d92-1a53-4123-9aec-c05dd825f974	2026-06-04 18:44:36.142067+00	2026-06-04 18:44:36.142067+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	102.251.9.14	\N	\N	\N	\N	\N
bdefc281-884d-4f38-a057-d18b756d7bcd	e6e44d92-1a53-4123-9aec-c05dd825f974	2026-06-04 18:45:16.429507+00	2026-06-04 18:45:16.429507+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Mobile Safari/537.36	102.252.9.21	\N	\N	\N	\N	\N
c44cca65-d3ad-4981-8534-e2e0de7c99d0	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	2026-06-03 07:44:51.615479+00	2026-06-03 07:44:51.615479+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Safari/605.1.15	147.12.132.209	\N	\N	\N	\N	\N
7cfc8870-0dd0-4970-bd6f-b3aad7ef39a9	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	2026-06-03 07:45:05.613636+00	2026-06-03 07:45:05.613636+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.3 Safari/605.1.15	147.12.132.209	\N	\N	\N	\N	\N
3e251737-1efa-4403-93ae-622a256973f0	2e01e063-789f-4c1e-ad09-180781c35411	2026-06-24 07:34:26.205975+00	2026-06-24 07:34:26.205975+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	92.207.129.21	\N	\N	\N	\N	\N
0baad439-ac66-4343-8f1c-2f458ac87456	36252019-fac0-4514-91df-23eb5fdc3a5f	2026-06-24 21:28:40.765171+00	2026-06-24 21:28:40.765171+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	86.155.60.108	\N	\N	\N	\N	\N
c92633b1-49fe-4b1b-9957-8b230742234e	be20a8d7-d8e8-457e-bc94-828592ac9ab3	2026-06-04 13:06:54.775033+00	2026-06-24 18:48:19.058046+00	\N	aal1	\N	2026-06-24 18:48:19.057929	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	86.178.199.138	\N	\N	\N	\N	\N
3f2211d8-f158-4871-aa2a-bafb59af8896	9a796c66-37fe-4446-b279-468fb6ac3dfd	2026-07-01 19:53:54.931406+00	2026-07-02 09:07:11.746992+00	\N	aal1	\N	2026-07-02 09:07:11.746869	Mozilla/5.0 (iPhone; CPU iPhone OS 18_7 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.5 Mobile/15E148 Safari/604.1	104.28.30.90	\N	\N	\N	\N	\N
a70d4080-4500-4ca2-adc2-eb9972badc4d	889b3064-f9c0-42ea-9800-6cd4d1078f1a	2026-06-24 13:33:31.752453+00	2026-06-25 19:45:28.799867+00	\N	aal1	\N	2026-06-25 19:45:28.799732	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36	94.72.215.137	\N	\N	\N	\N	\N
ea705b24-a1e0-46fb-ac4e-7ec027cdd7c0	c4233153-ba79-4596-a447-7c979056fd33	2026-07-06 12:38:07.309283+00	2026-07-06 12:38:07.309283+00	\N	aal1	\N	\N	Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Mobile Safari/537.36 EdgA/149.0.0.0	62.64.219.11	\N	\N	\N	\N	\N
c8509f20-2242-4104-bd74-65cc072a4d49	c4233153-ba79-4596-a447-7c979056fd33	2026-07-06 12:38:55.879428+00	2026-07-06 12:38:55.879428+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36	62.64.219.10	\N	\N	\N	\N	\N
30f26583-43d3-4d56-a1b2-c155a8741073	c4233153-ba79-4596-a447-7c979056fd33	2026-07-06 17:20:59.175127+00	2026-07-08 07:29:10.081198+00	\N	aal1	\N	2026-07-08 07:29:10.081089	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/148.0.0.0 Safari/537.36	88.97.210.35	\N	\N	\N	\N	\N
2960e7c8-69d2-40aa-b027-d5e500e73c83	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	2026-08-25 18:38:59.188102+00	2026-08-25 18:38:59.188102+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Safari/605.1.15	104.28.30.127	\N	\N	\N	\N	\N
e40dacbd-2800-42e1-91e0-77fa61d65ef7	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	2026-08-25 18:38:59.88272+00	2026-08-25 18:38:59.88272+00	\N	aal1	\N	\N	Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.6 Safari/605.1.15	104.28.30.127	\N	\N	\N	\N	\N
cdc14a7a-d336-4054-9540-21490fa753f5	be20a8d7-d8e8-457e-bc94-828592ac9ab3	2026-06-26 07:08:38.673768+00	2026-09-16 19:38:24.987892+00	\N	aal1	\N	2026-09-16 19:38:24.986904	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36	81.141.110.69	\N	\N	\N	\N	\N
46916489-8342-4870-9444-01b7bbf98b36	36252019-fac0-4514-91df-23eb5fdc3a5f	2026-09-04 12:31:15.478532+00	2026-09-04 12:31:15.478532+00	\N	aal1	\N	\N	Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/152.0.0.0 Safari/537.36	109.148.219.208	\N	\N	\N	\N	\N
\.


--
-- Data for Name: mfa_amr_claims; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_amr_claims" ("session_id", "created_at", "updated_at", "authentication_method", "id") FROM stdin;
46916489-8342-4870-9444-01b7bbf98b36	2026-09-04 12:31:15.571581+00	2026-09-04 12:31:15.571581+00	password	981a3c76-cb60-47e2-b705-a340a5920e38
6b4434c7-6b4e-4235-a70d-d0946b839613	2026-06-05 16:41:44.250691+00	2026-06-05 16:41:44.250691+00	password	56abd1ef-0dc3-4849-89db-01d8725c2205
e17ae44e-7a67-408e-a062-9de65e3d7537	2026-06-23 20:19:44.789709+00	2026-06-23 20:19:44.789709+00	otp	9a807470-19d5-4fb5-9f81-4f19f810b33d
f0e1ddfc-1010-4073-82c4-19e2782c7495	2026-06-23 20:20:18.451263+00	2026-06-23 20:20:18.451263+00	password	19f06e27-5177-4e6c-99b5-aae66949aa3f
9c3c73e6-6fc4-47f2-ac74-1435d035446b	2026-06-09 09:29:33.586246+00	2026-06-09 09:29:33.586246+00	password	1695653c-4f12-4d72-96ac-509a88c2b466
34c5b6d7-d524-4153-8b7e-cd7c07ed2da1	2026-06-09 14:28:11.135831+00	2026-06-09 14:28:11.135831+00	password	7d5fc1b6-05b2-4acd-810a-b584d1cdb643
3e251737-1efa-4403-93ae-622a256973f0	2026-06-24 07:34:26.210016+00	2026-06-24 07:34:26.210016+00	otp	8a142ca5-1941-4c61-9ace-03aedd252f31
dc8fefbb-0367-4285-8acf-86e0f26301c5	2026-06-24 07:34:36.484453+00	2026-06-24 07:34:36.484453+00	password	317d8cb4-a24a-4247-83e1-6e3823a1ccf7
ec3e22ea-ae51-4958-b97b-41bddfae478c	2026-06-24 13:33:29.753013+00	2026-06-24 13:33:29.753013+00	otp	4b0a17d5-6123-46be-bb73-b936472486a4
a70d4080-4500-4ca2-adc2-eb9972badc4d	2026-06-24 13:33:31.755082+00	2026-06-24 13:33:31.755082+00	password	4711943a-8f56-4ea8-a519-97b1697f1d8d
e0a484fa-8e54-4822-8eb0-046c39bf5b40	2026-07-01 09:41:24.617519+00	2026-07-01 09:41:24.617519+00	password	45b24007-bd5b-44e9-add1-fae8fca8ecb8
3f2211d8-f158-4871-aa2a-bafb59af8896	2026-07-01 19:53:54.989264+00	2026-07-01 19:53:54.989264+00	password	8f7b62cd-775c-4c4f-9717-72de7fd33de5
c3fdd87f-0415-4077-86b3-15022ec9af5f	2026-09-22 15:06:20.750265+00	2026-09-22 15:06:20.750265+00	password	d8860287-dde5-47bf-824c-94edcf930887
62524521-8963-4485-bf25-e20142929fbf	2026-09-22 15:06:22.848096+00	2026-09-22 15:06:22.848096+00	password	6771d0fd-69a1-4a51-adb3-c2b5f82e7426
059170df-6abe-40d1-a717-9e951ee4f5a1	2026-08-22 18:52:12.057215+00	2026-08-22 18:52:12.057215+00	password	de547a5b-0ef4-48ff-a935-3e2ea4765f0d
ea705b24-a1e0-46fb-ac4e-7ec027cdd7c0	2026-07-06 12:38:07.343808+00	2026-07-06 12:38:07.343808+00	otp	771b8f22-a842-4233-8dd6-8d38c52905d4
c8509f20-2242-4104-bd74-65cc072a4d49	2026-07-06 12:38:55.903212+00	2026-07-06 12:38:55.903212+00	password	d7e7b52c-5bf4-414f-b87b-45db20895732
0baad439-ac66-4343-8f1c-2f458ac87456	2026-06-24 21:28:40.810906+00	2026-06-24 21:28:40.810906+00	password	e17b86b9-5f88-4384-814f-af35963d615b
30f26583-43d3-4d56-a1b2-c155a8741073	2026-07-06 17:20:59.258772+00	2026-07-06 17:20:59.258772+00	password	24bb1bdc-fdc1-4f3f-a371-da9fe21ff67e
5401fcff-a126-4078-a1c7-a6a5e9d76c77	2026-07-06 20:23:36.84307+00	2026-07-06 20:23:36.84307+00	password	216cfe86-1efb-4f66-91db-5ba7b56c04e3
cdc14a7a-d336-4054-9540-21490fa753f5	2026-06-26 07:08:38.717828+00	2026-06-26 07:08:38.717828+00	password	70e9b734-e8ed-47de-9985-b02fb052be8e
c44cca65-d3ad-4981-8534-e2e0de7c99d0	2026-06-03 07:44:51.651985+00	2026-06-03 07:44:51.651985+00	otp	4827a23d-9d1d-4d7f-973a-2cfd213de188
7cfc8870-0dd0-4970-bd6f-b3aad7ef39a9	2026-06-03 07:45:05.616104+00	2026-06-03 07:45:05.616104+00	password	b7422b50-8b59-4efe-aca6-7574eb63cd2e
ae6e6ea6-5d7a-401f-bfa4-c252bf613f56	2026-07-10 13:25:10.087749+00	2026-07-10 13:25:10.087749+00	password	9d047828-dfc7-4d19-bc4a-68823f202143
26c54547-be28-4e89-91a6-c21d1237b820	2026-06-04 13:06:51.398272+00	2026-06-04 13:06:51.398272+00	otp	87347049-561f-4ca1-8dbc-3a36b2db3464
c92633b1-49fe-4b1b-9957-8b230742234e	2026-06-04 13:06:54.777639+00	2026-06-04 13:06:54.777639+00	password	cb97b4ad-8cdd-4002-8f5f-b14d520ab791
27743ecc-d21e-4528-a7bb-19b0c6ac0b22	2026-06-04 18:44:36.162699+00	2026-06-04 18:44:36.162699+00	otp	ecd0d3b6-996f-4104-9b6d-412e72465a07
bdefc281-884d-4f38-a057-d18b756d7bcd	2026-06-04 18:45:16.432099+00	2026-06-04 18:45:16.432099+00	password	a9a8c83d-1d13-4442-b28c-b0a3b1025879
f9aa7fbe-9925-4d59-ac5e-1a6d1ca7ac0f	2026-06-26 10:30:22.886443+00	2026-06-26 10:30:22.886443+00	otp	e4de246e-61c2-49fa-ba65-fe715c5c4eba
2960e7c8-69d2-40aa-b027-d5e500e73c83	2026-08-25 18:38:59.273585+00	2026-08-25 18:38:59.273585+00	password	d07ae005-bc70-4eb6-a8f6-78f79016ada7
e40dacbd-2800-42e1-91e0-77fa61d65ef7	2026-08-25 18:38:59.88555+00	2026-08-25 18:38:59.88555+00	password	a8efb68b-1f4b-448b-9712-91cbb296b194
19e898d3-d68a-4ff9-8c4c-c1af00c4dcfa	2026-06-26 19:28:43.809577+00	2026-06-26 19:28:43.809577+00	otp	fe23ea35-0e77-4678-b9ed-a06899184751
d21c89e0-b361-464c-a4cf-5a063e2454ed	2026-06-26 19:46:49.321161+00	2026-06-26 19:46:49.321161+00	password	32a822e3-414b-49ee-8695-9b45f7ad5424
e01b3ab1-9120-44b4-b8f2-2644e640b97c	2026-06-26 19:54:34.81286+00	2026-06-26 19:54:34.81286+00	password	38662f0a-9f06-4d34-8451-f49db998dfc4
db97d4ac-8c99-4817-aceb-791f8ed49c0f	2026-06-26 21:38:14.190098+00	2026-06-26 21:38:14.190098+00	password	370a652a-e551-48ee-bc20-6aa944d0c854
826e623b-ea48-4b4f-8ac2-7f312b3d5b01	2026-06-27 10:02:39.467075+00	2026-06-27 10:02:39.467075+00	otp	7a9c6c96-6e2f-4a58-a1c2-09b2e1004e83
481ae52d-5570-481d-abec-0e505fe9ea67	2026-06-28 16:25:26.544484+00	2026-06-28 16:25:26.544484+00	password	f150a249-f167-4ff1-b858-85f3e02bab7b
\.


--
-- Data for Name: mfa_factors; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_factors" ("id", "user_id", "friendly_name", "factor_type", "status", "created_at", "updated_at", "secret", "phone", "last_challenged_at", "web_authn_credential", "web_authn_aaguid", "last_webauthn_challenge_data") FROM stdin;
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_challenges" ("id", "factor_id", "created_at", "verified_at", "ip_address", "otp_code", "web_authn_session_data") FROM stdin;
\.


--
-- Data for Name: mfa_recovery_code_sets; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_recovery_code_sets" ("id", "user_id", "mfa_factor_id", "failed_verification_count", "verification_locked_until", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: mfa_recovery_codes; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."mfa_recovery_codes" ("id", "mfa_recovery_code_set_id", "code_hash", "consumed_at", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_authorizations; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_authorizations" ("id", "authorization_id", "client_id", "user_id", "redirect_uri", "scope", "state", "resource", "code_challenge", "code_challenge_method", "response_type", "status", "authorization_code", "created_at", "expires_at", "approved_at", "nonce") FROM stdin;
\.


--
-- Data for Name: oauth_client_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_client_states" ("id", "provider_type", "code_verifier", "created_at") FROM stdin;
\.


--
-- Data for Name: oauth_consents; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."oauth_consents" ("id", "user_id", "client_id", "scopes", "granted_at", "revoked_at") FROM stdin;
\.


--
-- Data for Name: one_time_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."one_time_tokens" ("id", "user_id", "token_type", "token_hash", "relates_to", "created_at", "updated_at", "expires_at") FROM stdin;
0f862ea0-af0b-44e0-9a5a-5ac563c137e5	33206a78-c324-45b5-a09b-ecd6d3a89052	recovery_token	acae3ab740ad93dcae19ab978fa34149710789425d5465dae294878b	jomobi@hotmail.co.uk	2026-06-26 10:11:03.454635	2026-06-26 10:11:03.454635	\N
060cdc60-d347-4904-8327-04fec88425d9	8a9a9cc3-91ca-429d-893c-4fca61f02479	recovery_token	ded25e7a4966e84029c1a633260a1964c5520acba936d35a081ad653	ncbobbittent@yahoo.com	2026-06-26 10:13:15.951487	2026-06-26 10:13:15.951487	\N
95c56be4-aa9b-4545-aa2f-5f3ca4db2021	bd7b8095-f9e0-4f3b-8894-a22d061af337	recovery_token	4f336c06f2d299c960c7a0c4380a244847678ec3b371bdfd897e7f81	helen.jennings1@yahoo.co.uk	2026-06-26 10:13:24.24487	2026-06-26 10:13:24.24487	\N
577c60bc-9aba-4df4-9d7f-6e248f8d4280	bd7b8095-f9e0-4f3b-8894-a22d061af337	confirmation_token	355b2169941a9fb3fe01e1cc9dd8f7b3f1a50f9491be0f0ed4dfe4fd	helen.jennings1@yahoo.co.uk	2026-06-02 13:13:32.513978	2026-06-02 13:13:32.513978	\N
96eeba4e-c900-407e-893e-fa74427c9631	8a9a9cc3-91ca-429d-893c-4fca61f02479	confirmation_token	c8d7e1dbcce76609eade6e5b9cdea394a9412ee7150ab1f7538a2520	ncbobbittent@yahoo.com	2026-06-04 11:23:01.32317	2026-06-04 11:23:01.32317	\N
f80a6c3c-c3ef-484f-9248-7a3fbc7ed40d	25c0e60d-93ac-4ba4-a8c3-46c097cdc973	confirmation_token	303b31aec575765592097421b738423a901fa9e739ca4e1e43baf36d	a@example.com	2026-09-15 11:03:04.221749	2026-09-15 11:03:04.221749	\N
9ad701e3-c00a-49c1-9efa-f3abad6b08a8	223c9b39-49e8-4e7b-86e4-59eb1d3e90d8	recovery_token	pkce_fb381a81febdc1bc796493b7697d77e711e9b011b2f5757d65961f08	gladysmabongiwemokebisa@gmail.com	2026-06-05 09:46:59.040584	2026-06-05 09:46:59.040584	\N
2ba5b925-0e8e-4942-b53c-7a67203843f1	baefdd0b-521d-4090-8021-1c39c7614608	confirmation_token	e509e3bb0910b42dabd7e7705b89b6bc21bc281e4abb86efd180ffbb	test1@bookmytherapy.co.uk	2026-09-19 08:03:07.03176	2026-09-19 08:03:07.03176	\N
09a4d340-d66e-48ad-ad2a-510d1705eb04	33206a78-c324-45b5-a09b-ecd6d3a89052	confirmation_token	8a3b136a19132a5d37bfe8d27920df4fdfd44b2d4aa4728a60c7890c	jomobi@hotmail.co.uk	2026-06-24 09:04:33.690078	2026-06-24 09:04:33.690078	\N
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."refresh_tokens" ("instance_id", "id", "token", "user_id", "revoked", "created_at", "updated_at", "parent", "session_id") FROM stdin;
00000000-0000-0000-0000-000000000000	414	etqaun32cg37	889b3064-f9c0-42ea-9800-6cd4d1078f1a	t	2026-06-24 13:33:31.753616+00	2026-06-25 17:10:39.564251+00	\N	a70d4080-4500-4ca2-adc2-eb9972badc4d
00000000-0000-0000-0000-000000000000	655	jtlsx46kwzbo	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-13 10:25:04.309252+00	2026-07-13 12:34:58.342504+00	5hrc7gds2agl	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	592	g5n457bxtajn	9a796c66-37fe-4446-b279-468fb6ac3dfd	t	2026-07-05 10:08:17.690391+00	2026-07-16 13:01:48.026698+00	fq5rsikcleca	e0a484fa-8e54-4822-8eb0-046c39bf5b40
00000000-0000-0000-0000-000000000000	589	z6sygklhbcpe	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-03 20:55:28.322906+00	2026-07-06 13:25:21.729278+00	5i75377lth2g	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	362	kcf5vs7x2ozx	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-19 19:54:39.697117+00	2026-06-21 13:20:11.441173+00	xx7dkbes6smr	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	288	dejmrjuhwbju	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-10 20:48:39.78874+00	2026-06-15 13:33:15.51551+00	d2ksbohnufky	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	271	d2ksbohnufky	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-09 17:34:55.657867+00	2026-06-10 20:48:39.77133+00	xxygvrhjejfw	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	327	4uteh35ugm2u	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-15 13:33:15.531886+00	2026-06-15 14:31:27.88805+00	dejmrjuhwbju	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	373	bwp3vmfrk662	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-21 13:20:11.449674+00	2026-06-22 14:35:28.056851+00	kcf5vs7x2ozx	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	328	3pkofmb6bdgw	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-15 14:31:27.892519+00	2026-06-15 15:29:35.235442+00	4uteh35ugm2u	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	330	67o5kchcskby	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-15 15:29:35.247037+00	2026-06-15 18:20:31.946285+00	3pkofmb6bdgw	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	211	bvexabg4bdca	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	f	2026-06-03 07:44:51.636271+00	2026-06-03 07:44:51.636271+00	\N	c44cca65-d3ad-4981-8534-e2e0de7c99d0
00000000-0000-0000-0000-000000000000	212	fhy4rhjv7csf	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	f	2026-06-03 07:45:05.614701+00	2026-06-03 07:45:05.614701+00	\N	7cfc8870-0dd0-4970-bd6f-b3aad7ef39a9
00000000-0000-0000-0000-000000000000	235	fkg4ze3vmbuv	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-05 16:37:02.747415+00	2026-06-08 10:12:21.723719+00	n4x7n6erjvds	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	332	i3bw67b7fjsi	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-15 18:20:31.954579+00	2026-06-15 19:18:46.23784+00	67o5kchcskby	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	333	f2rlu76sn3q3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-15 19:18:46.2527+00	2026-06-15 20:54:45.394522+00	i3bw67b7fjsi	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	255	qrwkbovyqdry	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-08 10:12:21.730008+00	2026-06-08 12:47:38.265657+00	fkg4ze3vmbuv	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	219	7igp2u5mog6c	be20a8d7-d8e8-457e-bc94-828592ac9ab3	f	2026-06-04 13:06:51.381756+00	2026-06-04 13:06:51.381756+00	\N	26c54547-be28-4e89-91a6-c21d1237b820
00000000-0000-0000-0000-000000000000	220	pm6essq6clel	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-04 13:06:54.776216+00	2026-06-04 17:08:39.967963+00	\N	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	224	ttqmqowwjlqm	e6e44d92-1a53-4123-9aec-c05dd825f974	f	2026-06-04 18:44:36.156984+00	2026-06-04 18:44:36.156984+00	\N	27743ecc-d21e-4528-a7bb-19b0c6ac0b22
00000000-0000-0000-0000-000000000000	225	72mrizh2ij3o	e6e44d92-1a53-4123-9aec-c05dd825f974	f	2026-06-04 18:45:16.430572+00	2026-06-04 18:45:16.430572+00	\N	bdefc281-884d-4f38-a057-d18b756d7bcd
00000000-0000-0000-0000-000000000000	263	jdwoajma4h7o	e6e44d92-1a53-4123-9aec-c05dd825f974	f	2026-06-09 09:29:33.542563+00	2026-06-09 09:29:33.542563+00	\N	9c3c73e6-6fc4-47f2-ac74-1435d035446b
00000000-0000-0000-0000-000000000000	334	kngrmh6u7fol	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-15 20:54:45.41745+00	2026-06-16 11:19:48.324382+00	f2rlu76sn3q3	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	376	2ehksvxv3kke	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-22 14:35:28.064307+00	2026-06-23 18:51:53.446832+00	bwp3vmfrk662	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	266	ro5q6ndiliqw	be20a8d7-d8e8-457e-bc94-828592ac9ab3	f	2026-06-09 14:28:11.115671+00	2026-06-09 14:28:11.115671+00	\N	34c5b6d7-d524-4153-8b7e-cd7c07ed2da1
00000000-0000-0000-0000-000000000000	389	szqqv2z7k6xs	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-23 18:51:53.453168+00	2026-06-23 19:56:39.09446+00	2ehksvxv3kke	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	223	ia7lfqf7afwn	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-04 17:08:39.989137+00	2026-06-05 12:31:52.380977+00	pm6essq6clel	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	233	32bt2yjpo3tw	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-05 12:31:52.403229+00	2026-06-05 13:30:24.970799+00	ia7lfqf7afwn	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	391	rymp3lkxfd3e	a0296447-63d6-4dd6-9924-55cccc0f0a29	f	2026-06-23 20:19:44.785324+00	2026-06-23 20:19:44.785324+00	\N	e17ae44e-7a67-408e-a062-9de65e3d7537
00000000-0000-0000-0000-000000000000	234	n4x7n6erjvds	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-05 13:30:24.986856+00	2026-06-05 16:37:02.72442+00	32bt2yjpo3tw	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	392	ypx44kvzmigz	a0296447-63d6-4dd6-9924-55cccc0f0a29	f	2026-06-23 20:20:18.449772+00	2026-06-23 20:20:18.449772+00	\N	f0e1ddfc-1010-4073-82c4-19e2782c7495
00000000-0000-0000-0000-000000000000	343	bbftquh6zriu	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-16 11:19:48.338738+00	2026-06-16 18:35:41.026002+00	kngrmh6u7fol	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	390	5r2tsialpyln	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-23 19:56:39.111408+00	2026-06-23 21:09:48.221607+00	szqqv2z7k6xs	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	259	xxygvrhjejfw	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-08 12:47:38.271013+00	2026-06-09 17:34:55.650872+00	qrwkbovyqdry	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	236	yln75rwrdioz	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-05 16:41:44.237444+00	2026-06-09 18:07:50.449167+00	\N	6b4434c7-6b4e-4235-a70d-d0946b839613
00000000-0000-0000-0000-000000000000	347	gzlcw6wztbyp	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-16 18:35:41.04299+00	2026-06-17 21:30:19.626599+00	bbftquh6zriu	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	272	72kglwxao6hu	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-09 18:07:50.456984+00	2026-06-09 19:56:25.732234+00	yln75rwrdioz	6b4434c7-6b4e-4235-a70d-d0946b839613
00000000-0000-0000-0000-000000000000	350	5ozamhfysfoq	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-17 21:30:19.638988+00	2026-06-18 06:57:17.241332+00	gzlcw6wztbyp	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	274	ptpdwylltmkb	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-09 19:56:25.751557+00	2026-06-09 20:54:49.976809+00	72kglwxao6hu	6b4434c7-6b4e-4235-a70d-d0946b839613
00000000-0000-0000-0000-000000000000	276	gkzcp6xbdltj	be20a8d7-d8e8-457e-bc94-828592ac9ab3	f	2026-06-09 20:54:49.991079+00	2026-06-09 20:54:49.991079+00	ptpdwylltmkb	6b4434c7-6b4e-4235-a70d-d0946b839613
00000000-0000-0000-0000-000000000000	352	hnur7rzwerbr	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-18 06:57:17.253438+00	2026-06-18 19:37:59.216323+00	5ozamhfysfoq	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	406	buueeriopvjy	2e01e063-789f-4c1e-ad09-180781c35411	f	2026-06-24 07:34:26.207636+00	2026-06-24 07:34:26.207636+00	\N	3e251737-1efa-4403-93ae-622a256973f0
00000000-0000-0000-0000-000000000000	407	qqeab4u4edw5	2e01e063-789f-4c1e-ad09-180781c35411	t	2026-06-24 07:34:36.482986+00	2026-06-24 10:26:54.337572+00	\N	dc8fefbb-0367-4285-8acf-86e0f26301c5
00000000-0000-0000-0000-000000000000	411	2epescg7yo6z	2e01e063-789f-4c1e-ad09-180781c35411	f	2026-06-24 10:26:54.342481+00	2026-06-24 10:26:54.342481+00	qqeab4u4edw5	dc8fefbb-0367-4285-8acf-86e0f26301c5
00000000-0000-0000-0000-000000000000	395	4tluylqo2kou	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-23 21:09:48.225388+00	2026-06-24 12:45:47.301633+00	5r2tsialpyln	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	355	xx7dkbes6smr	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-18 19:37:59.222429+00	2026-06-19 19:54:39.68187+00	hnur7rzwerbr	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	413	i4p7lnyoqawr	889b3064-f9c0-42ea-9800-6cd4d1078f1a	f	2026-06-24 13:33:29.746962+00	2026-06-24 13:33:29.746962+00	\N	ec3e22ea-ae51-4958-b97b-41bddfae478c
00000000-0000-0000-0000-000000000000	412	6qvegot64jil	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-24 12:45:47.319465+00	2026-06-24 13:48:46.892071+00	4tluylqo2kou	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	415	3abcaenlo537	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-24 13:48:46.897593+00	2026-06-24 14:47:04.329434+00	6qvegot64jil	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	416	joa3r7zf4w3a	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-24 14:47:04.337182+00	2026-06-24 17:29:13.472308+00	3abcaenlo537	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	487	gxh6q7myzlm3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-27 10:43:27.120466+00	2026-06-27 12:17:32.411355+00	unhny3cz55et	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	984	i45pknjh4umy	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-06 15:37:53.565735+00	2026-09-06 18:05:29.296233+00	5lhc5lthuljl	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	419	ckkmu5a5vden	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-24 17:29:13.478368+00	2026-06-24 18:48:19.032341+00	joa3r7zf4w3a	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	432	xdbwdr23unbk	be20a8d7-d8e8-457e-bc94-828592ac9ab3	f	2026-06-24 18:48:19.038767+00	2026-06-24 18:48:19.038767+00	ckkmu5a5vden	c92633b1-49fe-4b1b-9957-8b230742234e
00000000-0000-0000-0000-000000000000	524	vinvirccc2ju	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-29 12:24:31.311876+00	2026-06-29 20:02:33.746494+00	ilijpsqcfoic	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	561	fq5rsikcleca	9a796c66-37fe-4446-b279-468fb6ac3dfd	t	2026-07-01 12:31:47.11853+00	2026-07-05 10:08:17.67039+00	e5b4lju5whkf	e0a484fa-8e54-4822-8eb0-046c39bf5b40
00000000-0000-0000-0000-000000000000	597	a6vaizk2dlc7	c4233153-ba79-4596-a447-7c979056fd33	f	2026-07-06 12:38:07.325643+00	2026-07-06 12:38:07.325643+00	\N	ea705b24-a1e0-46fb-ac4e-7ec027cdd7c0
00000000-0000-0000-0000-000000000000	435	bniijht6nl6x	36252019-fac0-4514-91df-23eb5fdc3a5f	f	2026-06-24 21:28:40.789051+00	2026-06-24 21:28:40.789051+00	\N	0baad439-ac66-4343-8f1c-2f458ac87456
00000000-0000-0000-0000-000000000000	598	6c5wqlekrpne	c4233153-ba79-4596-a447-7c979056fd33	f	2026-07-06 12:38:55.896692+00	2026-07-06 12:38:55.896692+00	\N	c8509f20-2242-4104-bd74-65cc072a4d49
00000000-0000-0000-0000-000000000000	1070	qzrgcew2tiso	be20a8d7-d8e8-457e-bc94-828592ac9ab3	f	2026-09-16 19:38:24.957048+00	2026-09-16 19:38:24.957048+00	yce2zvuwp3mk	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	602	yk62esg24tzj	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-06 17:48:04.853671+00	2026-07-06 19:49:50.249745+00	3m5exqfb7xdc	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	604	4kbe4e4yep4p	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-06 19:49:50.269495+00	2026-07-06 20:55:48.043148+00	yk62esg24tzj	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	606	52zshic6d2ht	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-06 20:55:48.049765+00	2026-07-07 12:59:38.305128+00	4kbe4e4yep4p	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	445	4plod23x7qg7	889b3064-f9c0-42ea-9800-6cd4d1078f1a	t	2026-06-25 17:10:39.572968+00	2026-06-25 19:45:28.748586+00	etqaun32cg37	a70d4080-4500-4ca2-adc2-eb9972badc4d
00000000-0000-0000-0000-000000000000	446	3itejz4g3nlw	889b3064-f9c0-42ea-9800-6cd4d1078f1a	f	2026-06-25 19:45:28.768905+00	2026-06-25 19:45:28.768905+00	4plod23x7qg7	a70d4080-4500-4ca2-adc2-eb9972badc4d
00000000-0000-0000-0000-000000000000	536	sictjlfmllqb	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-29 20:02:33.763573+00	2026-06-30 19:56:02.401777+00	vinvirccc2ju	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	553	xwnr3cisbmtr	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-30 19:56:02.421786+00	2026-06-30 20:58:27.707804+00	sictjlfmllqb	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	1083	jo5sl6jquk4y	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-17 20:07:26.747742+00	2026-09-18 13:04:07.683107+00	caakxpew6jdi	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	555	5nwjnb3ms5ef	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-30 20:58:27.716501+00	2026-07-01 09:29:58.404547+00	xwnr3cisbmtr	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	513	e22xtobgiczq	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-28 16:25:26.512438+00	2026-06-28 17:23:25.423662+00	\N	481ae52d-5570-481d-abec-0e505fe9ea67
00000000-0000-0000-0000-000000000000	514	4cpy7vigyxtf	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-28 17:23:25.441619+00	2026-06-28 18:23:33.829023+00	e22xtobgiczq	481ae52d-5570-481d-abec-0e505fe9ea67
00000000-0000-0000-0000-000000000000	515	6bg42a7fplmv	be20a8d7-d8e8-457e-bc94-828592ac9ab3	f	2026-06-28 18:23:33.834878+00	2026-06-28 18:23:33.834878+00	4cpy7vigyxtf	481ae52d-5570-481d-abec-0e505fe9ea67
00000000-0000-0000-0000-000000000000	559	4zj53zwziqra	9a796c66-37fe-4446-b279-468fb6ac3dfd	t	2026-07-01 09:41:24.610531+00	2026-07-01 10:48:06.12446+00	\N	e0a484fa-8e54-4822-8eb0-046c39bf5b40
00000000-0000-0000-0000-000000000000	461	py2czvo6zzhd	1ef8cb01-2813-4203-b05d-52ad47f7c8de	t	2026-06-26 10:30:22.882821+00	2026-06-26 11:29:40.747428+00	\N	f9aa7fbe-9925-4d59-ac5e-1a6d1ca7ac0f
00000000-0000-0000-0000-000000000000	1088	oox3ftc2z5dn	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-18 13:04:07.706121+00	2026-09-19 11:58:23.806473+00	jo5sl6jquk4y	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	450	pe77qbaogm6p	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-26 07:08:38.70098+00	2026-06-26 11:58:50.282549+00	\N	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	560	e5b4lju5whkf	9a796c66-37fe-4446-b279-468fb6ac3dfd	t	2026-07-01 10:48:06.132593+00	2026-07-01 12:31:47.090418+00	4zj53zwziqra	e0a484fa-8e54-4822-8eb0-046c39bf5b40
00000000-0000-0000-0000-000000000000	464	pnfh37nblwui	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-26 11:58:50.287944+00	2026-06-26 15:37:05.715316+00	pe77qbaogm6p	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	1101	lh4mzgoj7ivw	c4233153-ba79-4596-a447-7c979056fd33	f	2026-09-19 16:55:02.103499+00	2026-09-19 16:55:02.103499+00	6asfhqfb6bst	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	556	yhnzeijw6qtv	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-01 09:29:58.424115+00	2026-07-01 18:57:52.345083+00	5nwjnb3ms5ef	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	467	usn5h2rjotdh	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-26 15:37:05.724196+00	2026-06-26 17:07:35.537735+00	pnfh37nblwui	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	566	ecuurmbmhy4k	9a796c66-37fe-4446-b279-468fb6ac3dfd	t	2026-07-01 19:53:54.965571+00	2026-07-02 07:51:09.047354+00	\N	3f2211d8-f158-4871-aa2a-bafb59af8896
00000000-0000-0000-0000-000000000000	463	q4t34ksfreoq	1ef8cb01-2813-4203-b05d-52ad47f7c8de	t	2026-06-26 11:29:40.758875+00	2026-06-26 17:49:15.810178+00	py2czvo6zzhd	f9aa7fbe-9925-4d59-ac5e-1a6d1ca7ac0f
00000000-0000-0000-0000-000000000000	471	3g5oz5eolxis	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-26 17:07:35.553076+00	2026-06-26 18:05:36.173886+00	usn5h2rjotdh	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	567	jysmpqidqc6z	9a796c66-37fe-4446-b279-468fb6ac3dfd	t	2026-07-02 07:51:09.071329+00	2026-07-02 09:07:11.708106+00	ecuurmbmhy4k	3f2211d8-f158-4871-aa2a-bafb59af8896
00000000-0000-0000-0000-000000000000	474	pn45m5wmkky3	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	f	2026-06-26 19:28:43.805227+00	2026-06-26 19:28:43.805227+00	\N	19e898d3-d68a-4ff9-8c4c-c1af00c4dcfa
00000000-0000-0000-0000-000000000000	568	ytncbvlgprya	9a796c66-37fe-4446-b279-468fb6ac3dfd	f	2026-07-02 09:07:11.719473+00	2026-07-02 09:07:11.719473+00	jysmpqidqc6z	3f2211d8-f158-4871-aa2a-bafb59af8896
00000000-0000-0000-0000-000000000000	491	ilijpsqcfoic	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-27 12:17:32.426934+00	2026-06-29 12:24:31.293076+00	gxh6q7myzlm3	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	477	epnamwskfylz	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	f	2026-06-26 19:46:49.316106+00	2026-06-26 19:46:49.316106+00	\N	d21c89e0-b361-464c-a4cf-5a063e2454ed
00000000-0000-0000-0000-000000000000	472	xkptmgjf6eqv	1ef8cb01-2813-4203-b05d-52ad47f7c8de	t	2026-06-26 17:49:15.814835+00	2026-06-26 20:39:03.444483+00	q4t34ksfreoq	f9aa7fbe-9925-4d59-ac5e-1a6d1ca7ac0f
00000000-0000-0000-0000-000000000000	479	ukqjm5gli7kl	1ef8cb01-2813-4203-b05d-52ad47f7c8de	f	2026-06-26 20:39:03.451836+00	2026-06-26 20:39:03.451836+00	xkptmgjf6eqv	f9aa7fbe-9925-4d59-ac5e-1a6d1ca7ac0f
00000000-0000-0000-0000-000000000000	478	dtw55vwgfpws	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	t	2026-06-26 19:54:34.791811+00	2026-06-26 21:37:11.52626+00	\N	e01b3ab1-9120-44b4-b8f2-2644e640b97c
00000000-0000-0000-0000-000000000000	480	qjhy5phovmew	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	f	2026-06-26 21:37:11.545329+00	2026-06-26 21:37:11.545329+00	dtw55vwgfpws	e01b3ab1-9120-44b4-b8f2-2644e640b97c
00000000-0000-0000-0000-000000000000	481	h5gip7krtmdt	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	f	2026-06-26 21:38:14.182864+00	2026-06-26 21:38:14.182864+00	\N	db97d4ac-8c99-4817-aceb-791f8ed49c0f
00000000-0000-0000-0000-000000000000	473	5tpbn5m5tzju	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-26 18:05:36.181764+00	2026-06-27 09:43:14.350377+00	3g5oz5eolxis	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	486	tzlejcixjqgl	5711310a-b42c-4b02-8420-c0818e98d748	f	2026-06-27 10:02:39.464434+00	2026-06-27 10:02:39.464434+00	\N	826e623b-ea48-4b4f-8ac2-7f312b3d5b01
00000000-0000-0000-0000-000000000000	484	unhny3cz55et	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-06-27 09:43:14.365019+00	2026-06-27 10:43:27.106821+00	5tpbn5m5tzju	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	565	xckphtos7v3n	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-01 18:57:52.365222+00	2026-07-02 18:20:40.679535+00	yhnzeijw6qtv	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	578	q4eey7qhyuzo	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-02 20:58:44.794899+00	2026-07-03 15:34:52.815993+00	kynokcqahdft	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	650	5hrc7gds2agl	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-12 08:22:40.545086+00	2026-07-13 10:25:04.30024+00	sk5x7sqlwbfr	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	588	5i75377lth2g	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-03 15:34:52.834225+00	2026-07-03 20:55:28.305053+00	q4eey7qhyuzo	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	576	kynokcqahdft	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-02 18:20:40.68526+00	2026-07-02 20:58:44.77611+00	xckphtos7v3n	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	657	2tcb6ap33xll	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-13 12:34:58.346043+00	2026-07-13 15:20:22.030667+00	jtlsx46kwzbo	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	988	grpmnh7h2n4f	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-07 08:10:56.358477+00	2026-09-07 09:21:23.199965+00	t4qlkwsjmn55	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	658	md4xho4vodak	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-13 15:20:22.046659+00	2026-07-13 16:45:15.236423+00	2tcb6ap33xll	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	599	3m5exqfb7xdc	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-06 13:25:21.742936+00	2026-07-06 17:48:04.840511+00	z6sygklhbcpe	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	601	hzunelrdwsvo	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-06 17:20:59.220016+00	2026-07-06 18:30:00.029835+00	\N	30f26583-43d3-4d56-a1b2-c155a8741073
00000000-0000-0000-0000-000000000000	660	oizmvaurdd5a	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-13 16:45:15.248375+00	2026-07-13 18:45:18.383157+00	md4xho4vodak	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	651	tzzzbcfvhsgc	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-12 18:58:12.685083+00	2026-07-13 20:07:06.604734+00	ng2v2coerwgd	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	605	grfdhtttomlb	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-06 20:23:36.820922+00	2026-07-07 08:07:24.352693+00	\N	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	662	b2gt3arghumr	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-13 18:45:18.393544+00	2026-07-14 07:09:27.756189+00	oizmvaurdd5a	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	608	4kvkbrjtuimu	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-07 08:07:24.36701+00	2026-07-07 10:33:43.780701+00	grfdhtttomlb	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	726	zmuxaaqiiswx	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-22 18:34:34.968182+00	2026-07-24 07:51:58.940294+00	4p5y66npjdog	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	645	uesko7oemscd	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-10 13:25:10.075437+00	2026-07-14 10:13:37.405658+00	\N	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	609	genry6jiknrv	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-07 10:33:43.794444+00	2026-07-07 12:05:58.498064+00	4kvkbrjtuimu	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	614	lrwtqvtjzez3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-07 12:59:38.32158+00	2026-07-07 21:21:13.977735+00	52zshic6d2ht	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	613	yvvglwaexfoj	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-07 12:05:58.504568+00	2026-07-08 05:51:01.986151+00	genry6jiknrv	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	666	k2orp2kfwmhu	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-14 10:13:37.415678+00	2026-07-14 12:45:19.605519+00	uesko7oemscd	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	603	3ao4ionxqbie	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-06 18:30:00.037843+00	2026-07-08 07:29:10.054347+00	hzunelrdwsvo	30f26583-43d3-4d56-a1b2-c155a8741073
00000000-0000-0000-0000-000000000000	617	n2xbedvsgjl2	c4233153-ba79-4596-a447-7c979056fd33	f	2026-07-08 07:29:10.062322+00	2026-07-08 07:29:10.062322+00	3ao4ionxqbie	30f26583-43d3-4d56-a1b2-c155a8741073
00000000-0000-0000-0000-000000000000	616	2zyv7mcegx6s	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-08 05:51:02.002845+00	2026-07-08 08:52:06.894751+00	yvvglwaexfoj	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	618	z7mjjlcyv5hl	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-08 08:52:06.902165+00	2026-07-08 09:50:23.523729+00	2zyv7mcegx6s	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	664	phki6gq7bq7r	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-14 07:09:27.774352+00	2026-07-14 16:38:49.375677+00	b2gt3arghumr	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	615	uvuztw37c4jb	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-07 21:21:13.990328+00	2026-07-08 10:04:47.816104+00	lrwtqvtjzez3	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	670	rz6izudz3o3v	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-14 16:38:49.389679+00	2026-07-14 17:55:15.356563+00	phki6gq7bq7r	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	663	drt2wn63lgfi	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-13 20:07:06.615073+00	2026-07-14 20:50:34.444698+00	tzzzbcfvhsgc	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	620	7myeyfdfq56k	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-08 10:04:47.82767+00	2026-07-08 11:47:34.628327+00	uvuztw37c4jb	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	671	y6pvesxmxcdw	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-14 17:55:15.364111+00	2026-07-15 07:36:09.970064+00	rz6izudz3o3v	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	669	k2jnoyzntsqa	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-14 12:45:19.622123+00	2026-07-15 09:14:56.196252+00	k2orp2kfwmhu	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	619	pvibdh7wddty	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-08 09:50:23.540712+00	2026-07-08 14:37:26.570981+00	z7mjjlcyv5hl	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	674	5joqqio7zn3k	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-15 09:14:56.213786+00	2026-07-16 08:00:35.663639+00	k2jnoyzntsqa	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	627	ll2p2ruz2cdy	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-08 14:37:26.589708+00	2026-07-08 18:21:09.411262+00	pvibdh7wddty	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	623	v55sqct2og6v	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-08 11:47:34.645354+00	2026-07-09 13:28:52.995767+00	7myeyfdfq56k	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	676	nwmdngj5u2lf	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-16 08:00:35.686117+00	2026-07-16 14:52:12.804194+00	5joqqio7zn3k	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	634	6j7dkov5gcxh	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-09 13:28:53.013879+00	2026-07-09 20:53:34.872304+00	v55sqct2og6v	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	673	se6dff7uqsip	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-15 07:36:09.988767+00	2026-07-17 14:48:52.144406+00	y6pvesxmxcdw	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	682	7wfvndcmb7kr	9a796c66-37fe-4446-b279-468fb6ac3dfd	t	2026-07-16 13:01:48.033241+00	2026-07-19 16:32:48.510479+00	g5n457bxtajn	e0a484fa-8e54-4822-8eb0-046c39bf5b40
00000000-0000-0000-0000-000000000000	636	msutzedcw2l2	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-09 20:53:34.883008+00	2026-07-10 09:04:10.916541+00	6j7dkov5gcxh	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	672	hyw7qtugw3tl	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-14 20:50:34.462427+00	2026-07-20 18:18:06.858328+00	drt2wn63lgfi	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	639	uyp4siqj7kof	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-10 09:04:10.931023+00	2026-07-10 10:02:34.032822+00	msutzedcw2l2	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	641	2vsturespy3e	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-10 10:02:34.040454+00	2026-07-10 11:01:04.183281+00	uyp4siqj7kof	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	642	3qsm5lnsqrg3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-10 11:01:04.191357+00	2026-07-10 11:59:34.209417+00	2vsturespy3e	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	643	4f67f35quawr	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-10 11:59:34.21888+00	2026-07-10 12:58:04.31604+00	3qsm5lnsqrg3	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	644	2na6zv6mslef	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-10 12:58:04.329857+00	2026-07-10 21:32:59.304269+00	4f67f35quawr	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	630	unq5c654jj2f	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-08 18:21:09.436875+00	2026-07-11 11:57:00.145666+00	ll2p2ruz2cdy	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	648	4ey4uulyhnmm	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-11 11:57:00.160625+00	2026-07-11 13:15:29.296384+00	unq5c654jj2f	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	649	sk5x7sqlwbfr	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-11 13:15:29.305559+00	2026-07-12 08:22:40.525739+00	4ey4uulyhnmm	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	647	ng2v2coerwgd	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-10 21:32:59.322976+00	2026-07-12 18:58:12.665909+00	2na6zv6mslef	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	840	r2ws7fv64krm	be20a8d7-d8e8-457e-bc94-828592ac9ab3	f	2026-08-14 07:27:33.422796+00	2026-08-14 07:27:33.422796+00	4nyq6l4dzqse	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	707	ezyrbefur4w3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-21 11:46:14.39237+00	2026-07-22 11:24:04.347598+00	yqhh2zh76kc6	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	767	tboquzprkfhg	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-29 17:39:24.704565+00	2026-07-31 08:53:04.280504+00	kilidbpkmdna	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	986	yrvitxqyj27s	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-06 18:05:29.312942+00	2026-09-06 20:21:50.308314+00	i45pknjh4umy	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	771	kplp3rooyutw	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-30 08:10:49.881726+00	2026-07-31 10:53:00.571031+00	uah3qis5pohw	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	708	4p5y66npjdog	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-21 17:05:12.346229+00	2026-07-22 18:34:34.954227+00	cz733crfk2qx	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	691	ffkokrq2je7r	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-17 14:48:52.157769+00	2026-07-17 20:38:41.539782+00	se6dff7uqsip	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	777	pgwbjthiuoqx	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-31 08:53:04.29671+00	2026-08-01 17:05:50.926867+00	tboquzprkfhg	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	844	sgofth27iiqn	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-14 14:19:40.124489+00	2026-08-17 08:22:14.291067+00	lggw4xvooy52	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	778	jwwoajjt5oo3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-31 10:53:00.593966+00	2026-08-03 07:11:15.077778+00	kplp3rooyutw	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	781	lc2chjrkmwgn	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-01 17:05:50.947386+00	2026-08-03 11:31:24.627661+00	pgwbjthiuoqx	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	846	a2nbdwtaxs4j	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-15 10:24:03.198765+00	2026-08-20 12:40:20.790822+00	pyu3rt2s3a2w	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	720	ertydgjfuups	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-22 11:24:04.354669+00	2026-07-23 13:22:26.695611+00	ezyrbefur4w3	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	699	o6fxqc3f4ij6	9a796c66-37fe-4446-b279-468fb6ac3dfd	f	2026-07-19 16:32:48.537002+00	2026-07-19 16:32:48.537002+00	7wfvndcmb7kr	e0a484fa-8e54-4822-8eb0-046c39bf5b40
00000000-0000-0000-0000-000000000000	692	n6nyt5fl34ln	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-17 20:38:41.562213+00	2026-07-20 07:32:56.124158+00	ffkokrq2je7r	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	930	vyaylo2o4z6e	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-29 13:14:52.20157+00	2026-08-30 10:02:19.116064+00	xt26p3d6fhf2	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	782	qdml456cvpjb	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-03 07:11:15.106187+00	2026-08-03 19:03:55.633719+00	jwwoajjt5oo3	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	683	4ykdfdpq774u	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-16 14:52:12.82803+00	2026-07-20 11:29:00.972721+00	nwmdngj5u2lf	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	934	voalt6hviouc	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-30 11:00:34.392771+00	2026-08-30 19:01:30.432823+00	yepyhl6l5kmc	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	789	5hic3icsqske	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-03 19:03:55.642249+00	2026-08-03 20:54:13.873845+00	qdml456cvpjb	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	705	7cdbmq7rchqg	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-20 18:18:06.878764+00	2026-07-20 21:00:51.514496+00	hyw7qtugw3tl	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	736	lh27zkzx6aa2	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-24 07:51:58.963185+00	2026-07-24 22:08:52.767276+00	zmuxaaqiiswx	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	706	yqhh2zh76kc6	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-20 21:00:51.530529+00	2026-07-21 11:46:14.370401+00	7cdbmq7rchqg	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	700	cz733crfk2qx	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-20 07:32:56.145696+00	2026-07-21 17:05:12.328661+00	n6nyt5fl34ln	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	790	ohaz5atrkki7	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-03 20:54:13.895012+00	2026-08-04 19:44:43.045332+00	5hic3icsqske	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	738	5ijjdts7ommp	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-24 22:08:52.783961+00	2026-07-25 22:03:23.948893+00	lh27zkzx6aa2	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	791	zttskbnwv7c3	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-04 19:44:43.061271+00	2026-08-04 20:50:55.337592+00	ohaz5atrkki7	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	783	cavoxa57gpps	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-03 11:31:24.644525+00	2026-08-05 11:28:52.862583+00	lc2chjrkmwgn	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	733	oq5ns5b2di34	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-23 13:22:26.702963+00	2026-07-27 11:50:16.988141+00	ertydgjfuups	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	794	kc7xzofs7a2o	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-05 11:28:52.875425+00	2026-08-06 21:21:48.896912+00	cavoxa57gpps	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	739	oblhe2azset3	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-25 22:03:23.971099+00	2026-07-27 15:54:59.987524+00	5ijjdts7ommp	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	792	thkxf6iw2vqr	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-04 20:50:55.350155+00	2026-08-07 17:08:37.137169+00	zttskbnwv7c3	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	745	gzqv4orafl44	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-27 11:50:16.998118+00	2026-07-27 19:15:43.121592+00	oq5ns5b2di34	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	798	2zf75dwlrngt	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-06 21:21:48.918736+00	2026-08-08 10:33:40.860235+00	kc7xzofs7a2o	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	747	xaca55k75cwv	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-27 15:55:00.003342+00	2026-07-27 20:04:08.115727+00	oblhe2azset3	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	753	zvnqmbhbftwc	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-27 20:04:08.13323+00	2026-07-28 19:00:38.714817+00	xaca55k75cwv	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	750	vdlt7xhi4ddh	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-27 19:15:43.13012+00	2026-07-28 20:04:25.149427+00	gzqv4orafl44	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	802	xex3c5c4bhg2	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-08 10:33:40.88043+00	2026-08-08 18:33:04.822126+00	2zf75dwlrngt	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	704	cmpqdpl5zj76	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-20 11:29:00.994283+00	2026-07-29 08:01:19.051826+00	4ykdfdpq774u	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	809	uejhsmuqdiak	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-08 18:33:04.832928+00	2026-08-09 15:28:02.338024+00	xex3c5c4bhg2	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	759	ymeyt3jbrgag	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-28 20:04:25.164563+00	2026-07-29 12:09:32.313464+00	vdlt7xhi4ddh	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	758	i5chqcdfmbfn	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-28 19:00:38.72187+00	2026-07-29 14:12:03.752414+00	zvnqmbhbftwc	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	811	2hi3v6nxtda2	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-09 15:28:02.353801+00	2026-08-09 17:48:03.017782+00	uejhsmuqdiak	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	765	l6cshtwgi2iq	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-29 14:12:03.760376+00	2026-07-29 16:30:40.8884+00	i5chqcdfmbfn	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	801	3dpwzl47rqki	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-07 17:08:37.152235+00	2026-08-10 07:04:48.835806+00	thkxf6iw2vqr	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	766	kilidbpkmdna	c4233153-ba79-4596-a447-7c979056fd33	t	2026-07-29 16:30:40.909333+00	2026-07-29 17:39:24.691437+00	l6cshtwgi2iq	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	763	5jzpvug34leh	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-29 12:09:32.334001+00	2026-07-29 20:52:55.398787+00	ymeyt3jbrgag	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	773	sw2r5r7exykf	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-30 09:44:18.387465+00	2026-08-12 10:54:27.598733+00	vu6itrpyj3z4	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	768	uah3qis5pohw	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-29 20:52:55.414402+00	2026-07-30 08:10:49.866648+00	5jzpvug34leh	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	760	vu6itrpyj3z4	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-07-29 08:01:19.071639+00	2026-07-30 09:44:18.378665+00	cmpqdpl5zj76	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	831	4nyq6l4dzqse	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-12 10:54:27.615426+00	2026-08-14 07:27:33.415159+00	sw2r5r7exykf	ae6e6ea6-5d7a-401f-bfa4-c252bf613f56
00000000-0000-0000-0000-000000000000	834	xsr7tjxnzjpx	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-13 09:39:28.080902+00	2026-08-14 08:12:32.828444+00	ah2uz53ndexp	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	910	6ldcfrzgml4q	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-27 12:49:06.535622+00	2026-08-27 16:10:50.456136+00	runkg3ptfmep	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	975	5lhc5lthuljl	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-05 08:49:01.186493+00	2026-09-06 15:37:53.546649+00	urr5mklyg5bc	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	822	lggw4xvooy52	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-10 20:51:54.985303+00	2026-08-14 14:19:40.109788+00	ry4vjr7i4z3t	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	813	u6ryldqc2npv	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-10 07:04:48.856666+00	2026-08-10 14:07:27.723067+00	3dpwzl47rqki	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	841	pyu3rt2s3a2w	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-14 08:12:32.837822+00	2026-08-15 10:24:03.182733+00	xsr7tjxnzjpx	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	908	t4qlkwsjmn55	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-26 13:38:16.562457+00	2026-09-07 08:10:56.336846+00	jzjutwfb4sgb	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	1052	hunbgqgcp7vi	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-15 15:23:06.018608+00	2026-09-15 18:20:26.721239+00	w4vagxwgr7ys	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	849	bdwmfzhtwtly	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-17 08:22:14.298099+00	2026-08-18 07:55:57.762871+00	sgofth27iiqn	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	816	ry4vjr7i4z3t	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-10 14:07:27.731219+00	2026-08-10 20:51:54.967376+00	u6ryldqc2npv	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	914	j3vps4y7retm	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-27 16:10:50.464019+00	2026-08-29 11:56:00.883561+00	6ldcfrzgml4q	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1056	6p4wnbg4ypsp	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-15 18:20:26.740244+00	2026-09-16 10:46:05.262146+00	hunbgqgcp7vi	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	990	4zwmbk6pd2z6	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-07 09:21:23.21841+00	2026-09-07 10:36:38.56886+00	grpmnh7h2n4f	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	927	xt26p3d6fhf2	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-29 11:56:00.890004+00	2026-08-29 13:14:52.194345+00	j3vps4y7retm	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1065	uhjy7oq2q3dk	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-16 10:46:05.267944+00	2026-09-16 19:05:44.99251+00	6p4wnbg4ypsp	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	993	7akes6vechva	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-07 10:36:38.587642+00	2026-09-07 14:41:34.153491+00	4zwmbk6pd2z6	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	812	ru2guqqkfz3k	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-09 17:48:03.032165+00	2026-08-11 12:57:36.764105+00	2hi3v6nxtda2	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1068	yce2zvuwp3mk	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-16 17:57:07.956543+00	2026-09-16 19:38:24.941172+00	6746fsonytmc	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	933	yepyhl6l5kmc	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-30 10:02:19.12335+00	2026-08-30 11:00:34.379604+00	vyaylo2o4z6e	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1071	3aar7zldry43	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-16 21:47:43.501153+00	2026-09-17 05:15:37.620828+00	ijh7arzanhgi	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	995	rz6cx6d7imuw	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-07 14:41:34.174244+00	2026-09-07 17:09:22.695973+00	7akes6vechva	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	996	itsyvd432oyi	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-07 17:09:22.71476+00	2026-09-07 19:53:43.829924+00	rz6cx6d7imuw	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	850	lpa5wcfjqrmf	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-18 07:55:57.789026+00	2026-08-19 20:58:15.63909+00	bdwmfzhtwtly	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	828	ah2uz53ndexp	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-11 12:57:36.778098+00	2026-08-13 09:39:28.06791+00	ru2guqqkfz3k	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	997	owd3okb7rvvj	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-07 19:53:43.847834+00	2026-09-07 20:56:58.500027+00	itsyvd432oyi	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	859	xva47wx6syqy	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-19 20:58:15.655059+00	2026-08-20 09:00:49.620158+00	lpa5wcfjqrmf	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	861	nbmeefxlhwks	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-20 12:40:20.806739+00	2026-08-20 14:57:29.674275+00	a2nbdwtaxs4j	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	860	ng2z7uswpygh	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-20 09:00:49.634653+00	2026-08-20 15:36:04.617905+00	xva47wx6syqy	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	987	3ogxinw2v2pa	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-06 20:21:50.325926+00	2026-09-08 16:14:19.339081+00	yrvitxqyj27s	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	863	qplj7inhickc	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-20 15:36:04.625312+00	2026-08-21 14:49:09.490478+00	ng2z7uswpygh	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	862	44nwbmvnyvjb	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-20 14:57:29.68641+00	2026-08-21 19:26:04.136924+00	nbmeefxlhwks	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	866	jecjggorlnzv	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-21 14:49:09.496073+00	2026-08-21 19:52:30.596648+00	qplj7inhickc	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	1001	mikk56hil253	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-08 16:14:19.359164+00	2026-09-09 19:25:05.031867+00	3ogxinw2v2pa	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	998	snxlamemoxon	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-07 20:56:58.517245+00	2026-09-11 18:57:59.145241+00	owd3okb7rvvj	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	867	3rqsfh4b2l6d	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-21 19:26:04.154549+00	2026-08-22 18:25:40.446643+00	44nwbmvnyvjb	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	873	pix6pnkxod44	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	f	2026-08-22 18:52:12.040471+00	2026-08-22 18:52:12.040471+00	\N	059170df-6abe-40d1-a717-9e951ee4f5a1
00000000-0000-0000-0000-000000000000	868	xfilpb2zljl5	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-21 19:52:30.603205+00	2026-08-23 18:23:24.519284+00	jecjggorlnzv	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	935	ctmeykipypxt	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-30 19:01:30.451562+00	2026-09-02 15:18:14.064294+00	voalt6hviouc	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	874	5htdzdp2rvbj	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-23 18:23:24.539831+00	2026-08-24 07:16:19.838981+00	xfilpb2zljl5	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	875	5jzvamy6hv6g	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-24 07:16:19.863533+00	2026-08-24 19:54:57.545019+00	5htdzdp2rvbj	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	964	q42smupwvyqi	36252019-fac0-4514-91df-23eb5fdc3a5f	f	2026-09-04 12:31:15.523475+00	2026-09-04 12:31:15.523475+00	\N	46916489-8342-4870-9444-01b7bbf98b36
00000000-0000-0000-0000-000000000000	883	4nig463a2wbj	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-24 19:54:57.566684+00	2026-08-25 13:21:26.578576+00	5jzvamy6hv6g	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	951	urr5mklyg5bc	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-02 15:18:14.080234+00	2026-09-05 08:49:01.166281+00	ctmeykipypxt	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	904	gnjkgsvsqp4x	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	f	2026-08-25 18:38:59.235508+00	2026-08-25 18:38:59.235508+00	\N	2960e7c8-69d2-40aa-b027-d5e500e73c83
00000000-0000-0000-0000-000000000000	905	nf5cl4nhwk3h	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	f	2026-08-25 18:38:59.883828+00	2026-08-25 18:38:59.883828+00	\N	e40dacbd-2800-42e1-91e0-77fa61d65ef7
00000000-0000-0000-0000-000000000000	894	4xumhnna5x7j	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-25 13:21:26.583735+00	2026-08-25 18:51:56.621123+00	4nig463a2wbj	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	906	jzjutwfb4sgb	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-08-25 18:51:56.633563+00	2026-08-26 13:38:16.538478+00	4xumhnna5x7j	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	872	runkg3ptfmep	c4233153-ba79-4596-a447-7c979056fd33	t	2026-08-22 18:25:40.456981+00	2026-08-27 12:49:06.513587+00	3rqsfh4b2l6d	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1032	w4vagxwgr7ys	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-12 22:24:29.79787+00	2026-09-15 15:23:05.997498+00	bu3bwzciluyt	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1036	pjc2fsewykaa	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-13 15:51:10.393025+00	2026-09-15 19:14:10.4487+00	p2b5uwrt3efb	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	1005	65je3ylxyljm	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-09 19:25:05.041203+00	2026-09-11 05:57:28.927563+00	mikk56hil253	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1057	6746fsonytmc	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-15 19:14:10.472055+00	2026-09-16 17:57:07.941666+00	pjc2fsewykaa	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	1069	ijh7arzanhgi	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-16 19:05:44.99792+00	2026-09-16 21:47:43.482188+00	uhjy7oq2q3dk	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1139	cht3nbg4g6ae	7db5ba07-e7fd-4795-844d-e59035681949	f	2026-09-22 15:06:20.738282+00	2026-09-22 15:06:20.738282+00	\N	c3fdd87f-0415-4077-86b3-15022ec9af5f
00000000-0000-0000-0000-000000000000	1072	caakxpew6jdi	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-17 05:15:37.64081+00	2026-09-17 20:07:26.738187+00	3aar7zldry43	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1140	7qin4xbjmd6z	7db5ba07-e7fd-4795-844d-e59035681949	t	2026-09-22 15:06:22.846615+00	2026-09-22 16:11:01.57167+00	\N	62524521-8963-4485-bf25-e20142929fbf
00000000-0000-0000-0000-000000000000	1141	ehiafkdtzz34	7db5ba07-e7fd-4795-844d-e59035681949	t	2026-09-22 16:11:01.583795+00	2026-09-23 07:40:02.948882+00	7qin4xbjmd6z	62524521-8963-4485-bf25-e20142929fbf
00000000-0000-0000-0000-000000000000	1142	ryyldoovanqn	7db5ba07-e7fd-4795-844d-e59035681949	f	2026-09-23 07:40:02.965623+00	2026-09-23 07:40:02.965623+00	ehiafkdtzz34	62524521-8963-4485-bf25-e20142929fbf
00000000-0000-0000-0000-000000000000	1013	tvog6uki57iy	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-11 05:57:28.949966+00	2026-09-12 11:57:59.639593+00	65je3ylxyljm	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1022	3hr2ezdzgpkc	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-11 18:57:59.154405+00	2026-09-12 20:58:27.484753+00	snxlamemoxon	cdc14a7a-d336-4054-9540-21490fa753f5
00000000-0000-0000-0000-000000000000	1030	bu3bwzciluyt	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-12 11:57:59.65476+00	2026-09-12 22:24:29.787214+00	tvog6uki57iy	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1096	6asfhqfb6bst	c4233153-ba79-4596-a447-7c979056fd33	t	2026-09-19 11:58:23.813245+00	2026-09-19 16:55:02.09505+00	oox3ftc2z5dn	5401fcff-a126-4078-a1c7-a6a5e9d76c77
00000000-0000-0000-0000-000000000000	1031	p2b5uwrt3efb	be20a8d7-d8e8-457e-bc94-828592ac9ab3	t	2026-09-12 20:58:27.510118+00	2026-09-13 15:51:10.372343+00	3hr2ezdzgpkc	cdc14a7a-d336-4054-9540-21490fa753f5
\.


--
-- Data for Name: sso_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_providers" ("id", "resource_id", "created_at", "updated_at", "disabled") FROM stdin;
\.


--
-- Data for Name: saml_providers; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_providers" ("id", "sso_provider_id", "entity_id", "metadata_xml", "metadata_url", "attribute_mapping", "created_at", "updated_at", "name_id_format") FROM stdin;
\.


--
-- Data for Name: saml_relay_states; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."saml_relay_states" ("id", "sso_provider_id", "request_id", "for_email", "redirect_to", "created_at", "updated_at", "flow_state_id") FROM stdin;
\.


--
-- Data for Name: scim_tokens; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."scim_tokens" ("id", "sso_provider_id", "token_hash", "prefix", "created_at", "expires_at", "revoked_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: scim_users; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."scim_users" ("id", "sso_provider_id", "user_id", "resource", "created_at", "updated_at", "deleted_at") FROM stdin;
\.


--
-- Data for Name: sso_domains; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."sso_domains" ("id", "sso_provider_id", "domain", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: webauthn_challenges; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_challenges" ("id", "user_id", "challenge_type", "session_data", "created_at", "expires_at") FROM stdin;
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: auth; Owner: supabase_auth_admin
--

COPY "auth"."webauthn_credentials" ("id", "user_id", "credential_id", "public_key", "attestation_type", "aaguid", "sign_count", "transports", "backup_eligible", "backed_up", "friendly_name", "created_at", "updated_at", "last_used_at") FROM stdin;
\.


--
-- Data for Name: Therapists; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Therapists" ("Id", "AuthId", "Name", "Email", "Timezone", "FeeInPence", "Bio", "StripeAccountId", "IsActive", "CreatedAt", "UpdatedAt", "MaxAdvanceUnit", "MaxAdvanceValue", "MinNoticeUnit", "MinNoticeValue", "CancellationPolicy", "ReminderUnit", "ReminderValue", "RemindersEnabled", "GoogleRefreshToken", "OpeningClientHours", "OpeningSupervisionHours", "CancelNoticeUnit", "CancelNoticeValue", "FlagGapWeeks", "ReviewAfterSessions", "Role", "InvoiceDueBeforeSession", "InvoiceDueDays", "InvoiceMemo", "InvoiceReminderDays", "InvoiceReminderTiming", "InvoicingEnabled", "CancelUnpaidBookings", "NonPaymentHours", "NonPaymentPolicyEnabled", "NonPaymentPolicyText", "DefaultOnlineVideoLink", "Slug", "Qualifications", "TermsAcceptedAt", "HasProfessionalInsurance", "MembershipBody", "MembershipNumber", "Modality", "TermsAcceptedIp", "TermsAcceptedVersion", "WelcomeEmailSent", "Plan", "StripeCustomerId", "StripeSubscriptionId", "LogoUrl", "PhotoUrl", "IntroCallReminderUnit", "IntroCallReminderValue", "IntroCallRemindersEnabled", "SupervisionReminderUnit", "SupervisionReminderValue", "SupervisionRemindersEnabled", "VerificationSubmittedAt", "VerifiedAt", "ProTrialStartedAt", "ProTrialEndsAt", "ProTrialEndingEmailSentAt", "ProTrialEndedEmailSentAt", "SignupLandingPath", "SignupReferrer", "GridEndTime", "GridStartTime") FROM stdin;
81684e9c-903e-4ce0-927e-d679ecf5d769	baefdd0b-521d-4090-8021-1c39c7614608	Test 1	test1@bookmytherapy.co.uk	Europe/London	7500	\N	\N	t	2026-09-19 08:03:08.565145+00	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	test-1	\N	\N	f	\N	\N	\N	\N	\N	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	\N	\N	\N	\N	\N	\N	/	\N	23:00	06:00
bd48e910-a161-46b2-9204-8346500fd85e	c4467f4c-aad8-4430-bdda-1b004fe4cf53	Martha Dickson	davidchefoo@gmail.com	Europe/London	4450	I am a counsellor but I don't give advice	acct_1TitLkGmqLkhuM61	t	2026-05-22 07:28:35.310416+00	2026-09-21 10:09:16.796591+00	weeks	2	days	1	Don't you dare!	hours	6	t	\N	0	0	hours	48	\N	\N	User	t	\N	\N	\N	\N	t	f	\N	f	\N	\N	chefoo-woo	very qulifed	2026-06-26 16:15:17.163258+00	t	BACP	44555555	what?	90.201.177.177, 172.71.151.198, 10.31.127.132	2	t	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-26 16:10:17.115634+00	2026-08-25 09:20:24.172139+00	2026-09-24 09:20:24.172139+00	2026-09-21 10:09:16.796559+00	\N	\N	\N	23:00	06:00
0dacfd12-575a-4c56-bff0-c73fc3f74e20	bd7b8095-f9e0-4f3b-8894-a22d061af337	Helen Jennings	helen.jennings1@yahoo.co.uk	Europe/London	7500	Integrative therapist	\N	t	2026-06-02 13:13:30.847122+00	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	helen-jennings	\N	\N	f	\N	\N	\N	\N	\N	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	23:00	06:00
95aca459-bc65-4a3a-8b0c-8440c2de2b87	03fae691-1b92-4f37-bfa7-e6a3f7e68e32	Serving Coops	55serving_coops@icloud.com	Europe/London	7500	\N	\N	t	2026-06-03 07:44:04.190517+00	2026-06-03 07:45:51.808272+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	serving-coops	z	2026-06-03 07:45:51.804756+00	t	z	z	\N	147.12.132.209, 172.68.192.195, 10.193.51.129	1	t	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	\N	\N	\N	\N	\N	\N	23:00	06:00
5bc2515e-19e0-480f-b1a6-8b4f9d51fdf9	8a9a9cc3-91ca-429d-893c-4fca61f02479	Natashia Bobbitt	ncbobbittent@yahoo.com	Europe/London	7500	I believe everyone has the ability to heal, grow, and become the author of their own story. My approach is compassionate, collaborative, and focused on helping clients move from surviving to thriving. Whether you're navigating grief, anxiety, trauma, life transitions, relationship challenges, or substance use recovery, I provide a safe space to process your experiences and develop practical tools for lasting change.	\N	t	2026-06-04 11:23:00.671515+00	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	natashia-bobbitt	\N	\N	f	\N	\N	\N	\N	\N	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	23:00	06:00
3f615b21-f9ca-4473-b8b2-0aaf471fb45d	468cade7-1d68-497e-9aa0-57e79722996e	David Houliston	houliston.david@gmail.com	Europe/London	7500	Humanistic therapist specialising in anxiety and life transitions.	acct_1TYluDGgOqknbIQ3	t	2026-04-14 10:59:50.260969+00	2026-06-24 06:17:08.326303+00	weeks	1	days	3	Cancellations made less than 48 hours will be charged in full.	hours	1	t	\N	1	0	hours	48	1	\N	Admin	t	2	Thank you for booking. 	1	before_due_date	t	t	24	t	Payment is required 24 hours before the session. Unpaid invoices will result in the booking being cancelled to free up sessions for other clients.	https://doxy.me/settings	david-houliston	Level 4	2026-05-21 11:25:04.384025+00	t	Bacp	234444	\N	90.201.177.177, 172.71.178.53, 10.195.116.1	1	t	Pro	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	\N	\N	\N	\N	\N	\N	23:00	06:00
7e2ec244-8fa6-4f98-a72e-82cf1d2eca12	a0296447-63d6-4dd6-9924-55cccc0f0a29	Kates counselling	contactkatescounselling@gmail.com	Europe/London	5500	Therapeutic Counselling	\N	t	2026-06-23 20:18:56.34093+00	2026-06-23 20:21:49.952714+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	kates-counselling	\N	\N	f	\N	\N	\N	\N	\N	t	Free	\N	\N	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/7e2ec244-8fa6-4f98-a72e-82cf1d2eca12/logo	\N	\N	\N	f	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	23:00	06:00
415c8847-3da1-4e70-805d-fd13beb95aa9	33206a78-c324-45b5-a09b-ecd6d3a89052	Jo Mo	jomobi@hotmail.co.uk	Europe/London	7500	Integrative	\N	t	2026-06-24 09:04:32.122775+00	\N	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	jo-mo	\N	\N	f	\N	\N	\N	\N	\N	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	23:00	06:00
7f855dc1-2b6d-4c01-ae97-293eaef2837d	e6e44d92-1a53-4123-9aec-c05dd825f974	Dr. Rickey Reewith - Msc.D. MHt	rreewith@gmail.com	Europe/London	7500	Life, Wellness and Relationship Therapist  / Specialist Counselllor.	\N	t	2026-06-04 18:43:28.700524+00	2026-06-09 09:34:08.817877+00	\N	\N	\N	\N	Cancel 48 hours in advance.	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	dr-rickey-reewith-msc-d-mht	Doctor of Metaphysical Science, MSc. D.	2026-06-09 09:34:08.813411+00	t	America Metaphysical Doctors Association	50769	\N	102.251.80.15, 172.69.109.170, 10.193.226.129	2	t	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	\N	\N	\N	\N	\N	\N	23:00	06:00
ccac4768-056c-468f-b179-770f4a8c6d8b	2e01e063-789f-4c1e-ad09-180781c35411	Nigel Small	nigelsmall1952@gmail.com	Europe/London	7500	\N	\N	t	2026-06-24 07:34:17.331602+00	2026-06-24 07:35:38.511036+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	nigel-small	Nothing here	2026-06-24 07:35:38.505818+00	t	WHATS	1242155	\N	92.207.129.21, 172.70.220.27, 10.195.88.132	2	t	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	\N	\N	\N	\N	\N	\N	23:00	06:00
434df510-d7ef-4e2c-aead-bfa8af97140d	889b3064-f9c0-42ea-9800-6cd4d1078f1a	Hrisa Mitreva	hrisamitreva@gmail.com	Europe/London	7500	\N	\N	t	2026-06-24 13:33:13.263235+00	2026-06-24 13:35:22.47179+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	hrisa-mitreva	MA in Integrative Counselling	2026-06-24 13:35:22.467402+00	t	BACP	01027005	Integrative	94.72.215.137, 172.69.224.16, 10.198.165.134	2	t	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	\N	\N	\N	\N	\N	\N	23:00	06:00
7de40fde-1f9a-471a-8d37-e9c04bc79f8e	36252019-fac0-4514-91df-23eb5fdc3a5f	Andrew Walklate	nwwb@outlook.com	Europe/London	5500	Integrative Counsellor offering tailored therapy including counselling, hypnotherapy, EMDR and NLP techniques.  Face to face and online sessions available.	\N	t	2026-06-24 07:18:12.738066+00	2026-09-04 12:31:44.403462+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	andrew-walklate	Registered Nurse \nHypnotherapy Practitioner Diploma \nLevel 5 Integrative Counselling	2026-06-24 21:36:11.487248+00	t	BACP	01029824	Integrative, Hypnotherapy, EMDR	86.155.60.108, 172.69.43.196, 10.198.207.1	2	t	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	\N	\N	\N	\N	\N	\N	23:00	06:00
1810faf2-d25b-4e98-ad68-780aef6b823e	9a796c66-37fe-4446-b279-468fb6ac3dfd	Eva Kovacs	info@evacounselling.com	Europe/London	7500	\N	\N	t	2026-06-26 10:03:31.335266+00	2026-07-01 19:54:16.206189+00	\N	\N	\N	\N	\N	\N	\N	f	\N	1200	400	hours	48	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	eva-kovacs	Prof.Dip Psy C	2026-07-01 19:54:16.060561+00	t	BACP	997069	Pluralistic	104.28.30.90, 172.64.192.190, 10.31.164.4	2	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-07-01 10:50:29.585101+00	2026-07-01 15:47:13.001246+00	\N	\N	\N	\N	\N	\N	23:00	06:00
4e7214dc-b42b-4462-aa74-5026e3b4c8e7	be20a8d7-d8e8-457e-bc94-828592ac9ab3	Michael Boulton	mb.therapy@outlook.com	Europe/London	4000	\N	acct_1TgQdzGUETlNTofG	t	2026-06-04 13:04:34.990107+00	2026-07-03 21:01:13.022794+00	weeks	4	\N	\N	Sessions cancelled with less than 24 hours notice will be charged in full	hours	1	t	1//06M2besdZewj_CgYIARAAGAYSNwF-L9IrNnlT6lV8ZwL7VrU0rPAlVpsEEK68tfhbGxZkB2RNWBxtMqx63mIcX3nqy-i-XR-277g	550	0	hours	24	3	\N	User	t	1	Thank you for your booking. Please note, payment is due before the session takes place.	\N	on_due_date	t	t	24	t	Payment is required 24 hours before the session takes place. A booking may get cancelled if payment hasn't been made before this time.	\N	michael-boulton	Cert ED. Counselling Skills (Integrative) & MA Person-Centred Counselling and Psychotherapy Practice	2026-06-04 13:13:44.882914+00	t	BACP	396552	Person-Centred	152.71.207.142, 172.68.192.194, 10.195.131.132	1	t	Pro	cus_UdxQr0jE5cyakF	sub_1TefWCKIvWPqhgVZEi88fDxW	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/4e7214dc-b42b-4462-aa74-5026e3b4c8e7/logo	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/4e7214dc-b42b-4462-aa74-5026e3b4c8e7/photo	\N	\N	f	\N	\N	f	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	2027-05-21 17:56:53+00	2027-06-04 17:56:53+00	2026-08-25 09:07:42.403935+00	2026-08-25 09:07:42.403935+00	\N	\N	23:00	06:00
37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	c4233153-ba79-4596-a447-7c979056fd33	A Better Self Therapies	debi@abetterselftherapies.co.uk	Europe/London	5000	Welcome to A Better Self Therapies, my name is Debi and my aim is to enable others to find and maintain balance, peace and the answers that they are looking for.  I offer a range of modalities which allows me to provide for individual needs with flexibility throughout sessions.	acct_1TqGooGZ7O0g85My	t	2026-07-06 12:37:36.573884+00	2026-07-29 16:59:52.392603+00	\N	\N	days	1	Cancellations made with less that 48 hrs notice will be charged in full.	days	1	t	1//067hAY1XqVjn9CgYIARAAGAYSNwF-L9IrzsRF2UTK-Q02lHfcoGz_cYm3zji-6nl6YxctJ3Bj9yG9TakDutwsyfIQRevgNv3C7_8	0	0	hours	48	\N	\N	User	t	2	Thank you for booking.  Payment is due prior to session to secure your slot.	\N	\N	t	f	\N	f	\N	\N	debi-benson	BA (Hons) Behavioural Studies\nMA (Hons) Teaching and Learning\nLevel 5 Diploma in Psychotherapeutic Counselling\nIEMT Practitioner\nEFT Practitioner\nReiki Master	2026-07-06 17:21:30.513419+00	t	NCPS	NCS21-01361	Integrative	88.97.210.35, 172.64.192.191, 10.26.149.131	2	f	Pro	cus_Upw8AVrV9bEDVK	sub_1TqGGrKIvWPqhgVZW4jTxlMX	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/37a5bf82-e84b-4cb7-b8a4-4e78aed3148b/logo	\N	\N	\N	f	\N	\N	f	2026-07-06 12:43:09.058078+00	2026-07-06 15:18:06.928091+00	2026-07-22 17:25:08+00	2026-08-05 17:25:08+00	2026-08-25 09:07:42.403935+00	2026-08-25 09:07:42.403935+00	\N	\N	23:00	06:00
ba74c380-d26a-438d-962f-65c1425cde6f	1ef8cb01-2813-4203-b05d-52ad47f7c8de	Mary McCabe	marymccabecounselling@gmail.com	Europe/London	6500	A BACP accredited counsellor, supervisor and trainer with 15 years experience supporting staff, students and clients in the NHS, Higher Education, Charites and other care sectors. Former careers in research and teaching.\nI specialise in working with neurodivergent people and those experiencing chronic health issues, bereavement and loss, and life transitions. \nOffering a range of therapeutic modalities including Acceptance and Commitment Therapy (ACT), parts work and creative approaches, in a person-centred, compassionate and collaborative and neuro-affirming plus trauma-informed manner.	\N	t	2026-06-25 14:49:57.865935+00	2026-06-26 20:42:07.408625+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	mary-mccabe	Masters Module (60 credits) Mindfulness and Acceptance therapeutic approaches\nDiploma in Supervision\nDiploma in Counselling\nUniversity Foundation Art Therapy\nPlus BEd Honours and MPhil Degrees	\N	t	BACP	48168	Person-centred foundation; Integrative ; Acceptance and Commitment Therapy (ACT); creative approaches	\N	\N	f	Free	\N	\N	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/ba74c380-d26a-438d-962f-65c1425cde6f/logo	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/ba74c380-d26a-438d-962f-65c1425cde6f/photo	\N	\N	f	\N	\N	f	2026-06-26 11:30:39.501269+00	2026-06-26 16:47:32.213005+00	\N	\N	\N	\N	\N	\N	23:00	06:00
8106bfc7-b15a-4a05-aa40-f214bf7ebb77	5711310a-b42c-4b02-8420-c0818e98d748	Sarah Olds	sarah.olds@gmail.com	Europe/London	7500	Neuroafformative psychotherapy	\N	t	2026-06-27 10:02:25.718486+00	2026-06-27 10:02:44.781851+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	sarah-olds	\N	\N	f	\N	\N	\N	\N	\N	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	23:00	06:00
d2ec7542-c806-44f7-87a0-626bbf61a8d8	3e433d1e-3feb-48b9-a7cc-73b5d546dd73	Tami Oren	general.orenge@gmail.com	Europe/London	7500	Therapy with Tami - Baing.With \nIntegrative Relational Psychotherapeutic counselling in Central Cambridge and online .	\N	t	2026-06-26 19:28:06.613631+00	2026-06-26 19:57:13.5217+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	tami-oren	Level 7 integrative Psychotherapy \nLevel 2 IFS \nLevel 4 Counseling skills and theories \nLevel 5 CBT	2026-06-26 19:57:13.376042+00	t	BACP,NCPS	01023920	Integrated relational IFS	80.3.27.217, 162.158.216.191, 10.30.250.94	2	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-26 19:33:16.638507+00	2026-06-26 19:49:02.733574+00	\N	\N	\N	\N	\N	\N	23:00	06:00
9ab24c5a-5210-4342-ab21-472b1a091f10	67e74856-ce44-4e06-837c-cb7a9e813959	Sharon McHugh	sharon@bettertomorrowscounselling.com	Europe/London	7500	\N	\N	t	2026-06-27 17:24:07.072778+00	2026-09-11 17:45:21.989528+00	\N	\N	\N	\N	\N	\N	\N	f	\N	0	0	\N	\N	\N	\N	User	f	\N	\N	\N	\N	f	f	\N	f	\N	\N	sharon-mchugh	Level 4 Integrative Counselling, Level 5 CBT	2026-06-28 09:41:56.703409+00	t	BACP	0084690	CBT, Integrative	86.135.196.70, 172.71.146.194, 10.31.127.132	2	f	Free	\N	\N	\N	\N	\N	\N	f	\N	\N	f	2026-06-27 17:29:07.864032+00	2026-06-27 20:40:39.293955+00	2026-09-11 17:42:36.210715+00	2026-10-11 17:42:36.210715+00	\N	\N	\N	\N	23:00	06:00
47884d7a-9e96-4245-bcec-f5ab308a54f4	7db5ba07-e7fd-4795-844d-e59035681949	David Houliston	therapy@davidhoulistoncounselling.com	Europe/London	5000	\N	acct_1TbIsTGunz6NhwSQ	t	2026-05-26 08:22:45.133483+00	2026-09-22 06:51:10.221647+00	weeks	2	hours	12	Sessions cancelled with less than 48 hours notice will be charged in full.	days	1	t	1//03JX6CNd4b6Q4CgYIARAAGAMSNwF-L9Iro9-09_qoSJgP-bP0qYqtB6ueN323JZ6-IUJRl9DmzoKZUkjqJB7-EY5Dq-cq-t7vy0U	56	0	hours	48	\N	\N	User	t	1	Thank you for booking. Payment is due 1 day before the session.	1	before_due_date	t	t	24	t	Payment is required at least the day before your session. Unpaid bookings may be cancelled.	https://doxy.me/davidhouliston	david-houliston-2	Level 4 Diploma in Therapeutic Counselling	2026-05-26 08:28:03.132303+00	t	BACP	01008925	Person-Centred, Transactional Analysis, Gestalt	90.201.177.177, 172.70.85.214, 10.199.189.4	1	t	Pro	cus_UbEdgBAgnsA2kS	sub_1Tc2AYKIvWPqhgVZwpiWyCVJ	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/47884d7a-9e96-4245-bcec-f5ab308a54f4/logo	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/therapist-assets/47884d7a-9e96-4245-bcec-f5ab308a54f4/photo	hours	1	t	hours	12	t	2026-06-25 11:34:40.084575+00	2026-06-25 11:34:40.084575+00	2027-05-14 11:31:50+00	2027-05-28 11:31:50+00	2026-08-25 09:07:42.403935+00	2026-08-25 09:07:42.403935+00	\N	\N	23:00	09:00
\.


--
-- Data for Name: AvailabilityRules; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."AvailabilityRules" ("Id", "TherapistId", "DayOfWeek", "StartTime", "EndTime") FROM stdin;
1dfd3913-9bde-4acd-87c7-212cb5f9e27e	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	5	09:00	17:00
37cb8110-119a-4906-a0b6-d02a3a9e5a39	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	3	09:00	17:00
57c91212-6552-402a-818a-24a7a0203dc5	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	0	09:00	17:00
86a9e0aa-7fc5-4f75-b633-fc87790e0de7	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	0	17:00	22:00
882bb3ee-7a7b-42cd-b8c3-ed7f2cfd348b	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	09:00	17:00
a2415156-3b19-4acb-ad3d-f540fb0d3a08	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	4	09:00	22:00
c4080d70-33e4-48fb-b3ee-3b6b9d867f20	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2	09:00	17:00
fe167a19-5e24-4002-952f-3e6491a07ca1	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	17:00	19:00
14349d90-7ecc-46bb-a0a9-579963f640ef	bd48e910-a161-46b2-9204-8346500fd85e	5	10:00	12:00
272a56c8-57ff-478c-8072-3b02448542f8	bd48e910-a161-46b2-9204-8346500fd85e	2	19:00	22:00
3183abbe-177e-4ecf-a01a-fae87d8b6be5	bd48e910-a161-46b2-9204-8346500fd85e	3	09:00	21:00
35bc5550-51a4-43be-92ad-496340461804	bd48e910-a161-46b2-9204-8346500fd85e	1	09:00	18:00
7980e3f7-256d-4bbe-acc8-46b11c749d6e	bd48e910-a161-46b2-9204-8346500fd85e	4	09:00	18:00
8b4b2583-920c-45c9-b40c-6087b0a38fdd	bd48e910-a161-46b2-9204-8346500fd85e	0	09:00	13:00
97db19d7-b180-4ff6-b4f8-77f4e3a25d3d	bd48e910-a161-46b2-9204-8346500fd85e	0	18:00	21:00
f6cd817a-f252-417f-ab78-0e8d9e34d610	bd48e910-a161-46b2-9204-8346500fd85e	2	09:00	18:00
1fdb0b49-d3c9-4208-9b87-9959867a6410	47884d7a-9e96-4245-bcec-f5ab308a54f4	3	12:00	14:00
019e1268-0a2f-4f80-aa00-c661ad4dfbed	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	5	14:00	15:00
57dbd134-3fe1-461b-b877-2b1500864211	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	3	19:00	20:00
59bceace-9463-487e-85df-7b5c961131ec	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	5	12:00	13:00
91101598-7e0c-4bd8-bddd-9f7e1c39c9b0	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	5	10:00	11:00
3c1e0e10-9b19-48bd-9ef5-9a83f0a2dcda	ba74c380-d26a-438d-962f-65c1425cde6f	0	09:00	19:00
4ab388d6-a148-4b53-a2da-f4ddbcf40f85	ba74c380-d26a-438d-962f-65c1425cde6f	3	09:00	17:00
5ba390fb-566e-4707-891a-49c2f507ea25	ba74c380-d26a-438d-962f-65c1425cde6f	1	09:00	20:00
88ef477a-c76a-4553-9b76-28cb76558d18	ba74c380-d26a-438d-962f-65c1425cde6f	2	17:00	21:00
d4d82fe4-c0a7-4914-9262-87b2c18ef358	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	5	11:00	12:00
ed4339c8-7447-4885-9233-83ce29c175b3	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	5	13:00	14:00
fb855389-151f-4372-b7da-0c8c01f36f54	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	3	20:00	20:30
35c0c7ad-7386-4de4-9ab4-6bf68401cba4	47884d7a-9e96-4245-bcec-f5ab308a54f4	0	10:30	13:00
40d690fe-8dd4-4d46-8915-c4b6c6ca10f1	47884d7a-9e96-4245-bcec-f5ab308a54f4	2	10:30	16:00
45c488ac-721a-4340-a285-b422cf15cdc7	47884d7a-9e96-4245-bcec-f5ab308a54f4	4	09:00	12:00
473086f7-e623-48d3-a35d-85454b92f28c	47884d7a-9e96-4245-bcec-f5ab308a54f4	0	18:00	21:00
496c5738-2388-4f7f-a194-c87669c3c5ef	47884d7a-9e96-4245-bcec-f5ab308a54f4	3	09:00	12:00
52aac86d-09e3-4531-ba5d-0f4032175ef9	47884d7a-9e96-4245-bcec-f5ab308a54f4	2	17:15	20:00
5541087b-0c1c-44b4-b2e4-7104ad6068f4	47884d7a-9e96-4245-bcec-f5ab308a54f4	5	10:00	12:00
780ba1b1-1f4d-4c6d-a383-0a319052be02	47884d7a-9e96-4245-bcec-f5ab308a54f4	4	14:30	16:00
9f34398a-aebc-4062-8a8b-37c58a0277c7	47884d7a-9e96-4245-bcec-f5ab308a54f4	3	14:00	20:00
100a266e-3dfb-45a8-b4dd-9c69ccffc471	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	0	21:00	22:30
1a393d3b-fc36-4f7a-96f5-6144d21b103d	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	0	16:00	17:00
1be83a66-cd95-4c36-b51c-44db0fe98309	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2	21:00	22:30
64922e86-f522-4c13-ada2-03daac90da08	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	3	16:00	17:00
705fe562-9533-44af-9c8d-b1c3ef9a89e1	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	4	15:30	16:30
761056b3-515d-4c3b-ac8a-3d8b33ab2e4e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2	19:00	20:00
76c8f211-fc01-4850-b969-9dfc1f3a3680	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	0	20:00	21:00
84ad2f1d-0f13-4f49-a391-f4859c8eec59	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	1	16:00	17:00
9b073511-29cf-44a3-a3f7-b7e16736510f	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2	16:00	17:00
a0d028a0-ee46-4dc0-b2b3-68894c50ee7c	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	4	21:00	22:30
c7b68970-52f3-4520-bcae-a49336f888b9	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	1	19:00	20:00
dcf365f6-275d-4c36-afad-0a4c29966710	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	4	19:00	20:00
eb7ea11a-44c0-4473-803f-9635927e3cfc	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	1	21:00	22:30
2680c05b-70fa-4cd9-82f4-beb61cf7dc6f	434df510-d7ef-4e2c-aead-bfa8af97140d	2	09:00	20:00
433e065d-f1bc-42bf-bdca-ba9c99c72c77	434df510-d7ef-4e2c-aead-bfa8af97140d	4	09:00	17:00
44e98d81-2797-4203-b30b-4102584b00d0	434df510-d7ef-4e2c-aead-bfa8af97140d	3	09:00	17:00
ba9678c7-d9d7-4f04-a7a1-75c4324d5f0f	434df510-d7ef-4e2c-aead-bfa8af97140d	1	09:00	17:00
fbd20c7a-860c-4eb6-924c-466f48ef97f0	434df510-d7ef-4e2c-aead-bfa8af97140d	5	09:00	17:00
fe020b47-26ad-4772-a8e9-86360e576bc5	434df510-d7ef-4e2c-aead-bfa8af97140d	0	09:00	20:00
9e68fb16-5969-4499-8848-27c71abc5ec3	7de40fde-1f9a-471a-8d37-e9c04bc79f8e	4	09:00	13:00
0cd3b502-3a0b-4e3e-b95c-52937b1533fe	9ab24c5a-5210-4342-ab21-472b1a091f10	4	12:00	16:00
1bff4712-fb95-4845-8c6a-7a9393146b7d	9ab24c5a-5210-4342-ab21-472b1a091f10	3	07:30	19:00
21e76e75-986b-4d6e-9719-be660d49f9d6	9ab24c5a-5210-4342-ab21-472b1a091f10	2	10:30	11:30
70b73f25-3194-4a3e-a858-c5b67eaf8e67	9ab24c5a-5210-4342-ab21-472b1a091f10	2	17:30	18:30
8b129e72-4b16-4ebf-a612-ad0bca755fb9	9ab24c5a-5210-4342-ab21-472b1a091f10	0	08:00	19:00
a2b9e052-2cb3-4ae9-b8a4-493e859b7f0a	47884d7a-9e96-4245-bcec-f5ab308a54f4	1	11:00	18:00
b3b598af-474c-47e8-9686-2be70950e847	47884d7a-9e96-4245-bcec-f5ab308a54f4	4	16:00	20:00
d4b53d2c-de9e-40dc-ab36-a0c645cb1562	47884d7a-9e96-4245-bcec-f5ab308a54f4	2	20:30	21:30
\.


--
-- Data for Name: DeliveryTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."DeliveryTypes" ("Id", "Code", "Label", "SortOrder", "AvailableForIntroCalls", "AvailableForSessions", "AvailableForSupervision", "RequiresLink", "IsActive") FROM stdin;
b4c1e8a7-5f2d-4a3b-9c6e-0d7f1a2b3c01	phone	Phone call	1	t	t	f	f	t
c7d2f9b8-6a3e-4b4c-8d7f-1e8a2b3c4d02	online	Online	2	t	t	t	t	t
d8e3a0c9-7b4f-4c5d-9e8a-2f9b3c4d5e03	face_to_face	Face to face	3	f	t	t	f	t
5466990b-b1c7-4a96-8ae2-f93bea13b0bc	walk_and_talk	Walk and Talk	4	f	t	f	f	t
\.


--
-- Data for Name: SessionTypeConfigs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."SessionTypeConfigs" ("Id", "TherapistId", "Name", "Description", "DurationMins", "FeeInPence", "SortOrder", "IsActive", "CreatedAt", "Color", "BufferMins", "EnableOnlineVideoLink", "VideoLinkUrl", "HideFromClients", "BookingAvailability", "DeliveryTypeId") FROM stdin;
6ae879dd-17a5-4fe3-885b-ebadac35060c	bd48e910-a161-46b2-9204-8346500fd85e	In Person	\N	50	6000	1	t	2026-06-20 10:53:11.148873+00	#16A34A	10	f	\N	f	Any	\N
11a355ad-276b-4777-b890-409d0be8b66e	bd48e910-a161-46b2-9204-8346500fd85e	Online	\N	50	5500	2	t	2026-06-20 10:53:29.547382+00	#CA8A04	10	f	\N	f	Any	\N
f2d4f68e-8457-4dc7-a7f3-09267e51e60a	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Online Counselling	\N	50	5000	0	t	2026-07-06 12:46:20.081379+00	#2563EB	10	t	\N	f	Any	\N
b95d0ce9-289d-45d0-9871-ab9580d36811	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	In-Person	In Chichester	50	35	0	t	2026-04-18 14:14:37.788129+00	#4f86c6	10	f	\N	f	Any	\N
f37dc415-9f9a-4464-a06b-8453ff11bf40	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Phone	Talk on the phone - voice only	50	37	2	t	2026-04-19 14:31:56.961268+00	#c45c5c	10	f	\N	f	Any	\N
b0a6d7dc-5b87-47a9-a29b-51c365527892	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Online	Online video call	50	36	1	t	2026-04-18 14:34:01.813424+00	#c6a63d	10	t	https://doxy.me/client	f	Any	\N
2c711bf7-6d72-483c-bf83-2f004d2491bf	47884d7a-9e96-4245-bcec-f5ab308a54f4	Introduction call	A brief, free, 10-to-15 minute chat by phone or video . It lets you share your main reasons for seeking support, check if you feel comfortable with them, and go over basic logistics like fees and schedules before booking a full session.	15	0	4	t	2026-07-16 16:00:29.286721+00	#CA8A04	15	t	https://doxy.me/davidhouliston	f	NewClientsOnly	\N
aeb060b8-173c-4bc9-9afd-9886e140904e	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Sauna	\N	60	5000	3	t	2026-05-26 07:38:13.632857+00	#9b6db5	10	f	\N	f	Any	\N
f251d5a4-4886-4425-a63f-3775952cf80a	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	In person Counselling	\N	50	5000	1	t	2026-07-06 12:47:11.38011+00	#9333EA	10	f	\N	f	Any	\N
82870962-db92-4530-938e-2de4fe4fab77	47884d7a-9e96-4245-bcec-f5ab308a54f4	Therapy Pot Session (online)	\N	50	0	3	t	2026-06-06 08:24:43.179172+00	#0891B2	10	f	\N	t	Any	c7d2f9b8-6a3e-4b4c-8d7f-1e8a2b3c4d02
9f412383-4f53-4f7f-bd11-b12424feaaf7	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Emotional Freedom Techniques	\N	50	6000	3	t	2026-07-06 12:48:35.395707+00	#CA8A04	10	f	\N	f	Any	\N
0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Online Appointment	Microsoft Teams Counselling Session	50	4000	0	t	2026-06-04 13:18:44.483253+00	#5ba05b	0	f	\N	f	Any	\N
39c51f09-654b-4837-9d65-e7589b9b6019	7de40fde-1f9a-471a-8d37-e9c04bc79f8e	Integrative Counselling (In Person)	50 min general integrative counselling session	50	5500	0	t	2026-06-24 21:42:30.904773+00	#CA8A04	10	f	\N	f	Any	\N
666d596b-439e-49c7-8998-385c716b794f	47884d7a-9e96-4245-bcec-f5ab308a54f4	Initial session - In-person in Chichester	Your first session (60 mins) is space to talk through what's brought you here — whether that's something you need to work through now, or the start of ongoing therapy. There's no obligation either way; we'll figure out what's right for you together.\n\nMeeting face-to-face allows for a personal connection and a calm environment where you can explore your thoughts and feelings.	60	6000	5	t	2026-08-10 10:45:29.796038+00	#2563EB	30	f	\N	t	NewClientsOnly	d8e3a0c9-7b4f-4c5d-9e8a-2f9b3c4d5e03
1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	BH Session	\N	60	2000	2	t	2026-06-09 18:25:03.013149+00	#DC2626	0	f	\N	t	Any	\N
719836e7-063e-412e-affa-8234342dd3cb	7de40fde-1f9a-471a-8d37-e9c04bc79f8e	Hypnotherapy Session (in Person)	50 min Hypnotherapy session including review and hypnotherapy treatment	50	7000	1	t	2026-06-24 21:43:27.52687+00	#EA580C	10	f	\N	f	Any	\N
aa3afc95-4772-4884-bfc6-c9fe9d898f3f	bd48e910-a161-46b2-9204-8346500fd85e	Initial assessment	\N	50	6000	0	t	2026-05-25 16:23:13.752707+00	#4f86c6	10	f	\N	f	Any	\N
a9cb0856-b500-46c9-b169-f93033be008b	7de40fde-1f9a-471a-8d37-e9c04bc79f8e	EMDR/IEMT  (In Person)	Session dedicated to use of Eye Movement therapies	50	7000	2	t	2026-06-24 21:44:04.504138+00	#EA580C	10	f	\N	f	Any	\N
fceec855-c5ea-426a-9b9f-bc46c470a6b5	47884d7a-9e96-4245-bcec-f5ab308a54f4	In-person in Chichester	Meeting face-to-face allows for a personal connection and a calm environment where you can explore your thoughts and feelings.	50	5500	0	t	2026-05-26 11:16:57.120308+00	#4f86c6	10	f	\N	f	Any	d8e3a0c9-7b4f-4c5d-9e8a-2f9b3c4d5e03
3dea6e5c-75b7-494e-92c4-1eab47cc8272	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Hypnotherapy	\N	50	6000	4	t	2026-07-06 12:49:14.221394+00	#2563EB	10	f	\N	f	Any	\N
e6731634-7b83-4718-9674-c007bc314a6d	47884d7a-9e96-4245-bcec-f5ab308a54f4	Initial Session - Online	Your first session (60 mins) is space to talk through what's brought you here — whether that's something you need to work through now, or the start of ongoing therapy. There's no obligation either way; we'll figure out what's right for you together.\n\nConvenient, confidential, and just as effective as in-person sessions, whether you’re at home, at work, or travelling.	60	5000	6	t	2026-08-10 10:46:30.504109+00	#2563EB	30	t	https://doxy.me/davidhouliston	t	NewClientsOnly	c7d2f9b8-6a3e-4b4c-8d7f-1e8a2b3c4d02
2b8f2392-75c9-4f10-b11b-74bae4bbd463	ba74c380-d26a-438d-962f-65c1425cde6f	Initial session	\N	50	6500	0	t	2026-06-26 20:44:11.561974+00	#2563EB	20	f	\N	f	Any	\N
acb2d172-d161-48e7-b3d5-5622199e2839	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	IEMT (Integral Eye Movement Techniques)	\N	60	8000	2	t	2026-07-06 12:47:44.676849+00	#16A34A	10	f	\N	f	Any	\N
5975ae28-e5e4-49eb-9a96-d09bc7e6d4f3	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Initial consultation	This is a free online/telephone session that provides the opportunity to discuss needs and to ensure that A Better Self Therapies is right for you.	30	0	5	t	2026-07-07 10:53:50.636066+00	#2563EB	0	f	\N	f	Any	\N
9701f0e1-cbfd-4159-b762-13f8b6ce3eff	1810faf2-d25b-4e98-ad68-780aef6b823e	Intro Call	\N	30	0	0	t	2026-07-01 10:53:01.482635+00	#DC2626	10	t	\N	f	Any	\N
70bc90d8-3f54-4915-a105-5fcad923bc5e	47884d7a-9e96-4245-bcec-f5ab308a54f4	For internal testing only - N	\N	50	31	2	t	2026-05-26 12:28:56.492805+00	#6b7280	10	f	\N	t	Any	\N
8c4c3bad-8ee0-4685-b500-b54fa71ee299	47884d7a-9e96-4245-bcec-f5ab308a54f4	For internal testing only - E	\N	50	0	7	t	2026-08-10 10:48:26.804615+00	#2563EB	10	f	\N	t	ExistingClientsOnly	\N
dfba3c75-ac1c-49da-b22f-ef5f6244935a	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Extended Online Appointment	Extended Microsoft Teams Counselling Session	90	6500	1	t	2026-06-04 13:19:22.154387+00	#4f86c6	0	f	\N	f	Any	\N
a6455293-058b-4aca-b001-0a8868aa69b3	47884d7a-9e96-4245-bcec-f5ab308a54f4	Online	Convenient, confidential, and just as effective as in-person sessions, whether you’re at home, at work, or travelling.	50	5000	1	t	2026-05-26 11:17:50.842249+00	#5ba05b	10	t	https://doxy.me/davidhouliston	f	Any	c7d2f9b8-6a3e-4b4c-8d7f-1e8a2b3c4d02
\.


--
-- Data for Name: AvailabilitySessionTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."AvailabilitySessionTypes" ("AvailabilityRuleId", "SessionTypeId", "TherapistId") FROM stdin;
1fdb0b49-d3c9-4208-9b87-9959867a6410	666d596b-439e-49c7-8998-385c716b794f	47884d7a-9e96-4245-bcec-f5ab308a54f4
1fdb0b49-d3c9-4208-9b87-9959867a6410	fceec855-c5ea-426a-9b9f-bc46c470a6b5	47884d7a-9e96-4245-bcec-f5ab308a54f4
35c0c7ad-7386-4de4-9ab4-6bf68401cba4	2c711bf7-6d72-483c-bf83-2f004d2491bf	47884d7a-9e96-4245-bcec-f5ab308a54f4
35c0c7ad-7386-4de4-9ab4-6bf68401cba4	a6455293-058b-4aca-b001-0a8868aa69b3	47884d7a-9e96-4245-bcec-f5ab308a54f4
496c5738-2388-4f7f-a194-c87669c3c5ef	666d596b-439e-49c7-8998-385c716b794f	47884d7a-9e96-4245-bcec-f5ab308a54f4
496c5738-2388-4f7f-a194-c87669c3c5ef	fceec855-c5ea-426a-9b9f-bc46c470a6b5	47884d7a-9e96-4245-bcec-f5ab308a54f4
52aac86d-09e3-4531-ba5d-0f4032175ef9	666d596b-439e-49c7-8998-385c716b794f	47884d7a-9e96-4245-bcec-f5ab308a54f4
52aac86d-09e3-4531-ba5d-0f4032175ef9	fceec855-c5ea-426a-9b9f-bc46c470a6b5	47884d7a-9e96-4245-bcec-f5ab308a54f4
780ba1b1-1f4d-4c6d-a383-0a319052be02	2c711bf7-6d72-483c-bf83-2f004d2491bf	47884d7a-9e96-4245-bcec-f5ab308a54f4
780ba1b1-1f4d-4c6d-a383-0a319052be02	a6455293-058b-4aca-b001-0a8868aa69b3	47884d7a-9e96-4245-bcec-f5ab308a54f4
b3b598af-474c-47e8-9686-2be70950e847	fceec855-c5ea-426a-9b9f-bc46c470a6b5	47884d7a-9e96-4245-bcec-f5ab308a54f4
d4b53d2c-de9e-40dc-ab36-a0c645cb1562	2c711bf7-6d72-483c-bf83-2f004d2491bf	47884d7a-9e96-4245-bcec-f5ab308a54f4
1a393d3b-fc36-4f7a-96f5-6144d21b103d	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
64922e86-f522-4c13-ada2-03daac90da08	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
705fe562-9533-44af-9c8d-b1c3ef9a89e1	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
761056b3-515d-4c3b-ac8a-3d8b33ab2e4e	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
76c8f211-fc01-4850-b969-9dfc1f3a3680	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
84ad2f1d-0f13-4f49-a391-f4859c8eec59	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
9b073511-29cf-44a3-a3f7-b7e16736510f	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
c7b68970-52f3-4520-bcae-a49336f888b9	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
dcf365f6-275d-4c36-afad-0a4c29966710	0607aabc-240c-4c0a-8adf-ad69519eb59e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7
d4b53d2c-de9e-40dc-ab36-a0c645cb1562	a6455293-058b-4aca-b001-0a8868aa69b3	47884d7a-9e96-4245-bcec-f5ab308a54f4
57dbd134-3fe1-461b-b877-2b1500864211	f2d4f68e-8457-4dc7-a7f3-09267e51e60a	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b
fb855389-151f-4372-b7da-0c8c01f36f54	5975ae28-e5e4-49eb-9a96-d09bc7e6d4f3	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b
\.


--
-- Data for Name: BlockedDates; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."BlockedDates" ("Id", "TherapistId", "Date", "Reason") FROM stdin;
e7266517-04d1-441c-8395-a81b20ab3595	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-04-21	\N
ef0ec61b-2ac9-4e0e-9cd3-80ae77e2c16c	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25	Spring Bank Holiday
6ead95a4-ae48-4ab5-ab87-57b57963cdb4	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-01	\N
e0fc43e1-951e-4d3b-9cba-94e3ab7f0a12	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-15	\N
3674a9c1-e4bf-4f32-8c74-4ea09f45a91c	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-31	HOLIDAY
4286e168-c693-4f90-ae0a-2fc34817689f	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-01	HOLIDAY
52f5d6f4-8f80-4791-8005-5b0260dd324f	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-02	HOLIDAY
dbfadd9d-6096-42da-9eae-37295c4f321b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-03	HOLIDAY
1812746b-667c-40a4-aafd-ffaf605c95e0	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-04	HOLIDAY
d8f82081-2502-4429-9c15-526c13ae7c97	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-18	HOLIDAY
927b1674-e9cd-4057-86ed-2ddd4679714e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-21	HOLIDAY
d7b21d96-6dc2-4b8d-8cba-77f49876a963	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-22	HOLIDAY
33175ce9-1b1b-43b7-9ad3-96d6a5b9dfda	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-23	HOLIDAY
9c2ec63a-7bda-4e77-be5b-c08004e2c3c0	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-24	HOLIDAY
81a1bbfd-3ed6-48ca-80ae-a6075bca2374	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-25	HOLIDAY
c6b2f5fb-af01-4d55-ae1d-1d61a84faeac	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-10-12	HOLIDAY
79d6ec43-6300-49db-a0da-3b73885186a0	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-10-13	HOLIDAY
1075dbca-0efc-45bf-824b-a76fc6910ca7	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-10-14	HOLIDAY
5bb7fd71-1d11-436d-bd5e-cb492ca4556b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-10-15	HOLIDAY
6698766e-6212-4d6e-b027-63abba441ebe	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-10-16	HOLIDAY
bb4844ee-8496-4051-b274-7c803ee5a616	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-13	\N
4a9923b6-d88f-4501-98ba-f10925f950a0	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-18	\N
8510abd0-946c-4f2a-a16c-bef6e666f864	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-14	Away
61625b8f-63de-4593-9b2f-6b1acc20dea5	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-15	Away
659efbcb-8413-40b7-aea6-4433e1feb2eb	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-31	Bank holiday
\.


--
-- Data for Name: GenderTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."GenderTypes" ("Id", "Code", "Label", "SortOrder", "IsActive") FROM stdin;
a1b2c3d4-0e5f-4a6b-8c7d-9e0f1a2b3c01	female	Female	1	t
b2c3d4e5-1f6a-4b7c-9d8e-0f1a2b3c4d02	male	Male	2	t
c3d4e5f6-2a7b-4c8d-8e9f-1a2b3c4d5e03	transgender	Transgender	3	t
d4e5f6a7-3b8c-4d9e-9f0a-2b3c4d5e6f04	trans_woman	Trans Woman	4	t
e5f6a7b8-4c9d-4e0f-8a1b-3c4d5e6f7a05	trans_man	Trans Man	5	t
f6a7b8c9-5d0e-4f1a-9b2c-4d5e6f7a8b06	non_binary	Non-binary	6	t
a7b8c9d0-6e1f-4a2b-8c3d-5e6f7a8b9c07	gender_questioning	Gender-Questioning	7	t
b8c9d0e1-7f2a-4b3c-9d4e-6f7a8b9c0d08	gender_fluid	Gender-Fluid	8	t
\.


--
-- Data for Name: Clients; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Clients" ("Id", "TherapistId", "Name", "Email", "Phone", "Notes", "GpName", "GpPractice", "GpPhone", "EmergencyContactName", "EmergencyContactPhone", "EmergencyContactRelationship", "CreatedAt", "UpdatedAt", "NegotiatedFeeInPence", "PreferredSessionTypeId", "OtpCode", "OtpExpiresAt", "VideoLinksJson", "DoNotEmail", "PreviousSessions", "ClientIdentifier", "AgeYears", "GenderTypeId") FROM stdin;
a15dd1b0-3451-43c3-bc9f-6d50992ca1c9	47884d7a-9e96-4245-bcec-f5ab308a54f4	Mawgan  Luff	mawganluff@8gmail.com	7856713552								2026-09-19 10:22:56.685213+00	\N	\N	\N	\N	\N	{}	f	0	ML	\N	\N
0e3710cd-d335-4841-a7f8-c998a743b9a4	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Fanny Price	f@p.com									2026-04-16 12:58:00.969197+00	2026-04-21 07:54:28.863033+00	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	{}	f	0	FP	\N	\N
b4f61a8a-fed1-47f7-9dd6-5532f064ec96	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	dsf fsdfs	crmalaysia2025@gmail.com	7590193774		fsf	sdfs	7590193774	dsf	7590193774	sdfs	2026-04-21 19:14:42.453717+00	2026-04-22 20:59:16.221964+00	4500	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	{}	f	0	DF	\N	\N
e17eb33b-dcbf-46c4-a713-4a9be7c2af35	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Mango Jerry	m@s.com	\N	Wants to use Zoom	\N	\N	\N	\N	\N	\N	2026-04-30 13:43:45.06553+00	\N	\N	\N	\N	\N	{}	f	0	MJ	\N	\N
a73d9024-84af-4937-b298-f1a0d948e7ba	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Percy	g@b.com		uoquoqwueo							2026-04-16 12:37:49.28873+00	2026-05-02 11:52:16.540447+00	2300	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	{}	f	0	P	\N	\N
f5506a34-ab36-44b5-8d4b-3342f503185c	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	ddfh dhd	o@w.c									2026-05-02 11:46:57.643294+00	2026-05-09 14:37:16.548034+00	\N	f37dc415-9f9a-4464-a06b-8453ff11bf40	\N	\N	{}	f	0	DD	\N	\N
575ca44f-4e73-4884-8289-44ce8914364f	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Shirley Temple	s@t.com	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-11 09:34:47.496833+00	\N	\N	\N	\N	\N	{}	f	0	ST	\N	\N
6589fc5e-b998-43f6-b1c6-0cddbb7f73af	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Teddy	Bear@s.c	99999999999	give him a hug	Dr Wanj	still	4454544	Bob	454554	Friend	2026-05-11 10:14:13.440308+00	2026-05-11 10:16:48.567053+00	5500	f37dc415-9f9a-4464-a06b-8453ff11bf40	\N	\N	{}	f	0	T	\N	\N
34b1ca19-a0fe-41ea-9836-3f8620181f97	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Sonia Casu	soniaca93@icloud.con	07395277583								2026-09-21 12:40:55.506998+00	\N	\N	\N	\N	\N	{}	f	0	SC	\N	\N
feee1fc0-5a59-446d-a271-0afd19b7be45	47884d7a-9e96-4245-bcec-f5ab308a54f4	Shannon Davis	shannondavisxx@outlook.com	+447407663250	\N	\N	\N	\N	\N	\N	\N	2026-05-28 14:46:22.234559+00	\N	\N	\N	\N	\N	{}	f	0	SD	\N	\N
106de2f0-45f6-43fa-8f89-6a0118d15da4	47884d7a-9e96-4245-bcec-f5ab308a54f4	Susan mclaird	susan.mclaird@mail.com	+447966103432								2026-05-28 14:46:22.247523+00	2026-05-29 15:21:45.333566+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	SM	\N	\N
4016c344-a3cf-4d82-a87e-2c94cd89abc2	47884d7a-9e96-4245-bcec-f5ab308a54f4	Loula	loulamaeweller@hotmail.co.uk	+447580115255								2026-05-28 14:46:22.060034+00	2026-06-10 15:37:34.183247+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	3	L	\N	\N
9ec95932-cd2b-4c41-b052-2156ec454d44	47884d7a-9e96-4245-bcec-f5ab308a54f4	Peter Saunders	pjsaunders52@gmail.com	+447833456870								2026-05-28 14:46:22.13454+00	2026-06-10 15:40:37.62268+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	2	PS	\N	\N
35b86aa5-d532-430c-93b2-3fa0bd31ba8f	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Sonia Casu	soniaca93@icloud.con	07395277583								2026-09-21 12:40:54.822127+00	\N	\N	\N	\N	\N	{}	f	0	SC	\N	\N
ed2b1782-07bd-44e8-8df2-c2fc10b020bd	47884d7a-9e96-4245-bcec-f5ab308a54f4	Nathan Everson	nathaneverson11@gmail.com									2026-05-28 14:46:22.125363+00	2026-05-29 15:20:54.386068+00	\N	a6455293-058b-4aca-b001-0a8868aa69b3	\N	\N	{"a6455293-058b-4aca-b001-0a8868aa69b3": "https://doxy.me/davidhouliston"}	f	0	NE	\N	\N
a5b49aef-9809-4265-ba52-96e3039411bb	47884d7a-9e96-4245-bcec-f5ab308a54f4	Sean King	seanfromchi@gmail.com	+447311180008								2026-05-28 14:46:22.225445+00	2026-05-29 15:21:26.484819+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	SK	\N	\N
5954c672-1e1a-4820-b729-d88f2b8e3b55	47884d7a-9e96-4245-bcec-f5ab308a54f4	Xenon Bridges	brdgesxenon@icloud.com	+497539869357								2026-05-28 14:46:22.278909+00	2026-05-29 15:22:11.837454+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	XB	\N	\N
d163e0da-714e-419e-9757-f14c2e2f18a8	47884d7a-9e96-4245-bcec-f5ab308a54f4	Marc Vincent	marcfive74@gmail.com	+447909868470								2026-05-28 14:46:22.082194+00	2026-06-10 15:38:12.521545+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	2	MV	\N	\N
a9e61101-c01f-4fb9-9869-1293646d14ad	47884d7a-9e96-4245-bcec-f5ab308a54f4	William Byford	wbyford31@gmail.com	+447774593041	\N	\N	\N	\N	\N	\N	\N	2026-05-28 14:46:22.269729+00	\N	\N	\N	\N	\N	{}	f	0	WB	\N	\N
291d4a94-d2a2-4151-93c3-89b21ae8c30e	47884d7a-9e96-4245-bcec-f5ab308a54f4	Graham Hayward	ghayward@ntlworld.com	+447710707998								2026-05-28 14:46:21.748177+00	2026-05-29 15:19:21.431015+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	GH	\N	\N
996ee20a-1f97-4cbf-81e4-af863dfdb336	47884d7a-9e96-4245-bcec-f5ab308a54f4	Annette Hart	netty@peter-hart.com		Room 3							2026-06-09 20:25:31.09138+00	2026-06-16 08:20:26.580426+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	AH	\N	\N
508444c1-a065-4639-9e11-c798406eb3d1	47884d7a-9e96-4245-bcec-f5ab308a54f4	Toni Bradshaw	westsussex56@gmail.com	+447384334624								2026-05-28 14:46:22.25653+00	2026-05-29 15:21:56.089036+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	TB	\N	\N
b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Aditi Kaushik	aditi.kaushikk@gmail.com	07586740552	Wednesdays at 9pm				Jasmeet Bhambra	07350183120	Partner	2026-06-05 12:54:54.189923+00	\N	4000	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	AK	\N	\N
f516b85e-c084-4caf-be52-c413017520ee	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Conor Wildsmith	conor666@yahoo.com	07405812339					Tracy Broster	‪07543829424‬	Step Mother	2026-06-05 12:59:41.278065+00	\N	2500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	CW	\N	\N
dd2aa615-f230-443d-91b7-8d910f74eaae	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	test client	testclient@example.com		\N	\N	\N	\N	\N	\N	\N	2026-05-12 09:45:17.670795+00	\N	\N	\N	\N	\N	{}	f	0	TC	\N	\N
44c935ee-ac12-47f5-abd8-858ea37692d0	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	test client	test@exampl.com		\N	\N	\N	\N	\N	\N	\N	2026-05-12 10:01:31.223026+00	\N	\N	\N	\N	\N	{}	f	0	TC	\N	\N
2d16f712-3c60-4ba9-8801-776dc423aa26	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	test client	h@s.c		\N	\N	\N	\N	\N	\N	\N	2026-05-12 10:17:02.723706+00	\N	\N	\N	\N	\N	{}	f	0	TC	\N	\N
1e1368e6-38d3-4b5f-821e-753912f772be	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	test client	t@gyyy.com		\N	\N	\N	\N	\N	\N	\N	2026-05-12 10:21:38.018966+00	\N	\N	\N	\N	\N	{}	f	0	TC	\N	\N
8deb6b3b-4506-4afe-92b8-f0fa2bff8231	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	test client	t@c.com		\N	\N	\N	\N	\N	\N	\N	2026-05-12 10:24:46.827632+00	\N	\N	\N	\N	\N	{}	f	0	TC	\N	\N
4d0def63-70e5-44a5-b6ed-2256db01f809	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Millie	m@w.w	7590193774	likes to sing	Dr NoGood	Hardly	0155255	Gran	7590193455774	Grandma	2026-05-22 16:22:33.90003+00	\N	\N	\N	\N	\N	{}	f	0	M	\N	\N
48b65fa5-71b5-4de4-ad09-19854cb18f16	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Dennis the Menance	d@m.s	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-22 16:58:18.551331+00	\N	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	{}	f	0	DTM	\N	\N
0e83389d-dabd-48fd-9a5b-fcc435dd26bd	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	fgfd dfdfg	k@w.c		\N	\N	\N	\N	\N	\N	\N	2026-05-22 20:33:23.703573+00	\N	\N	\N	\N	\N	{}	f	0	FD	\N	\N
48aaf5c7-cb34-4dfd-bea9-b1d4468b4002	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Jeremy Denk	j@f.c									2026-05-22 16:18:38.72745+00	2026-05-23 12:43:22.722528+00	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	{}	f	0	JD	\N	\N
604ae139-05d5-4679-a06c-9ef366488dc2	47884d7a-9e96-4245-bcec-f5ab308a54f4	Billy Brown	billydbrown1789@gmail.com	+447850247253	\N	\N	\N	\N	\N	\N	\N	2026-05-28 14:46:21.644194+00	\N	\N	\N	\N	\N	{}	f	0	BB	\N	\N
bbff92b1-9293-4cef-bb47-35b0a36e5945	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	dgdfg dfgdfg	oo@p.c		\N	\N	\N	\N	\N	\N	\N	2026-05-24 10:34:50.191199+00	\N	\N	\N	\N	\N	{}	f	0	DD	\N	\N
09b065c5-a8f7-431a-be7a-f4f6d3a94916	47884d7a-9e96-4245-bcec-f5ab308a54f4	David Rhys Turner	davidturnerdys@gmail.com	+447904714658	\N	\N	\N	\N	\N	\N	\N	2026-05-28 14:46:21.728767+00	\N	\N	\N	\N	\N	{}	f	0	DRT	\N	\N
6d3712ae-074d-44ad-9815-4c2c667f720d	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	david	houliston.david@gmail.com									2026-04-19 13:17:08.330484+00	2026-05-24 20:43:50.209631+00	33	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	{"b0a6d7dc-5b87-47a9-a29b-51c365527892": "https://doxy.me/client"}	f	0	D	\N	\N
0725377a-2a75-4fc2-a340-068025ddbf1e	bd48e910-a161-46b2-9204-8346500fd85e	Vernica	david@davidhoulistoncounselling.com	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-25 16:30:30.261549+00	\N	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	{}	f	0	V	\N	\N
1ba98f28-7476-4801-9786-f69733a4dc8f	bd48e910-a161-46b2-9204-8346500fd85e	david	houliston.david@gmail.com									2026-05-25 19:49:39.666281+00	2026-05-25 19:50:03.564633+00	250	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	{}	f	0	D	\N	\N
de2eece9-2c1e-4168-80eb-29e1fa596755	47884d7a-9e96-4245-bcec-f5ab308a54f4	David Houliston	houliston.david@gmail.com	\N	\N	\N	\N	\N	\N	\N	\N	2026-05-26 12:30:13.590621+00	\N	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	DH	\N	\N
88de853a-2cd3-443d-802c-8e410899fa01	47884d7a-9e96-4245-bcec-f5ab308a54f4	Alice Markham	almarkham29@gmail.com	+447545261104	\N	\N	\N	\N	\N	\N	\N	2026-05-28 14:46:21.624919+00	\N	\N	\N	\N	\N	{}	f	0	AM	\N	\N
4d5d4435-662e-4ea4-909a-8573d37e5a12	47884d7a-9e96-4245-bcec-f5ab308a54f4	Etta-Joy Galyer	etta.speight@gmail.com	+447930211604	\N	\N	\N	\N	\N	\N	\N	2026-05-28 14:46:21.739015+00	\N	\N	\N	\N	\N	{}	f	0	EG	\N	\N
29104fc4-9636-470a-adcf-431de2f88aa6	47884d7a-9e96-4245-bcec-f5ab308a54f4	Jessica lin	jessica62711@icloud.com	+447479908338	\N	\N	\N	\N	\N	\N	\N	2026-05-28 14:46:21.780275+00	\N	\N	\N	\N	\N	{}	f	0	JL	\N	\N
6af59927-94ab-413d-b2d1-6fc173656aca	47884d7a-9e96-4245-bcec-f5ab308a54f4	Jo	jo1hope2@gmail.com	+447738263187								2026-05-28 14:46:21.841104+00	2026-06-10 15:35:53.343263+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	8	J	\N	\N
9799c585-9a2b-4a80-ad19-8904771bf758	47884d7a-9e96-4245-bcec-f5ab308a54f4	james bailey	meganrigby2005@gmail.com	+447434675397								2026-05-28 14:46:21.757389+00	2026-05-29 15:19:40.747244+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	JB	\N	\N
864977ce-f74b-409d-8158-763ec40e6919	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Martha my dear	davidhoulistontherapy@gmail.com									2026-04-16 12:38:09.251572+00	2026-04-21 14:29:16.800334+00	\N	\N	848993	2026-04-21 14:47:13.611499+00	{}	f	0	MMD	\N	\N
ff51c829-7a78-4eb8-a267-63e6f443d3f6	47884d7a-9e96-4245-bcec-f5ab308a54f4	Johnathan Pownall	jonnypownall@live.co.uk	+447853675044								2026-05-28 14:46:22.037223+00	2026-05-29 15:20:11.698459+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	JP	\N	\N
745017df-0b22-41b1-bcdb-8ac6bc92a7c5	47884d7a-9e96-4245-bcec-f5ab308a54f4	Leo Powell	leoadrianpowell@gmail.com	+447816505327								2026-05-28 14:46:22.050597+00	2026-05-29 15:20:20.253952+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	LP	\N	\N
c8f76055-fef3-4aac-ac85-8cc72674b157	47884d7a-9e96-4245-bcec-f5ab308a54f4	Adam Hutchins	ahutchins83@outlook.com									2026-05-28 14:46:21.329436+00	2026-06-10 15:33:53.641451+00	4500	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	4	AH	\N	\N
435de98e-26a0-4b08-8979-5c984f92849c	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	dfdg dfgd	w@g.com									2026-05-01 10:08:16.315292+00	\N	\N	\N	\N	\N	{}	f	0	DD	\N	\N
31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Elena Magnavacca 	ecmagnavacca@gmail.com	07791302160					Francesca Magnavacca 	07807467360	Sister	2026-06-05 13:01:01.985947+00	\N	3500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	EM	\N	\N
2eae7ffe-555e-4c73-b66c-a7b44af25693	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Jack Doyle	jackdoyle240804@gmail.com	07883369857					Becky Doyle	07766770787	Mother	2026-06-05 13:02:20.967041+00	\N	2500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	JD	\N	\N
7bcc6880-0a24-4836-9190-077734a05bba	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Sonia Casu	Soniaca93@icloud.com	07395277583					Crystal Johnson	07391625497	Cousin	2026-06-05 13:03:31.932129+00	\N	3500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	SC	\N	\N
7ad8918b-f750-44f1-9c17-f8b101f9d826	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Viktoria Stoyanova	vikito2899@gmail.com	07902775923					Vladislavs Deksnis	07713277134	Partner	2026-06-05 13:04:38.242906+00	\N	2500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	VS	\N	\N
5133a2c0-2307-439e-b6be-1ae4401b3891	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Chase Currah	chasecurrah03@gmail.com	07936173001	Fridays at 9pm							2026-06-05 12:58:19.139073+00	2026-06-05 16:47:16.58317+00	2500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	CC	\N	\N
b86d2e4b-da0b-4286-a274-9cfdc5d7e60a	bd48e910-a161-46b2-9204-8346500fd85e	Graham	g@a.co	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-20 10:52:28.161802+00	\N	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	{}	f	0	G	\N	\N
067a1648-6f8e-4832-b666-069677893a96	47884d7a-9e96-4245-bcec-f5ab308a54f4	Test101	s@b.S	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-06 08:27:33.476649+00	\N	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	T	\N	\N
541effab-e1ee-480a-ac20-ab78235f4c10	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	BH Client	bh@betterhelp.com	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-08 12:50:26.735184+00	\N	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	BC	\N	\N
74577f33-d5a1-46a8-a5d7-fdbac56718d7	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Charles Fletcher	charles@cffloral.co.uk	07960002352					Jermaine Woods	07824600802	Partner	2026-06-05 12:56:21.04432+00	2026-06-09 20:57:16.503905+00	2500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	CF	\N	\N
f3b310f3-b55c-44fc-ba1b-5d5e1970905e	47884d7a-9e96-4245-bcec-f5ab308a54f4	Bettie Smythwood			Therapy Pot Client							2026-06-06 08:21:44.181783+00	2026-06-10 15:34:25.671978+00	\N	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	{}	t	5	BS	\N	\N
33990723-6e30-40a2-96f1-72dc705737ac	47884d7a-9e96-4245-bcec-f5ab308a54f4	Jan Rowley	janrowley21@yahoo.co.uk	+447599248771								2026-05-28 14:46:21.770791+00	2026-06-10 15:35:40.190723+00	\N	a6455293-058b-4aca-b001-0a8868aa69b3	\N	\N	{"a6455293-058b-4aca-b001-0a8868aa69b3": "https://doxy.me/davidhouliston"}	f	11	JR	\N	\N
202f75a9-cd59-412f-83d5-2b8b8868da8a	47884d7a-9e96-4245-bcec-f5ab308a54f4	Pj Saunders	melsj99@icloud.com	07833456870								2026-06-07 16:36:09.449302+00	2026-06-10 15:40:59.68781+00	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	PS	\N	\N
0d60d8c7-7987-47de-a39a-6319eb6e877a	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Thompson Sarkodie	thompsonsarkodie@live.co.uk	07931411164					Francheska Sarkodie	07939697282	Mother	2026-06-15 18:56:30.073077+00	\N	3000	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	TS	\N	\N
758d9e7d-469b-4f37-a796-7561858f5c18	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Naveed Mehmood	naveedm96@outlook.com	07717536509					Steven Whall	07894433558	Friend	2026-06-15 20:58:41.352187+00	\N	3000	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	0	NM	\N	\N
7318e5fd-f32c-47f0-bbbe-cdaeef268ff0	bd48e910-a161-46b2-9204-8346500fd85e	Veronica	v@v.v	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-20 10:54:46.760189+00	\N	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	{}	f	0	V	\N	\N
d1ee8786-5701-4da4-a7f9-5b5809c7b30e	bd48e910-a161-46b2-9204-8346500fd85e	Paul	p@e.c	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-20 10:55:49.216918+00	\N	\N	6ae879dd-17a5-4fe3-885b-ebadac35060c	\N	\N	{}	f	0	P	\N	\N
38f3ddb5-83ca-46d1-b545-ae066b442dd0	bd48e910-a161-46b2-9204-8346500fd85e	Fred	fred@s.c	\N	\N	\N	\N	\N	\N	\N	\N	2026-06-20 10:56:57.223023+00	\N	\N	11a355ad-276b-4777-b890-409d0be8b66e	\N	\N	{}	f	0	F	\N	\N
0f9a6849-fbe2-4378-b63d-926f489d4377	47884d7a-9e96-4245-bcec-f5ab308a54f4	Richard Wells	stereo3000@gmail.com	+447900511822								2026-05-28 14:46:22.157656+00	2026-09-09 08:19:54.363669+00	5000	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	6	RW	\N	\N
2eb0b0fa-3294-4d66-8841-f4d6c7016818	47884d7a-9e96-4245-bcec-f5ab308a54f4	Becca Leathlean	lubrinbecca@gmail.com	+447817781501	Hi - I could do this Tuesday and the next two Tuesdays at this time - we could see how it goes. Then I'll be teaching for 3 weeks. I could still conceivably do 5pm on a Tuesday during this time, but might prefer to take a break as the job is quite intense...							2026-06-02 16:55:59.172149+00	\N	\N	\N	\N	\N	{}	f	0	BL	\N	\N
70feded2-98f2-483f-a56f-e74a33e05752	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Jill Duncan	jillduncan@hotmail.co.uk	07361239652					Peter Duncan	07943657486	Father	2026-07-06 17:52:56.972132+00	2026-07-08 10:37:03.730287+00	3000	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	22	JD	\N	\N
d06a0ed3-f629-49c5-ba6a-14110212efff	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Gabriel Harel	gabypadillaharel@hotmail.com	07344708356					Alicia Padilla Allen	07948321495	Sister	2026-07-10 09:06:38.246601+00	\N	2500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	9	GH	\N	\N
f942823f-e523-4eae-9237-9f22c7f2d02b	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	fsdfs sdfsd	j@ex.com									2026-05-01 10:15:59.899813+00	\N	\N	\N	\N	\N	{}	f	0	FS	\N	\N
bedb6631-8b9a-42e3-853e-15e500cd7435	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	dsf dsfsdf	f@d.com									2026-05-03 08:08:43.561373+00	\N	\N	\N	\N	\N	{}	f	0	DD	\N	\N
834bdeba-60ea-42eb-a194-88d8f0f9d776	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	online online	online@ink.com									2026-05-03 08:17:22.512083+00	\N	\N	\N	\N	\N	{}	f	0	OO	\N	\N
624fec2c-7b62-49bb-af61-f35746d37ad2	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	I  pay	i@p.c									2026-05-03 15:27:06.79154+00	\N	\N	\N	\N	\N	{}	f	0	IP	\N	\N
a80393f0-28ae-4960-a134-5f823cc3e520	bd48e910-a161-46b2-9204-8346500fd85e	Percy Sledge	info@bookmytherapy.com									2026-05-25 17:00:27.138467+00	\N	\N	\N	\N	\N	{}	f	0	PS	\N	\N
59ce34f8-14f2-4023-a207-006434716536	bd48e910-a161-46b2-9204-8346500fd85e	grun pee	info@bookmytherapy.co.uk									2026-05-25 17:03:29.895884+00	\N	\N	\N	\N	\N	{}	f	0	GP	\N	\N
edf0bb4f-39b9-44d8-910e-e9cfbf36ddb1	47884d7a-9e96-4245-bcec-f5ab308a54f4	Chris Bryne	cjbyrne.uk@gmail.com	+447519364398								2026-05-28 14:46:21.653543+00	2026-05-29 15:19:32.147432+00	\N	\N	\N	\N	{}	f	0	CB	\N	\N
99a4df01-2fa1-4714-9cdc-d7b054aef464	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Rachel Ison	rachelison4@gmail.com									2026-07-06 17:31:29.940421+00	\N	\N	\N	\N	\N	{}	f	0	RI	\N	\N
02ba73e0-f4bc-4812-a41f-07be773c8eae	7de40fde-1f9a-471a-8d37-e9c04bc79f8e	Howard Morris							Caroline Morris		Wife	2026-06-24 21:40:25.626598+00	\N	\N	\N	\N	\N	{}	t	0	HM	\N	\N
0aa204b6-004d-4161-a1fe-0275da723904	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Ben Heritage	benalexander64@gmail.com									2026-07-06 17:36:37.980765+00	2026-07-06 17:46:58.922243+00	\N	\N	\N	\N	{}	f	0	BH	\N	\N
b38cf33e-25ec-43da-aa75-ab9480df74ad	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Masau Zulu	masausozulu03@gmail.com									2026-07-06 17:32:44.919679+00	2026-07-08 08:54:00.773006+00	\N	\N	\N	\N	{}	f	0	MZ	\N	\N
8053fd6c-fa8b-46c0-80ed-085283b90eec	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Lillie Mai Somerton	kirstyparsons789@live.co.uk		Email contact is Mum.\nPTP client							2026-07-06 17:35:14.685802+00	2026-07-06 17:43:36.886908+00	7200	\N	\N	\N	{}	f	0	LMS	\N	\N
55130fe8-186f-481e-8db4-1d6e49c9ae13	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Debi 	debibenson@hotmail.co.uk									2026-07-07 08:12:09.137194+00	\N	\N	\N	\N	\N	{}	f	0	D	\N	\N
6fe67340-b48f-48e0-86f9-84d62f68bd08	47884d7a-9e96-4245-bcec-f5ab308a54f4	some one	someone@theinbetweenplace.com									2026-07-08 12:03:43.536071+00	\N	\N	\N	\N	\N	{}	f	0	SO	\N	\N
8cbc71a0-5191-4832-abd6-78be7544eb42	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Katie Lloyd	katie.lloyd6@tesco.com	07860838018					Katie Lloyd	07860838018		2026-07-13 08:21:52.255299+00	\N	\N	\N	\N	\N	{}	f	0	KL	\N	\N
9624d78f-c155-4908-a9ee-01f1e54f5ab5	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Teresa Reed	teresam1980@hotmail.com	07596 521083	On behalf for teenage daughter	Dr Kant	 Watlington Medical Practice	01553810253	Eve OCruelly	07727421421	Daughter	2026-07-14 16:36:49.973345+00	\N	\N	\N	\N	\N	{}	f	0	TR	\N	\N
8778e261-6cf1-4428-8f91-1594b89a93c8	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Katie  Aggio	katie.aggio@yahoo.co.uk	07946538827								2026-07-29 16:36:52.894922+00	\N	\N	\N	\N	\N	{}	f	0	KA	\N	\N
e04d944f-65df-4fed-b326-697b50753b12	47884d7a-9e96-4245-bcec-f5ab308a54f4	Danny  Tucker	charlenefox86@gmail.com	07713853046	I’m messaging regarding my husband he had an ecute mental breakdown on Sunday and tried to attempt suicide police where called and assessed by mental health he’s since been very emotional and can’t seem to move forward he is awaiting talking therapy through the hospital but I think he really needs to talk now and not wait for that as he’s very fragile could you message me what’s best to do thanks 07729634550	Any doctor 	Rowlands castle surgery 		Charlie Tucker 	7729634550	Wife 	2026-07-31 06:06:09.549249+00	\N	\N	\N	\N	\N	{}	f	0	DT	\N	\N
2daf5d4d-4775-4f80-b0c2-bb725fa6d530	47884d7a-9e96-4245-bcec-f5ab308a54f4	Jane  Smith	jane@bookmytherapy.com									2026-08-10 10:50:11.94294+00	\N	\N	\N	\N	\N	{}	f	0	JS	\N	\N
0a0c45bd-8af0-4c8b-8d1a-908554c0f00b	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Mel Bridges	melaniebridges@icloud.com	\N	\N	\N	\N	\N	\N	\N	\N	2026-08-14 08:43:01.438658+00	\N	\N	acb2d172-d161-48e7-b3d5-5622199e2839	\N	\N	{}	f	0	MB	\N	\N
6d173ef8-8f2c-49d0-94a6-a7ac6be1a8e0	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Rose Mills	Wanguirose935@gmail.com	\N	\N	\N	\N	\N	David Mills	\N	Partner	2026-08-14 08:46:23.740382+00	\N	\N	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	{}	f	0	RM	\N	\N
4487faf2-6de9-47ff-83cb-2fd596695390	9ab24c5a-5210-4342-ab21-472b1a091f10	Sharon Delaney	lilacrainbows@hotmail.co.uk	07484386985								2026-06-30 07:44:44.380624+00	2026-08-14 18:08:51.508868+00	\N	\N	\N	\N	{}	f	0	SD	\N	\N
74149353-981c-4862-8b0c-0ae0ddf5b2d9	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Leanne Gipp	lennygipp@icloud.com	07943857458								2026-08-20 09:28:06.14776+00	\N	\N	\N	\N	\N	{}	f	0	LG	\N	\N
c96dc826-0d5b-4915-9f42-ad4819298201	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	Javier Alcivar	jacomealcivar@icloud.com	+447877052803					Finn Kircher 	+447936131114	Fiancé	2026-08-25 13:24:54.423168+00	\N	2500	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	{}	f	9	JA	\N	\N
8f1f8e39-770f-47c6-9e7b-ef8c7d04ab1a	47884d7a-9e96-4245-bcec-f5ab308a54f4	Richard Meier	richard@meier.co.uk	+447789204712								2026-08-25 13:26:39.784076+00	\N	\N	\N	\N	\N	{}	f	0	RM	\N	\N
55c2d705-10eb-47df-bf0a-bfae2d8a3609	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Frankie Bridges	melaniebridges@icloud.com				St James medical centre kings lynn					2026-08-13 09:42:52.688204+00	2026-08-30 10:10:06.638522+00	\N	acb2d172-d161-48e7-b3d5-5622199e2839	\N	\N	{}	f	0	FB	\N	\N
1bd257e2-a016-4dac-a0ab-027d8172fc26	47884d7a-9e96-4245-bcec-f5ab308a54f4	Craig Austin	Kleanit10@gmail.com	+447561342415	\N	\N	\N	\N	\N	\N	\N	2026-09-01 05:57:16.058327+00	\N	\N	\N	\N	\N	{}	f	0	CA	\N	\N
0c3d11e6-fdde-48e4-9b88-755d674448c1	7de40fde-1f9a-471a-8d37-e9c04bc79f8e	Adrian Brooks										2026-09-04 12:35:48.05001+00	\N	\N	\N	\N	\N	{}	t	0	AB	\N	\N
06df22a6-8663-4f29-959c-e022ff69233e	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Joanne Aldridge 	jonicola1976@gmail.com									2026-09-02 15:20:50.926213+00	2026-09-08 16:17:47.532958+00	5000	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	{}	f	0	JA	\N	\N
8b0a8b68-a2f2-4983-b72c-621f75da48a7	47884d7a-9e96-4245-bcec-f5ab308a54f4	Tom Harley	tommyharley99@btinternet.com	+44 7957 207153								2026-07-29 09:47:56.40295+00	2026-09-09 08:20:24.62557+00	5000	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	{}	f	0	TH	\N	\N
c9751178-17c2-47d8-8c75-f84e5e0ac89b	47884d7a-9e96-4245-bcec-f5ab308a54f4	Samuel Mount	Samuelmount9@hotmail.com	07900411644								2026-09-01 13:30:39.119757+00	2026-09-09 08:19:33.125653+00	4000	a6455293-058b-4aca-b001-0a8868aa69b3	\N	\N	{"a6455293-058b-4aca-b001-0a8868aa69b3": "https://doxy.me/davidhouliston"}	f	0	SM	\N	\N
562c519f-8dca-46be-a9c6-cef031bd3c34	9ab24c5a-5210-4342-ab21-472b1a091f10	Lauren Stewart										2026-09-11 17:46:25.814246+00	\N	4000	\N	\N	\N	{}	t	0	LS	\N	\N
a8c9ee29-6ebd-433d-a7e9-e33a32a4a481	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Lois Robinson	Llpaul86@yahoo.com	07854804698		Dr. Connoly	Southgates Medical Centre 	01553 819477	Mr Iain Robinson 	07736461672	Partner	2026-09-15 17:48:48.776035+00	\N	\N	\N	\N	\N	{}	f	0	LR	\N	\N
702e92bb-32a2-4426-a5c0-47c0b95a0a0c	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	Connor Chapman	connorchapman433@gmail.com	07411931566								2026-09-16 20:24:25.841763+00	\N	\N	\N	\N	\N	{}	f	0	CC	\N	\N
\.


--
-- Data for Name: Bookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Bookings" ("Id", "TherapistId", "StartTime", "EndTime", "Status", "StripePaymentId", "CancelToken", "CancellationReason", "FeeInPence", "CreatedAt", "UpdatedAt", "ReminderSentAt", "IsPaid", "GoogleEventId", "SessionTypeId", "StripeInvoiceId", "NonPaymentNoticeSentAt", "VideoCallUrl", "ClientId", "InvoiceSentAt", "IsLateCancellation", "IsRefunded", "RefundedAmountInPence", "InvoiceNumber", "InvoicePaidAt", "IsInvoiceVoided", "InvoiceReminderSentAt", "InvoiceDueDate", "SessionNotes", "BookedBy", "ClinicalNotesCiphertext", "ClinicalNotesUpdatedAt", "ProcessNotesCiphertext", "ProcessNotesUpdatedAt", "ClinicalNotesFormat", "ProcessNotesFormat") FROM stdin;
0aff4f35-8b1c-44c4-a7a1-f7d4c78abb94	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-09 13:15:00+00	2026-07-09 14:15:00+00	Cancelled	\N	e71181a0-e079-48b7-8fb1-5c94e2da0426	\N	5000	2026-07-08 14:14:32.002997+00	2026-07-08 14:15:07.241748+00	\N	f	8gvgnlchb0rnv56ghsrtefmhq0	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	t	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
4c716c8f-0119-4d8b-a5a7-ebbc05db8069	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-10-10 12:00:00+00	2026-10-10 13:00:00+00	Confirmed	\N	e9f6837c-c66a-4cc3-a38b-e2327d124369	\N	7200	2026-09-06 20:25:49.698187+00	\N	\N	f	935ods0igjvkkkpoivvjd8sdhs	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
2b0e6dfd-d344-4d54-87a1-720d5c77d6b6	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-04 12:30:00+00	2026-06-04 13:30:00+00	Confirmed	\N	042b3b1f-d026-43d3-b039-4593d2fcb63b	\N	0	2026-08-29 11:18:42.415114+00	\N	\N	f	ttgq3tsjonpgt9d04cki0jmcc8	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	\N	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
ce795864-cece-4d81-b0e2-d7ea4b34aa89	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-25 14:30:00+00	2026-09-25 15:30:00+00	Confirmed	\N	e71afad6-17bd-49fa-ac05-04f0a94e88c6	\N	0	2026-09-11 14:23:53.62664+00	\N	\N	t	tevj27lb2nrc2ef5c8dqtn1h1o	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	\N	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
3ffd0ec7-3712-48cc-9ab8-e7ee3d3919c0	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-28 21:00:00+00	2026-07-28 21:50:00+00	Confirmed	pi_3TvJq3GUETlNTofG2r32UqRt	b201ba1f-9809-45aa-9204-e4deba54923f	\N	3500	2026-07-20 16:14:47.21078+00	2026-07-20 16:14:48.56929+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	7bcc6880-0a24-4836-9190-077734a05bba	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
caf651f3-80d6-4c6b-ac7f-d1b60e0fe13e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-31 21:00:00+00	2026-07-31 21:50:00+00	Confirmed	pi_3TwqX4GUETlNTofG3MS1f1z2	66d4d0b4-4c8a-4675-8624-6373d8ed409d	\N	4000	2026-07-24 21:21:29.460661+00	2026-07-24 21:21:30.945462+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
a28f6c75-fa3e-4734-8396-f5f41d8997f6	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-05 10:00:00+00	2026-09-05 11:00:00+00	Confirmed	\N	20f06fa6-0f69-45d5-9f82-0744cb46bf4e	\N	5000	2026-09-02 15:22:35.857141+00	2026-09-02 16:07:01.141197+00	2026-09-04 10:03:50.265436+00	t	di3b9vstccu94clnpdn2t46i1k	f251d5a4-4886-4425-a63f-3775952cf80a	in_1UBG0BGZ7O0g85MyQE4tyCmC	\N	\N	06df22a6-8663-4f29-959c-e022ff69233e	2026-09-02 15:23:07.389824+00	f	f	\N	UJ5LF8YI-0012	2026-09-02 16:07:01.141196+00	f	\N	2026-09-03 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
41534732-6d08-4d7e-b05f-e9852d997b1f	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-10-03 12:00:00+00	2026-10-03 13:00:00+00	Confirmed	\N	8e278f20-31b7-4c62-87a2-8d9db007c72a	\N	7200	2026-09-06 20:25:16.416063+00	\N	\N	f	p7ong4nd0i6vjl4cj2g0nhbnf8	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
f57ae548-4a40-4038-bef1-74eb1ea1823c	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-10-03 11:00:00+00	2026-10-03 12:00:00+00	Pending	\N	cfa1ac48-8b36-41f8-ad1a-5c916732ef1d	\N	5000	2026-09-16 10:48:10.35661+00	2026-09-16 10:48:28.007752+00	\N	f	br9334h2u6sl7e1rqfmeb3bdp8	f251d5a4-4886-4425-a63f-3775952cf80a	in_1UGGOOGZ7O0g85MycnbzyOZg	\N	\N	b38cf33e-25ec-43da-aa75-ab9480df74ad	2026-09-16 10:48:47.68855+00	f	f	\N	UJ5LF8YI-0014	\N	f	\N	2026-10-01 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
11673d87-6206-4de7-9e08-ae3e01822843	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-10 20:00:00+00	2026-08-10 20:50:00+00	Confirmed	pi_3U0T5mGUETlNTofG2uGE4FnE	9e80ba2e-4b1b-430f-8541-9ab928172a8c	\N	3000	2026-08-03 21:08:18.830108+00	2026-08-03 21:08:20.195679+00	\N	t	kuf05psfhfc39avnj355lr087c	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
10403a16-6187-413c-bfbf-1c7017327adc	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-09 18:00:00+00	2026-07-09 19:00:00+00	Cancelled	pi_3TqwHnGunz6NhwSQ1C4ELfmn	357e955c-551e-4261-af78-a6b9907e0b12	\N	31	2026-07-08 14:17:19.595195+00	2026-07-08 14:18:35.335614+00	\N	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
4fd59b8d-fb01-411e-a782-84d463b0b9a2	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-03 11:00:00+00	2026-08-03 12:00:00+00	Cancelled	pi_3TyolWGunz6NhwSQ01N3aEXj	e98f138f-497b-438b-b8b7-d07d7eba3048	\N	31	2026-07-30 07:52:37.812444+00	2026-07-30 07:53:48.998657+00	\N	t	omoe3l3dt9lbhoak402uf8mva4	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
475e96aa-7357-4728-98c3-ade142bc36f6	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-09 09:00:00+00	2026-06-09 10:00:00+00	Cancelled	pi_3Tcgf5Gunz6NhwSQ1an00YI5	34021e94-c656-4a93-bfd4-6ec1de39d060	\N	31	2026-05-30 06:46:26.99699+00	2026-06-02 20:30:30.387528+00	\N	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
8ee754df-b6fa-4f2c-b6bf-f574a9583019	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-02 11:00:00+00	2026-07-02 12:00:00+00	Cancelled	pi_3TneahGunz6NhwSQ1O7ItzVE	cc052df5-a16a-4012-b5ce-e84a9e81bf60	\N	31	2026-06-29 13:13:24.850024+00	2026-06-29 13:17:00.963853+00	\N	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
640b3e17-86b1-4e2c-994c-0e4a95a867a9	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-26 11:00:00+00	2026-09-26 12:00:00+00	Pending	\N	db7915e5-5997-4ac2-8b3f-6bd63fecb417	\N	5000	2026-09-19 12:00:13.33073+00	\N	\N	f	8sldi6841e7vuic2clapegukio	f251d5a4-4886-4425-a63f-3775952cf80a	in_1UHN21GZ7O0g85My6p0GftOr	\N	\N	74149353-981c-4862-8b0c-0ae0ddf5b2d9	2026-09-19 12:06:16.024716+00	f	f	\N	UJ5LF8YI-0015	\N	f	\N	2026-09-24 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
c0a80c08-e112-437f-bc80-97c8ddf9d44d	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-06 15:30:00+00	2026-05-06 16:20:00+00	Cancelled	\N	098f8618-9501-409a-bb03-0f6a82c581f5	non-payment	5000	2026-05-04 09:55:54.431839+00	2026-05-06 08:15:48.816006+00	\N	f	le1fkbgdo1p7a7d5k9e1kkl78g	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TTJEFGabf5vsP4Jtc64F2f5	2026-05-06 08:15:49.586164+00	\N	0e3710cd-d335-4841-a7f8-c998a743b9a4	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
6711169e-d205-4d2b-8b97-5d869f58e5f2	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-25 19:00:00+00	2026-08-25 19:50:00+00	Confirmed	pi_3U6Gd2GUETlNTofG04lo5m4P	37718354-388c-4198-b366-562d0ef7c24f	\N	2500	2026-08-19 21:02:36.467628+00	2026-08-19 21:02:36.775387+00	\N	t	69i3q3nhro6v9v2ti92eti1pkg	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
ffa5cf67-65bf-4df8-aa8e-ca24aa3b701a	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-22 12:00:00+00	2026-08-22 13:00:00+00	Confirmed	\N	878355b5-ad06-4104-84f2-c5bdf270a7fb	\N	5000	2026-07-11 12:07:01.464181+00	\N	2026-08-21 12:04:00.430962+00	f	27dqvb5qq6hha6i36ha3jkddb8	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
b42dce53-f8e9-4af4-bf5e-57d836cb7ade	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-27 20:00:00+00	2026-08-27 21:30:00+00	Confirmed	pi_3U7gHmGUETlNTofG0nHVdOLJ	9bec5502-fdc8-4f1f-b148-ed6dceb7f22a	\N	4500	2026-08-23 18:38:31.672689+00	2026-08-23 18:38:31.98409+00	\N	t	cq8camvo4fe48adhm13mpbka10	dfba3c75-ac1c-49da-b22f-ef5f6244935a	\N	\N	\N	d06a0ed3-f629-49c5-ba6a-14110212efff	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
944118fd-af3f-45b9-8713-0d7bc5b62346	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-29 12:00:00+00	2026-08-29 13:10:00+00	Confirmed	\N	0476a83a-1024-40f9-9afb-f3bb72bbdf54	\N	8000	2026-08-14 08:43:03.3702+00	2026-08-15 09:03:26.285552+00	2026-08-28 12:00:02.037207+00	t	gqm26nq22lhn9k29t1cmgj3e4s	acb2d172-d161-48e7-b3d5-5622199e2839	in_1U4GiQGZ7O0g85MyCLIYascg	\N	\N	0a0c45bd-8af0-4c8b-8d1a-908554c0f00b	2026-08-14 08:43:53.379581+00	f	f	\N	UJ5LF8YI-0008	2026-08-15 09:03:26.284884+00	f	\N	2026-08-27 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
0440070b-c1fb-485f-8e66-e3358b72d353	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-09 11:30:00+00	2026-07-09 12:30:00+00	Cancelled	\N	88264762-70e6-41a3-b764-51489195837c	\N	0	2026-06-25 11:22:56.093309+00	2026-07-09 06:03:11.352528+00	2026-07-08 23:32:07.710703+00	t	kjfmoo7n17ovk49288r0ci2dvg	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	\N	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
34f37527-fdb7-4907-a55e-a36bf8fe500f	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-18 10:00:00+00	2026-07-18 11:00:00+00	Confirmed	\N	3fa30901-5436-46fb-afc3-7a70f7a0dba3	\N	5000	2026-07-13 12:35:48.536883+00	2026-07-13 13:45:00.892609+00	\N	t	h26n6bm1l77kog21iqgmv2ont4	f251d5a4-4886-4425-a63f-3775952cf80a	in_1Tsj5xGZ7O0g85MysmxB7aF0	\N	\N	99a4df01-2fa1-4714-9cdc-d7b054aef464	2026-07-13 12:36:28.959621+00	f	f	\N	UJ5LF8YI-0005	2026-07-13 13:45:00.892546+00	f	\N	2026-07-16 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
447e3e0c-4629-4370-a8e7-1a10d2b18804	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-03 16:00:00+00	2026-08-03 16:50:00+00	Confirmed	pi_3TvOKIGUETlNTofG3xB5t6oW	f669a6cd-f51c-4d90-80a0-0f6a7b4881c2	\N	3000	2026-07-20 21:02:18.026467+00	2026-07-20 21:02:18.331723+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	70feded2-98f2-483f-a56f-e74a33e05752	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
954f4b8f-4a17-4056-a716-f7fa4277cd4c	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-19 11:00:00+00	2026-09-19 12:00:00+00	Confirmed	pi_3UFwqWGZ7O0g85My1qPuR8II	5a2f12e8-9298-4b5b-862f-ecc306370e6d	\N	5000	2026-09-15 13:56:33.400266+00	2026-09-15 13:56:34.753872+00	2026-09-18 11:00:14.371245+00	t	r37hnsh47ud23rbijg962nj9vc	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	0aa204b6-004d-4161-a1fe-0275da723904	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
d10ba3c7-5dcb-427a-b3c1-fec5e4b16b2b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-03 20:00:00+00	2026-08-03 20:50:00+00	Confirmed	pi_3TximdGUETlNTofG0rFfYC3o	adc9527c-06c3-411d-af07-b53e479e888d	\N	2500	2026-07-27 07:17:12.305444+00	2026-07-27 07:17:12.613282+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	d06a0ed3-f629-49c5-ba6a-14110212efff	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
cece4293-9150-433c-acbf-cf78de551022	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-03 20:00:00+00	2026-09-03 20:30:00+00	Confirmed	\N	d6e8d142-b372-4bf1-911f-ae3dac950846	\N	0	2026-08-20 09:28:28.675386+00	\N	2026-09-02 20:03:24.372003+00	t	9q13qtnh4kf2ja7u6a07l2vguo	5975ae28-e5e4-49eb-9a96-d09bc7e6d4f3	\N	\N	\N	74149353-981c-4862-8b0c-0ae0ddf5b2d9	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
c2a19069-02e6-441e-a1b8-2ee57b222e4e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-07 19:00:00+00	2026-08-07 19:50:00+00	Confirmed	pi_3Tys7PGUETlNTofG0hxx4Q38	b6f84487-1135-49ed-8f3a-4bb2824b019d	\N	2500	2026-07-30 11:27:22.247635+00	2026-07-30 11:27:22.559951+00	\N	t	611e89igpa7bsppco5d7e1dc3g	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
56358ea2-2f4a-4c56-a1fe-6ee3fba3b2f1	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-09 10:30:00+00	2026-09-09 11:30:00+00	Cancelled	\N	4a876274-78be-499b-912d-ea34c4439ad1	\N	4000	2026-09-07 11:25:17.469962+00	2026-09-07 11:25:29.511238+00	\N	f	4du32a1b9kvaqm9vs2lg2ibvog	a6455293-058b-4aca-b001-0a8868aa69b3	\N	\N	\N	c9751178-17c2-47d8-8c75-f84e5e0ac89b	\N	t	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
7fee3c65-9259-4b12-8aa6-50ac13b531fc	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-17 20:00:00+00	2026-08-17 20:50:00+00	Confirmed	pi_3U3hXJGUETlNTofG2Q3aBsbe	2d014237-2dd1-4913-a04a-2ce5920cb011	\N	3000	2026-08-12 19:10:05.279657+00	2026-08-12 19:10:05.883843+00	\N	t	ntpof90rlom1smns741p2q7sqk	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
e4b3733f-7769-4686-af0f-192f7513e9fd	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-13 12:00:00+00	2026-08-13 13:00:00+00	Confirmed	\N	e95e564b-94f7-4cfb-84ae-18f1361a5d5d	\N	5000	2026-08-06 14:13:31.444131+00	2026-08-08 13:30:43.86303+00	2026-08-13 00:00:53.818358+00	t	600d5hf1dh3k3k2rvq94dit6lc	fceec855-c5ea-426a-9b9f-bc46c470a6b5	in_1U1S3RGunz6NhwSQotO7x6Ev	\N	\N	8b0a8b68-a2f2-4983-b72c-621f75da48a7	2026-08-06 14:13:56.394827+00	f	f	\N	KUGSYF8I-0006	2026-08-08 13:30:43.862976+00	f	2026-08-08 12:25:17.740334+00	2026-08-11 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
f685b1a4-7465-451b-8a08-e0fbe1dc01eb	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-25 21:00:00+00	2026-08-25 21:50:00+00	Confirmed	pi_3U81GaGUETlNTofG0wNFhU87	ba8d1a75-1c57-44d3-9dc4-7e428ac99543	\N	3000	2026-08-24 17:02:40.155085+00	2026-08-24 17:02:40.464968+00	\N	t	uocvthlncfurhj612omras5858	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
34b3c7b2-e1a0-4dd0-acfa-0fa28836b3e3	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-22 13:00:00+00	2026-08-22 14:00:00+00	Cancelled	\N	0708e166-3008-44e3-ad65-84c206c3cd2a	\N	5000	2026-08-14 08:46:25.64702+00	2026-08-27 12:52:46.289051+00	\N	f	l750s35l17afhn4gevupkmo928	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	6d173ef8-8f2c-49d0-94a6-a7ac6be1a8e0	\N	t	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
df6f15f2-0df7-424e-b52b-071dd34f2da5	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-07 11:30:00+00	2026-09-07 12:30:00+00	Cancelled	\N	f88bd554-9109-44dc-b3f8-683dbc4d2e2d	non-payment	4000	2026-09-02 16:27:12.139914+00	2026-09-05 16:03:22.220511+00	\N	t	2a24afitobul2dc7vnlkqj320o	a6455293-058b-4aca-b001-0a8868aa69b3	in_1UBH30Gunz6NhwSQPLtbAbAr	2026-09-05 10:41:17.051774+00	\N	c9751178-17c2-47d8-8c75-f84e5e0ac89b	2026-09-02 16:30:05.493816+00	f	f	\N	KUGSYF8I-0011	2026-09-05 16:03:22.220464+00	t	2026-09-03 23:04:25.061173+00	2026-09-05 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
3bec204f-41df-4445-9123-1e8db5339e17	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-05 13:00:00+00	2026-09-05 14:00:00+00	Cancelled	\N	024a35ac-9995-4351-b369-f9ba3315199e	\N	5000	2026-08-29 11:58:23.719928+00	2026-08-30 10:12:02.062361+00	\N	f	cp7nfgl679gaf6n1jbah3t1fe8	f251d5a4-4886-4425-a63f-3775952cf80a	in_1U9ktwGZ7O0g85MyyHKHW5K5	\N	\N	55c2d705-10eb-47df-bf0a-bfae2d8a3609	2026-08-29 11:58:27.628586+00	f	f	\N	UJ5LF8YI-0010	\N	f	\N	2026-09-03 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
e7614149-bbe8-46dd-a875-a396c1dbc1d7	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-19 14:00:00+00	2026-09-19 15:00:00+00	Confirmed	pi_3UGPNxGZ7O0g85My0Up5Uvdv	d8103103-9614-407e-91c3-923b5698bd2a	\N	5000	2026-09-16 20:24:56.563934+00	2026-09-16 20:24:57.027676+00	2026-09-18 14:01:18.833538+00	t	8ha17aacsk470u1tqppda6tdl4	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	702e92bb-32a2-4426-a5c0-47c0b95a0a0c	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
6eb08b8b-f7b0-4722-b5c2-f2d2a31385ec	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-26 10:00:00+00	2026-09-26 11:00:00+00	Confirmed	pi_3UHfpVGZ7O0g85My0tLiLSOA	8b08c6a2-b9f3-44ce-981c-4980df94f3ea	\N	5000	2026-09-20 08:10:39.535012+00	2026-09-20 08:10:41.078746+00	\N	t	mrbb8k6fcb59a6637gsd6938ds	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	a8c9ee29-6ebd-433d-a7e9-e33a32a4a481	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
c867e9f3-ddc0-4e37-a500-1b543df9552d	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 09:00:00+00	2026-05-15 09:50:00+00	Confirmed	pi_3TWDWcGabf5vsP4J1oV4HSHN	0dad1875-fa2e-4677-b8ea-e6c6e174f210	\N	5000	2026-05-12 10:26:54.236597+00	2026-05-12 10:27:11.67971+00	\N	t	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	8deb6b3b-4506-4afe-92b8-f0fa2bff8231	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
1837887c-e51d-4f95-b4e8-0558b1313b05	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-13 21:00:00+00	2026-07-13 21:50:00+00	Confirmed	pi_3TrM7KGUETlNTofG2ZLaOaDc	42f648c4-e7be-4bc5-9ccc-0cac55d1e57d	\N	3000	2026-07-09 17:52:15.139799+00	2026-07-09 17:52:15.455596+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
b23ea747-eea8-4061-b620-01d46bc81017	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-24 10:15:00+00	2026-07-24 11:15:00+00	Cancelled	\N	f4c70794-0d52-4671-83fb-7145d0ba84f1	\N	5000	2026-07-22 08:17:33.653042+00	2026-07-22 08:19:15.878435+00	\N	f	hq7qsm6nfobibujfls4aslg1ms	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
dc42503a-a075-479e-a622-155aa73c32ea	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-14 16:00:00+00	2026-09-14 16:50:00+00	Confirmed	pi_3UBiPKGUETlNTofG38RNH4YZ	f50b8cf6-2099-4b35-9a68-15af1caa0035	\N	2500	2026-09-03 21:42:58.46522+00	2026-09-03 21:42:58.796344+00	\N	t	ct3t2lqbvgr71kv6llh95u239s	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	c96dc826-0d5b-4915-9f42-ad4819298201	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
69825343-1639-42fd-89b7-fc0d723486eb	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-26 21:00:00+00	2026-08-26 22:30:00+00	Confirmed	pi_3U3kClGUETlNTofG2Talqeat	bd85988a-ecad-44a4-ae5d-7778625992b4	\N	6500	2026-08-12 22:01:03.320103+00	2026-08-12 22:01:03.703871+00	\N	t	sk8h2uahula16uc4msfe2v4fls	dfba3c75-ac1c-49da-b22f-ef5f6244935a	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
9161b98f-8fc2-4be8-ab55-37b396885683	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-05 12:00:00+00	2026-09-05 13:00:00+00	Confirmed	\N	fbe23fc9-42b1-4f29-8e1d-606ff1c371d2	\N	5000	2026-07-13 17:42:01.23523+00	\N	2026-09-04 12:00:36.644604+00	f	msrao0fkkp39sql636o9r9qk8c	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
d0d47006-2e8e-4bbf-8348-097d43652551	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-05 13:00:00+00	2026-09-05 14:00:00+00	Confirmed	\N	6843073e-9543-4e31-9133-226d561462cf	\N	5000	2026-08-30 10:12:42.906793+00	2026-08-30 10:23:38.446812+00	2026-09-04 13:01:03.426206+00	t	iltjfm6bb3s9gll3d8c76sjmss	f251d5a4-4886-4425-a63f-3775952cf80a	in_1UA5jDGZ7O0g85MyIgcPGEUV	\N	\N	55c2d705-10eb-47df-bf0a-bfae2d8a3609	2026-08-30 10:12:46.221515+00	f	f	\N	UJ5LF8YI-0011	2026-08-30 10:23:38.44675+00	f	\N	2026-09-03 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
e172409d-fab0-4c17-b7ac-69a2c588219e	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-07 14:30:00+00	2026-08-07 15:30:00+00	Confirmed	\N	9ee61640-b84f-470b-bec9-eaac663bf07f	\N	0	2026-07-30 14:32:54.55322+00	2026-08-03 16:26:30.92096+00	2026-08-07 02:33:04.120576+00	t	bmjvafkhoov2hj91teevqaqsag	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	\N	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
684f5713-8340-44c5-87cb-95f3e3a452b6	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-08 10:00:00+00	2026-08-08 11:00:00+00	Confirmed	pi_3TxtnNGZ7O0g85My1J3v38l3	42a571b8-5771-439c-b653-9fc3baeae7c7	\N	5000	2026-07-27 19:02:41.552447+00	2026-07-27 19:02:41.934422+00	2026-08-07 10:00:59.278251+00	t	\N	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	99a4df01-2fa1-4714-9cdc-d7b054aef464	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
b53997c6-b2cf-4c6b-b55d-8b336f5265a2	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-20 16:00:00+00	2026-08-20 16:50:00+00	Confirmed	pi_3U4PjcGUETlNTofG2hmhCRYE	66dcfbf1-9339-4e35-a23e-7f740d2c12c5	\N	3000	2026-08-14 18:21:44.316947+00	2026-08-14 18:21:44.64358+00	\N	t	0ad6ttmijpgo7m98s5lhejmnpo	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	0d60d8c7-7987-47de-a39a-6319eb6e877a	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
17595990-c273-41e6-96c6-938048eb9bfc	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-08 11:00:00+00	2026-08-08 12:00:00+00	Confirmed	\N	b47c1b40-4ee8-4b4b-93c4-5deca6b67905	\N	5000	2026-08-06 21:23:59.896547+00	2026-08-08 10:34:26.49768+00	2026-08-07 11:01:25.046527+00	f	rkc9c3pjvr5u9daiogvtin50ds	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
52b2987b-ee4e-4c6e-bb71-35a43847fb66	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-07 21:00:00+00	2026-09-07 21:50:00+00	Confirmed	pi_3U6coBGUETlNTofG3veKQybX	29ec959d-2bbd-439e-9630-e4cd702ea2f3	\N	3000	2026-08-20 20:43:35.020735+00	2026-08-20 20:43:35.324429+00	\N	t	jfqdh55dluo2769qlgk1u78nss	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
d4bffd1f-3466-4b3e-b2d2-2175b0da9cb1	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-29 11:00:00+00	2026-08-29 12:00:00+00	Confirmed	\N	d388c188-ba23-450b-bb77-6b2e3f8c2457	\N	5000	2026-07-13 17:41:26.892875+00	2026-08-14 08:39:13.274129+00	2026-08-28 11:04:02.427227+00	f	hcreafd3l9ccj81nfb5qkmoj50	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
5a3e239d-8dba-4316-8c65-a00d74e99f41	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-29 21:00:00+00	2026-09-29 21:50:00+00	Confirmed	pi_3UGQ49GUETlNTofG0sQ10aaC	bdaa015d-20ff-4b66-9009-47248680a8c4	\N	4000	2026-09-16 21:08:33.212236+00	2026-09-16 21:08:33.514951+00	\N	t	7pu20ktmblsh2u6huvfuuc13cs	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
776b7554-ea22-4c7b-bce2-752fd9e03f3a	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-16 10:30:00+00	2026-09-16 11:30:00+00	Cancelled	\N	c9fb7bde-0cf0-42fe-ae5e-d1173973b665	non-payment	4000	2026-09-07 11:27:08.194482+00	2026-09-14 23:00:48.136757+00	\N	f	op0f5f3ofbp2hihamllc65jbjk	a6455293-058b-4aca-b001-0a8868aa69b3	in_1UD0kuGunz6NhwSQVv1wGG46	2026-09-14 23:00:47.578959+00	\N	c9751178-17c2-47d8-8c75-f84e5e0ac89b	2026-09-07 11:30:34.6304+00	f	f	\N	KUGSYF8I-0013	\N	t	2026-09-11 23:02:30.947976+00	2026-09-14 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
539fc79a-e352-4600-b36d-5083febc8b56	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-16 10:30:00+00	2026-09-16 11:30:00+00	Cancelled	\N	52fe8bbc-f983-4fda-a106-511d71dd81d8	non-payment	4000	2026-09-15 17:37:48.71611+00	2026-09-15 17:38:51.1113+00	\N	f	eevh3bu1hj34smb2kbukuhi20c	a6455293-058b-4aca-b001-0a8868aa69b3	in_1UG0JIGunz6NhwSQSPJOU9Ky	2026-09-15 17:38:50.440141+00	\N	c9751178-17c2-47d8-8c75-f84e5e0ac89b	2026-09-15 17:38:27.815085+00	f	f	\N	KUGSYF8I-0014	\N	t	\N	2026-09-14 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
e5d1c467-a591-49dc-a540-2c0875005cc3	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-10-07 21:00:00+00	2026-10-07 21:50:00+00	Confirmed	pi_3UGQ5TGUETlNTofG0DeNhbHR	c1f4427b-fba4-4798-bf43-91ebfabd7c9f	\N	4000	2026-09-16 21:09:55.212563+00	2026-09-16 21:09:55.509414+00	\N	t	fcusl0ak9o4kqqadca4cnkutbo	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
629ecc7f-bec2-410d-9db6-705ab85aef3d	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-29 19:00:00+00	2026-09-29 19:50:00+00	Confirmed	pi_3UI6X4GUETlNTofG1EWt3eZA	df50b7cd-8094-4edd-9364-f324022fc618	\N	4000	2026-09-21 12:41:21.891812+00	2026-09-21 12:41:22.292043+00	\N	t	6dhjvi05kspsbv1adg31u6rgms	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	34b1ca19-a0fe-41ea-9836-3f8620181f97	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
9d422ed8-0f32-4160-ae44-750ea8325448	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-14 08:30:00+00	2026-05-14 09:20:00+00	Pending	\N	95074723-0de1-4c25-9a04-8c05d26509dc	\N	2300	2026-05-12 08:26:24.606654+00	\N	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	a73d9024-84af-4937-b298-f1a0d948e7ba	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3bb09a5d-a8ea-4a00-93b2-aa2a33ffa728	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-04 10:30:00+00	2026-05-04 11:20:00+00	Confirmed	\N	fd19b3e4-67e7-4a62-bb60-38bf33e35345	\N	5000	2026-05-04 08:18:51.237837+00	\N	2026-05-04 08:32:18.439611+00	f	hq8ege65lpkk9a4jn1nicnmvq0	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	575ca44f-4e73-4884-8289-44ce8914364f	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
26205a68-cdfe-4add-9496-3f59b5a25e03	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-05 11:00:00+00	2026-09-05 12:00:00+00	Confirmed	\N	8b44ffb7-fd7e-48de-9857-b6035deb0fe4	\N	5000	2026-08-27 12:50:34.812807+00	2026-08-28 06:56:34.881286+00	2026-09-04 11:00:54.41307+00	t	73mu36dje98jpqpbhaemarq6n0	f251d5a4-4886-4425-a63f-3775952cf80a	in_1U95tYGZ7O0g85MyOuoyZ9Or	\N	\N	0aa204b6-004d-4161-a1fe-0275da723904	2026-08-27 16:11:20.316718+00	f	f	\N	UJ5LF8YI-0009	2026-08-28 06:56:34.881251+00	f	\N	2026-09-03 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
f7e744a8-ef15-4823-bdda-8b35fbb07888	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-20 20:00:00+00	2026-07-20 20:50:00+00	Confirmed	pi_3Tre7fGUETlNTofG2lX1tKr2	67159611-ae32-4fe6-bb3a-1538f0104d31	\N	2500	2026-07-10 13:05:48.397838+00	2026-07-10 13:05:48.704144+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	d06a0ed3-f629-49c5-ba6a-14110212efff	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
67e129f4-ca08-463e-afd2-7963fdf60af2	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-20 16:00:00+00	2026-07-20 16:50:00+00	Confirmed	pi_3TsuUgGUETlNTofG1asPcQHP	3066c326-5f3f-4c76-829b-87552423cb15	\N	3000	2026-07-14 00:46:45.691353+00	2026-07-14 00:46:46.006576+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	70feded2-98f2-483f-a56f-e74a33e05752	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
07aa00b6-06d8-4c97-a6a9-cf8e674a60f0	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-05 10:30:00+00	2026-09-05 11:30:00+00	Cancelled	\N	1a09e455-8f3c-41c1-bd85-1bd1538ee87b	\N	0	2026-09-04 15:39:21.28104+00	2026-09-04 15:40:10.610174+00	\N	f	ufnlmlqfhfhf0e78ul78bqoeic	8c4c3bad-8ee0-4685-b500-b54fa71ee299	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	t	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
fe1e599a-fea5-45f1-a799-7e07ae3a1ccf	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-19 21:00:00+00	2026-08-19 21:50:00+00	Confirmed	pi_3U3uWqGUETlNTofG3zO6HN0I	71f058a1-d39f-44f8-8643-f815a0e29015	\N	2500	2026-08-13 09:02:27.86059+00	2026-08-14 14:20:35.046108+00	\N	t	la24pb3ov8iulc1lourbp5bte0	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
cd640017-7b2a-4860-87c7-85b3fa4b5a5b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-14 20:00:00+00	2026-09-14 20:50:00+00	Confirmed	pi_3UD8kcGUETlNTofG0mD6xXxH	0fc54951-cf30-48c0-86e6-0a152ec0a6ef	\N	3500	2026-09-07 20:02:50.521873+00	2026-09-07 20:02:50.827118+00	\N	t	can0fqgn862899bq7m6naiqfr8	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	7bcc6880-0a24-4836-9190-077734a05bba	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
7df093c7-cd5c-44b3-921d-a8ced8f55410	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-01 11:00:00+00	2026-08-01 12:00:00+00	Confirmed	pi_3Tz9adGunz6NhwSQ0fuJwqsU	0c25e7f3-c4e4-4c3f-9ea6-8ce977772edb	\N	5000	2026-07-31 06:06:43.480304+00	2026-07-31 06:06:43.779809+00	2026-07-31 23:05:00.168893+00	t	vukqdl66msqus379ogdcovjpks	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	e04d944f-65df-4fed-b326-697b50753b12	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
fd949549-340b-4811-a9a3-930fccc271af	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-06 12:00:00+00	2026-08-06 13:00:00+00	Confirmed	\N	ba7e7bc3-6f3b-412b-a1d5-13c00b9894cb	\N	5000	2026-07-29 09:47:59.53362+00	2026-07-29 19:42:37.064288+00	2026-08-06 00:02:51.054789+00	t	thqh4fbbcvd9n54vjv8orv7bqo	fceec855-c5ea-426a-9b9f-bc46c470a6b5	in_1TyU6YGunz6NhwSQkgDFxJDY	\N	\N	8b0a8b68-a2f2-4983-b72c-621f75da48a7	2026-07-29 09:48:53.19839+00	f	f	\N	KUGSYF8I-0005	2026-07-29 19:42:37.064239+00	f	\N	2026-08-04 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
c37ba36b-1c0f-41a4-ab03-7ab76e240873	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-14 21:00:00+00	2026-09-14 21:50:00+00	Confirmed	pi_3UD9aCGUETlNTofG3RpFlKgl	1b2cf784-305e-466e-9dc8-3e0537831af7	\N	3000	2026-09-07 20:56:08.020091+00	2026-09-07 20:56:08.319828+00	\N	t	58ca85j46nsi7asqsvl101ehrk	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
7609af0a-6ab2-4440-9f4c-3dcadb088c02	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-24 16:00:00+00	2026-08-24 16:50:00+00	Confirmed	pi_3U5YenGUETlNTofG2rZ2quc6	86ad3d79-5f64-44c2-8711-187203a62a65	\N	3000	2026-08-17 22:05:28.346652+00	2026-08-17 22:05:28.659224+00	\N	t	89d00lisn5o78pl34qgjaq0i64	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	70feded2-98f2-483f-a56f-e74a33e05752	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
c16ed815-2a1f-4a5b-8646-e319aa505247	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-28 11:00:00+00	2026-07-28 12:00:00+00	Cancelled	pi_3TvwnOGunz6NhwSQ0nesnoZY	0a2a862b-c77a-4c4a-b3a3-1136662adb76	\N	31	2026-07-22 09:50:38.14036+00	2026-07-22 10:02:40.020289+00	\N	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
a7e9d358-961e-4302-a388-eb74c3d74a91	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-11 19:00:00+00	2026-08-11 20:00:00+00	Confirmed	pi_3U1sKMGZ7O0g85My2W5nzOuN	5636bd9c-b30c-436c-a0b3-fd57b0c59fbb	\N	5000	2026-08-07 18:17:09.636948+00	2026-08-07 18:17:09.960441+00	2026-08-10 19:00:37.617053+00	t	4l8dpcc140cdbr1f6ngj11cuv4	f2d4f68e-8457-4dc7-a7f3-09267e51e60a	\N	\N	\N	8778e261-6cf1-4428-8f91-1594b89a93c8	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
8eda68c4-1c9c-4c3f-b98e-58877c577d4f	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-19 10:00:00+00	2026-09-19 11:00:00+00	Confirmed	pi_3UG0UVGZ7O0g85My1ZB00FQu	eb68c390-61ac-4dce-adc5-a6747f237f33	\N	5000	2026-09-15 17:51:48.917118+00	2026-09-15 17:51:49.225627+00	2026-09-18 10:04:50.814965+00	t	hmpetqv60u0simd4ouddp5rtto	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	a8c9ee29-6ebd-433d-a7e9-e33a32a4a481	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
99c6971b-36f2-476c-9caf-6f893dfb894e	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-26 17:00:00+00	2026-08-26 18:00:00+00	Confirmed	\N	7dbb06e5-e00e-48da-9f72-a6eb54f08efd	\N	5000	2026-08-21 08:31:15.498092+00	\N	2026-08-26 05:03:59.493191+00	t	f3spndcp9o72thdg7s8on76tgk	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	0f9a6849-fbe2-4378-b63d-926f489d4377	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
7360820e-6ce2-4657-a787-ee0ec67b1c84	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-09 21:00:00+00	2026-09-09 21:50:00+00	Confirmed	pi_3UARVOGUETlNTofG1nF2A3Tl	fdefa80d-287a-4ce7-b850-86fa1a17d449	\N	4000	2026-08-31 09:27:59.15702+00	2026-08-31 09:27:59.471104+00	\N	t	ro358qp8nom08fbsqknkqnfrdk	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
68a9b608-3bc7-4ed3-a75b-ffc300d2de3d	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-16 21:00:00+00	2026-09-16 21:50:00+00	Confirmed	pi_3UARWTGUETlNTofG1q4tWbTv	59dd1ec5-5bc4-458a-bb2c-76427eebc3c0	\N	4000	2026-08-31 09:29:05.273229+00	2026-08-31 09:29:05.564869+00	\N	t	3m28qfghkrckjtk390g817hpno	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
e9f3b159-2ab5-43f9-84dc-2da2c3bd2147	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-16 10:30:00+00	2026-09-16 11:30:00+00	Confirmed	\N	861137dd-f04b-40cc-91b1-19a3a057b8f3	\N	4000	2026-09-16 06:26:16.863845+00	\N	2026-09-16 06:29:01.032157+00	t	uthrou1r68i0ckuoou3r7flpns	a6455293-058b-4aca-b001-0a8868aa69b3	\N	\N	\N	c9751178-17c2-47d8-8c75-f84e5e0ac89b	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\\x0141a5484647a75480a2c36e15035eed626b83743f81345e3efdcda57b455c85b0e13c07ac3ca37dcf96562a7e2a1c662e03d1b14a3fb9fe7d34fb0e61d073f0d4177a4760a6bf791bc49cfe2e47d13e28e5fd839212ce609423dd1d278185dc3aa47327dc303cd657c9a697812c1e78851511685bc1befbc9b06d1a884a7c94d5991128ad7580e463769b3d9e4e48e1c541f33684537b96e59000e152f32357107cc867a9db54f7c6b6b95f0d1e9dd41b87128b294819900a282fc0ec59f01b1083c46abb0d8153d4dede455c94166d00f29457c996f95340afb728b22a3ed95639f89c43a99e0c77439d2b9bc862e8c3475648c8fe24c7158ae7f7e8ad8e4ef2c77b4ba33229cf5f4e6ce8a1182a1b675974a66cb502332a3ac7931e305bd69f	2026-09-17 09:50:51.829578+00	\\x01af806f8604c7567f616e03b55d4e84df0377527393696833ec9c15d597e961d015512b8f7c3dc0a5cabb762e718a9a1783e580b3a68f6b47986c14597520e728fd787c8e395550ce610eb95d67d660baf48fd51050a197c3d4775f89aa1a25d690e3e94a1995351b6a859af1256d7dcb5399fe0cc80f0584d2da584c99921b2915e746624aaf13b0712a31ccacc21dd97a1cf16188bf8bc8eeabbb0c5526d283f6903c4d474e872678e4019416b03cfec9bc68f235d2f8baf7ffbd3470c102905c98c7b00c7cbfe833204225d2f1ffa3a9d4a26d1c1deb8fe480d5a5c0a14687a9de8e38669c00c5baaa41126b3ec8a04160f2ebcb9ec920ada9826aa550c29a422d64ca0c811412ce88eb45a7f69c4afbd34a4aa1098aef155accc585fb5a43d6713d601222df57e6c6cfec770d41df002d8f636960c1e6d110be8909cbd2da1ea66e82cdb9d24656d848c311a318a13a11db5364f2e0cf8877ba002a94d213b8548c7b284670e2f64096a946e487589faaf72eac2debe66e8115c22e73123d3fd99ff6e53f56862bb704c62127626d03c774cd69895197a2b42e7511aa2b3e2e48c07f124a5fa27eb61d51f636a231df865ac4c4124450c6aab50f475cae412544d9934c916fbd17b2ec9874c6c5cb59234815e33ba8874ac092d78508dcf082d8796b44228c1b2aec3a99d0f10ea7e3ff17f8cdd1941b760aa43996220ee18130bc6ee07fd033e1b93ef6ee411396e026819d2c35774349c1cf1e5d2873fff0da3a00fb8422311a00705ac2a8f4e1cab7cdb7f90fb797a896aabcec3f06e3b3353c8b54a92f83499ab71eb2c10de96692c7508f366645e7a1f4111d14bdfae95f9c2655795c4e9b99d6d183e1d0d9d60967c00c85ff542e8c645bc016b16bf1df6651818537f5556c71181b11b814e4d924779be912fd7f0347093804f49c7ea645be5873774f719b9a115a05dda58381c8ec0c88462cb2b88038ceecd2c778bdc110c82416a00cc8f26a1891c4a72aaf6fedb30b10868cf174adf2fa54924f5feb07e7267ccf329c54418f15c5368d901a3710855004ab860c5f9eec857d3c9af044c9468fcfea76ae1d0d19f175d7bdabdda2582080d1c4e6e6ba31468bb4a9f166d4cab492295188f12791682469753f0ae4a6dc9113d7a2fe42a20aed5e53f105f7b3dd394d2eda2fd3804d05033e0e2bee054c426972deb04ba2c8ac3ff4a7152a4599af983dbdb9d2bd1c3ed7796aae60f853e5f3337c2a05cb9b6da51ca4c74f39e38625b54139cd03333a1f8f81342e8127b66fe83327e61724976abd01a97f24a09593eccbf2951b51132e9aac38b7bdcd5906c32f0c74a663cb29cb81ee1897e8fa52833375d28831b2b40a29f1f116fc6416d3c57edfc5f99e3fd3cb435fac91dba21284fa01faef9f255e00e9ebfa570af8873152d3aa4605531d71cf90c20e8e486807102edc573e694edf77615969c90df8d1031df47ed50e3975bb2023937606576c5449bb823622f1580bbc0f16e2ce8657630aff2e4267624c02a6c072c51b035a9a2852663d94111924c91d823efed4dbecbc4c1b2bdb0a12af37a4292edc03fb1efb0b3943930c69466706f06f5f254c40f0ccfb5db482c1f1c79fc54b3e44df49a2b6020a781b9a815a42bb01219eb8c103f7213fd211efd37e642bb2fe1b8e985d254ad30a2e6ee193aa82cb86c997887600c0af971e1729923fe326ebcac53ac81cf0197adeba562f4954a2c489517a3cf8cd6d7720530e92b24a1f8acf11756a1d66b86e91f91b190867f47732939b642cf6a2d0735e1905009f028a53cdab249ce7328ebf8839dfca38c78248188340ed889df4dae857a69c94aef35156c5dd789168e36a4efcb062b9651d50b22dddd794e89d3504a489032114f8b01b45435dbad9c2f82a56a91803fd33b0d35cf71096fa57b4f39f3131fe210b6c00180e74f03556fb3409f5d9e03547ffc525c3de8a36f81cb3f598b78637e3080c5be77b823821eac27437ca319591a0f96956d48ec4cc56729f48f0eedb591cbbd3001c991b0e6d3b9563d379bacdfb52da92a0f87f6d98f0a633070739f9af56fd8796741e44972c48c5bda34a3da087aa4ab5bf49b32d4574310afc96bb8234a30d67fdecb3c8cc74f6c013a182e115e2970a97865692aca94d147bb65699ad4bc59312c837806596ef815e3ab9797c9eba4e5425cc354a09dba1d32eb56fa08b738475d61e44e9faf63568f9b35bb7f2fabcef06562d4aecd63ba7dbbe95dd939d3416f0dec41d1bab6caffb2265ea286bea7f26c1fd45e9c11f67acf9dc4789fccb011006eaf558580985842e5cee4c95dc634dec243257984e4ca19cd5b472b574949db20d8bd28e79c718230f17d1e0d8e68b28a8b6cc7e664df6dac86ea4afbb16736aa5aaa8b1c6db9f0b641e6dfc870d9443deee6eed56d0747c4e2f370b797bf19753c7569313ee2324932d42f924296b9415fdf5d755a42a969df097de66ebc1658cde427c17b8cca5cf4ba701af397fa107296f2baccf63f7b08c2207c27ea5bd42cb4feed2f126cb25787dd5ede6fd62413a0842984a2c63c03b25f5499267fa248c6715dfc2ee02fcc08d22150bc59e34ed4d4d3ceb6c10d8f3292c1da6eb19e1ff7684462727963d60f1ea7e8df704b98abd3f0c3b981a82a963b6c129e2a339100b7baed4c7a25a35beacd0e1a454445f855b20ee0889dd03d75de596ee055dadfb51e79f343cbcae3891e9f278d8dc28e79ef5dc9a62de84a06809f6cdce415bece3241ffb3cdf0adf05a6b164c7777f7546f11ee79532504e6eb6f7b2fa8e7502ded2b77fc401c47ac6ccf585318ebfb55c4beaa5b3c018c7c76ca8d7062d44a6d2c03e4ae23c019abc5a1953170c99518a65230f7f94951fa01870424d4c09715ace77e000fd7d8eb6be5be85f10c3bb04e721c058e465494767f77084f8f3a807b05e8d19954d2fde29067f372494b1596ed6a749b80ab9b87e55e8743f796f9ead32c2360dd7e91a3f264d6c6d9e5e82b647314b59e89698618a2fbfa5bfca9f5406ff9dd38a2ab32d10b415b2e95db14fb25747826fa72b38882f9760d65ae49dae76da9c285754238b3bdaf4f5e6a394b4efae4d6f78a95e23c66945fe98337b244295bd720d02ffd792e4dfd8db620337eac8f5fbdd9a68d3f685066fd84b07498458b1fab39aff5f90c01942b28b0bade55625c60ba924f9d2c64639171fd40d6446ffe974b34f60ce52c14d592f39cab424ecda7fed2ed9082ef9a7842c6df871b2d80a1e8c4649a889aadd8c90e611cf702000912da51e243626b10ff3f2a5f88fe6e78eace5f3ea3903f6340d9827a9a7910b83411a319aa0e307e9b0d113c5143e7ad7c5bad156a495a2ea98a9458481c226d17b087978674e8bbf93f519ca24a96b3507c986816c2fe9d7d1d711665914384883d6a5d791ad09ccb85c54ee7e0897c10329bfa95df9548d3683d1ee8677d1e3552cdb756360348b20fe2eb0aba9b6c901cfe2ecaf34d6170231d30c1889474e9eae0f3bdc176090380f8ec5dd6762a33f9c5a41aa0ff452f77d90afa3650d6111831c74313d76cee5c9178d07005db35fc255c2f3ddafc74595b1838e73f86b9c027ec7c948c4334d5867846f0d1efd30dda66086eea0826435cc8d5c1b21e6ceed54f69889c03c1c480154dfb33fd374534fe6489392f5a3e2b8fb1a2661a6cf2a700ed800d961dc94ee14c0281dd7b8b1395ea3d3ad40a8822551929d73444fbf0c1e0fb395d5aef66fdc50843fdabf22237a78192dc476b7ebcd7a52d7127940b18b968db9814e14157d01f0722ea8f7a43f31a6a8008aa01c944063e5d0c61de66bd7cbfe1a023726c982df3769e2f1fcb7b15ff3552b5eae4e065565bb453af3509a03ab4e2e045df1004b7b82f20a4f2d4f3b9b9e3cdaca81830fdf6510f938a04d8aecddbd1de4b1b40ffb294c8787f75d9b80f995fdcdf56f8611603e89b74a3bd604c4d09d8bfc4695088fbd809095bf86ee9a7bdefae3e9de58f49bb6305c0422f7e2a5577797c521ba3c21a5e596d19ff21b1bf6af015bb25653c8dccdd28c193c302b3e562ff6bc73ce04e5ff02dc8396e6a795b20f0e373cc7b0ac7a8ccb01cd6bcb04d468c37dcae415bd793266e1d07432aea60caf9c1367713feea0c44b9f6246b5d1cb3691123ace5bde0ac4f6107075d8adc229b359ad166e7441f32dc0206773cec3ed6ecea43fae443c80e0c1b3901b0be777df959f7d98b8894bcc8fa0c2a57f14fa32508068a200572fd91a964cad58188ce1bad144018cda2193a0260b1b86ea6e83da0a37c3bd4d3bb988b97825dbaaf114171a832f52167216f01fd3d36c094c15d2305f42618360e5177589546830898b8fcfee2e55c958622d601535d42c5b28176e181cdf2aa6a03066e92f99139936bba3e3e0a4c7ddbd3b8f6d35257a27a93bb784aa34d098d9a56b4fc2d73e6f9ed141ed12ebbc63f1bd27bbce989611a2ef5077f67f9e24cbd6e694be3de00c8e3e36e529b70fc1b99dc6acb35232977b44aed92a3d9dabe3440225d44e60ba10f0fdb8e2064e96adfd28dd947a2157d9d43c338a6885005525d97f57562e7bf9fddb1f9cc0ac70207467b96ff342f4f7a613b11a66dfad4a4e5069c5863c27b7f017bc1b68e84ad59eebf95a3117385b0856f5396c3b44282aab25cfce9e3de3e73f63ae56cb38cbf487b3b9c92a1526b822bd54a2d830f93bb7f57c7c0ee1f838a33aa4dc5209f2e9657e954553e08848ffc6ba0ea8d521b56912cf28b9a09543	2026-09-17 09:50:53.746138+00	text	text
fa66ea1b-6b59-4741-8fd5-2cb717f16e4e	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-21 14:30:00+00	2026-08-21 15:30:00+00	Confirmed	\N	41e2e874-d3b4-4a77-848e-69dfec8f74d5	\N	0	2026-08-21 08:28:48.629389+00	\N	2026-08-21 08:32:39.988617+00	f	77ikjr27hb58jbpcd46l7bggl4	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	\N	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\\x01abf182b1835b091064255db7029c5a7768ce82cd8793ef10ee1617948d5681e202c0e0bd53642ac435e3b799d7296c2e00319ebaea10b9ff85f6cf0e6cc37dce370ad54211b656d64d1a57f5c4d74d4ad8ec68674fa015acaebd5c75ff2275b846ad194a6a041cf0144e1718c18e6ce2395fa04239fe1b79545922f42da69587c123a1e4ec3c5318d6c1455e037fc9aba9324274d9897f5ebdbf04faa498f3ba9b74b3a66457	2026-09-17 11:06:31.966558+00	\N	\N	text	text
156e6994-e500-44b6-b1c4-f3ac3086e37a	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-30 10:30:00+00	2026-09-30 11:30:00+00	Confirmed	\N	724e7479-1237-40dc-a917-e3ceb3e296ec	\N	4000	2026-09-21 12:44:52.474454+00	\N	\N	f	2dnlh3ffntmpdgt6jq08pdh64s	a6455293-058b-4aca-b001-0a8868aa69b3	\N	\N	\N	c9751178-17c2-47d8-8c75-f84e5e0ac89b	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
40ea68e9-5b19-48e2-8968-ea364f3a5857	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-26 15:45:00+00	2026-05-26 16:45:00+00	Cancelled	\N	5a123674-e089-4b6a-a956-a397efcf128e	non-payment	33	2026-05-25 09:58:33.613985+00	2026-05-25 19:54:08.468096+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	in_1TazPlGgOqknbIQ3f7EdvY5K	2026-05-25 14:57:50.552759+00	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	2026-05-25 14:23:37.108194+00	f	f	\N	NLNFFSVW-0004	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	text	text
0027e211-2b90-4c2f-ba23-7db76353658d	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-03 12:00:00+00	2026-09-03 13:00:00+00	Confirmed	\N	7dcc9e69-87c8-466c-8b1d-db4ff2d56ccc	\N	5000	2026-08-27 15:59:09.237579+00	2026-09-01 10:08:44.566384+00	2026-09-02 16:31:57.640738+00	t	uo4cetcsd08gs09f5pfa70l10s	fceec855-c5ea-426a-9b9f-bc46c470a6b5	in_1U96b5Gunz6NhwSQQ2qUpdDx	\N	\N	8b0a8b68-a2f2-4983-b72c-621f75da48a7	2026-08-27 16:56:19.667363+00	f	f	\N	KUGSYF8I-0008	2026-09-01 10:08:44.566321+00	f	2026-08-30 23:04:44.105841+00	2026-09-01 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
574bb5ce-343a-43db-88ca-03999370c5b4	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-14 19:00:00+00	2026-07-14 19:50:00+00	Confirmed	pi_3Tri3vGUETlNTofG2toTJNYl	0af81453-bbc3-4a87-a1f9-7313184e34d3	\N	2500	2026-07-10 17:18:10.945616+00	2026-07-10 17:18:11.26828+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
08f16be9-2f34-4c1c-8a8f-ca40c0e1bd52	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-18 13:30:00+00	2026-07-18 14:00:00+00	Confirmed	\N	e055801b-19f8-43df-9bdf-f63483fe2b87	\N	0	2026-07-14 16:36:57.758765+00	\N	\N	t	\N	5975ae28-e5e4-49eb-9a96-d09bc7e6d4f3	\N	\N	\N	9624d78f-c155-4908-a9ee-01f1e54f5ab5	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
b17b2739-bfd0-4f48-8d09-5893e067c9b8	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-26 19:00:00+00	2026-08-26 19:50:00+00	Confirmed	pi_3U5lzmGUETlNTofG2o9qzy3r	0c11fa73-eee5-4993-98a4-b0c2bc626d71	\N	3500	2026-08-18 12:20:03.525056+00	2026-08-18 12:20:03.835993+00	\N	t	9lb3hdug99an5j3v3f0c83qhlg	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
10668d41-380f-4b42-8241-7166195aafbc	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-28 11:15:00+00	2026-07-28 12:15:00+00	Cancelled	\N	fc044d66-2941-4b67-9530-e4203002e919	\N	31	2026-07-22 10:03:07.457317+00	2026-07-22 10:06:03.141132+00	\N	t	lkl1d4ce5v25vmdd6mjfob62s0	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
28bb48c0-f910-467e-8ab3-80d2b49617ba	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-03 09:00:00+00	2026-09-03 10:00:00+00	Confirmed	pi_3UAkh2Gunz6NhwSQ0MikyN84	cdbe8812-269e-44db-a937-bbc2fe701f91	\N	5000	2026-09-01 05:57:17.734523+00	2026-09-01 05:57:18.168729+00	2026-09-02 16:31:58.139078+00	t	vblhv5tbib09aciauiv8dckeh8	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	1bd257e2-a016-4dac-a0ab-027d8172fc26	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
cb7d490b-ab2f-4176-9d43-22875a971550	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-03 21:00:00+00	2026-08-03 21:50:00+00	Confirmed	pi_3Tz9zuGUETlNTofG334sA6wr	7d311041-0a38-47aa-858f-0496f673e7d4	\N	3000	2026-07-31 06:32:49.371604+00	2026-07-31 06:32:49.67343+00	\N	t	mkiaqeml2312gkmn57ha3sn9rs	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
3428a656-212c-4e2f-8986-194abb7bcda1	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-06 19:00:00+00	2026-08-06 20:00:00+00	Confirmed	pi_3TyaV3GZ7O0g85My0genE7vV	2f5e27c2-1c44-4c1d-9b7d-f6db1db193a7	\N	5000	2026-07-29 16:38:37.523052+00	2026-07-29 16:38:37.968065+00	2026-08-05 19:00:53.25356+00	t	\N	f2d4f68e-8457-4dc7-a7f3-09267e51e60a	\N	\N	\N	8778e261-6cf1-4428-8f91-1594b89a93c8	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
aa06c930-3511-4575-b818-ce475de47fd9	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-19 19:00:00+00	2026-08-19 19:50:00+00	Confirmed	pi_3U1togGUETlNTofG1LQAOjcu	a07983c2-fd24-486d-94fd-a1a12e1c2ab5	\N	3500	2026-08-07 19:52:33.587057+00	2026-08-07 19:52:33.895013+00	\N	t	740bucptgko1cluo96nre0q7d8	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	7bcc6880-0a24-4836-9190-077734a05bba	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
21150657-76fe-4b06-a3ec-3c33db793d79	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-21 11:30:00+00	2026-09-21 12:30:00+00	Confirmed	\N	9382052d-d3ee-4b49-84ab-2a1c2d6c7944	\N	4000	2026-09-16 10:31:10.65766+00	2026-09-20 11:32:00.704367+00	2026-09-20 11:30:56.885804+00	t	9e35le7u7murj6b93v2a33h5a4	a6455293-058b-4aca-b001-0a8868aa69b3	in_1UGwATGunz6NhwSQsWQLpU1K	\N	https://doxy.me/davidhouliston	c9751178-17c2-47d8-8c75-f84e5e0ac89b	2026-09-18 07:25:12.378126+00	f	f	\N	KUGSYF8I-0016	2026-09-20 11:32:00.704332+00	f	2026-09-18 23:02:56.997233+00	2026-09-20 00:00:00+00	\N	Therapist	\\x015ad80f15daf29cb08426bef01f32abfdc095fbd72e755bdb7516cc7a91736041770e1488e89a300a7225fb340cbe1b6257401997ea40787045a0996c55de143f5271e38e48096ff72cf658cbd94d6fab5a7f12c4127f58926e0ac2943eee33879182eb60b3fc9880188908743ef8766f5a0f905aeffe7514566b5d1551448204f2fe28359d8b525b0ea53cf4d2a4c12079dde3de562fb55c40107a639eba5ae5e27f9b5f82b52bb82447ac540e5c7bf98d63d53def68626643fa194e72b0f5903d809a40744636cc534ac9902bcab9c34d021e131dac1886e1414ae9c42cee5e541a026412422bdbbd470bb386e28d18010fdf071a0ad49cee6d07fee91d693e25ac692d95e7916d4c9955234f7fe7a5ee08efca8665e32e9f9f32f80024f193720004cde3561025feea0ab9fc7a55eeee2feae346a4bf67a584d3b36a96aebcf22d4751c9461ed0163b1c252b9168c527bc0d4c00ce0db4e67b15eb95f25f07266b922e1e40e07292a0b95d424501728accc77b6c1b83f88c496276f94d43d9426e160582da66fd19d910e57feb8f16c4ad3316db946ca99c980857145a866dab87fde5a358ce5c982276204c1330203c3d7043bd41ae64702b3570a6169cfa07049159505d01b1b30bad75fcbdd6350afe0f1aebcc0867d8b4b7a3db2a8c1572ddaddbd3f608acf538acffba695805476e1bcd1601176e285809b378a7a181779f72c7472b18adc8cebf1c50dc347fe817fe911b00ade6a8e01e3d7210c36a7ee4165f6f11004e0effee261da48d8cb727b850f2d55539afe603357ca4791e5c2f626daa8872955295846817960d0ccfc732342a07a699cd49fed6ae881b6457a58520de1fed38946543ed9a7afd8e529dc261160d0364010449a8d39cb9d5a05c51cfd8d9118e42a23e7341e581c681c794af908c84a7a492f34e6b78f5736662d6e8f620220962a51f5445870b1f5cabab2ed00833d61316b370d4077d97b672a16214e8aeafd1f59bfe2983fe06f33060ae034f9ce9c2c903fe3508727829727a910648a527a4480cbf3b227ed26213c67ebc83b6a531c4917cb196aec226fee6f70225a1c46cb31932f6557de2fd4dedb83d41a8efdfad3bdf0c22cd860a74e63c97b689fa16e25254ba35d97f142d5ed3187cc557fc4d4de2a8620a5f9b1c4d7694ffcc14237658a3f208dda88a2e48c81d3954b11b61168a1ef8c89db641b088d556d44dc839aded19a19ec25f1a59910a1d425e3ca0ef97fd23d546f9269e25cc530d376eab4b5739d68d9d2abdecd18b33304fda617034e3ab0898e8c54842bb8af38dafca3b476ddb9467e8eacccf10bc29d2de2bed688fdc4bb20805af94a0377d6661c0e00d7ac5a1bcfffd2707b30cd9f6eedc173b7d455cd41984e1b549f2adce6422c066aa29d703e9fe5f160111ae40876cdf8254415361425d4eb83186bb768bd99d72b32df6ee409fb246bca450ed1cb7a95aa3126a1595fbca81c85553f9ded6f29dfd51d92dd8e7b005c43df40e63c0e0e225fce4409d6c77d736f86172872545b8b75b8e3b99b0469c649eef62ad51706862ed51409a8bc26f6670f97a26634cef77166a22eaa9c3e830605ef6fb7f93afd8a0b9d2777b600840566df5f62676c7214f10bb49e064222935dd319f40542c97220692a0b7266144d6f184155a2c1993eeacd899df385ab8aca6a3cb391d1012e7fbc56a45dac1665ff9072239e80025ab237ec622e98f8ae1692d2a465b454e064283a76d39177b41bdc4857c3874dc2d4afb984ac1557227cdc26f700dff97d8076a539b38edf09d955f298b8db3f5e35fbfd7e782f288ffda7743a6e5c82995a15780d6b6a410d5b403bf8f46377a7c9ec9477a3997a63b4cc8e55ef07920c3d1787cc542a12bda7edadf2027f599a492dae480438a341afc4cadd76240707bca52d78dd0a34143788486c71fb5f535a7b9995c23dd5c52c9993439cb09060e1252f76bf0189aba37f3461255098c9c498ec54bca4a902567ac01e4d9788ade4dd67dce3c0a9971d117fa204c53f6a1ddb68fdee39ddd837ae348cec311925808b1e20f4403809d1b5d085c458c52f8683c306fb1998dd2a6a6517fc2c915aa3b91c54e0940b8136b609a7c535137aa3772dd2d4a0dfd2f5332d5435be475f4139cc759d15236a8d8523c807ba74e4eb80a233b85997ddf24254bbfb398355c175a40260f4785422356ab802d2f8e55a61cc67ac9a2e4058d1750d85860b2354a5b041ce1de940c14bda1fe2c8c7a3ef040b904b387e47729ae2a58fca27d56b1f29dd00e2db1eea021858a6486c7718e78184284d54f09c0cd03e87fd504668e29c57a29bc6c95a3bbf6988d100e12ceda375ee573a2d0bb85e62108cd6ad64a95e0057b79d154e718baab821f0b9455c96fd087fccca1f758bee93d2ece19bac5e369478e1a357d4f0399f9ede354cb4c2530e68b0b10003c66e62865b9acabeb1b1a5cc37a87912c96b34fbb2ed137cb373e8537021ffb9f2e9e8468d981044dd90fd25139da2b4adf73ab2b81ce1af02204b0295bc70300107b5e907903f07203db768e41b6dc64f15435216ca1fd1023192fecd66200ef69933b5b4965c434c3c6ed427113ff0d925da6fb7b08777e31de7814754c99b292e1ea3469bc6ba3929115d789f6990071e18d90a7ad8800b85174ab3f8ecd2fc19c37a7e8b5d009edcd3ec076282e38b881d6809716bbe2d3b47d7c842e36555b21bde07bbd286135f9c3f78563acb7dcef6a62260e5e137a3fba44688c15b9978a7580b27919e2925e9fd49f11ce25dd08287141bd822e7da636caf0f9530369af478056cff0eb442941ffb56113b0c89fe7d8fd566c2fc07cf96844a14b8315afb3cc102946e0cabc7453f5220484690bbca756836c27dc5e8755808b1213698f84679c8092b80a5914f63be70d8a21f292e857d0f0d685f77541186be6852819e1ae092804e1aa41ce5e9754881dfc76769b522688ac6536b21e3dbe172fdf6d9ac529dae864bc0abd8a741c6df00f971d06be7d12d985f157a19b3c0565905f25f23aa2b4408037d948af544e3b40700f9816b6f0289559b9d2082a851d4ebc837fe54377c41b26ebef39267146d4bc656a61c9d9d4362b327c669c58977bb5e8064a531b6b3c7b8a73e1aadd84e51ee072488bd20b50540c5b1c97e70624	2026-09-22 10:02:13.197028+00	\\x011ebddb2c26799ee782a228ff0205aeaf8922e3a161dc78fb8bf3067b05184be54c716058eb42656a5b0fb1348a2dc47a3bec8b9438fb4ffd7bcd1257b9a5f3bf7fae6d4bdc9ed9950101400b4993ddc5ae3b18ee1937fc338584f8e863bae037ab64a96cd236da15033f836104e0fbc55c51a37f539b28e84e222300cdbb651cfdf2c32f2065574a6e983f4ff8f8d0c05cef3cd412eb5383d570355ba20405c81387482aa037cd70b72caccfc4b8aefa5acb7092151e1e1fd6ce4b080f76088cc74b1e6116d40f7a79e84a3f425a46185acd86f86479e52cf18c7613d48b39f1cd931d695d3871cb594ff9c4e9b89cb99ab08ffcd35e17a5b0c2a6f2ead887ef8fbe3615e21af42e5bf7d5c3388759ec8639e4b3dae4d469df2ba47fdfa38e8767803dc351f336c05d4b092045cc0a0d3f3e34ade03c4fd00e68d558c0ca91265fcbb7e7c3acac6eb30002655727eadf28187345db1b71eac078b6401f068831ad8859b7a0a6ac86beefeb1406f3ce57374008e172e7edf78e43900def8b8500b371746c99cd7238f036b56fcfacba24895cecdf560215983cf66259cfd8975e01dc530553fefd33a310755604e4bc2cb85eb64d14f1a8938648a5455ccd1d96057bfe9e66b270041957d08330bdcc7c85170a779963b2fd6cc952e655f8fa1b3f9a6444aff941d173529871bfdb541f62d8e2853691b8e518fb9249fff0afdb2863674a4c0b3289a1a8c47e8804e72933f3489f79f028de1df2395c2140a945d2b1610a803edd3b6fbe7cd57d75a571cd7dcdb216f85b6ad0255730991b34e39e7201b5708a8223d2f9e2692737083b3ba783d8d391676c9c4b0a39db8368d8b54742b5d75d6c6ba746ab6aecdae708b486b60057c2cbf57ae82094a09dc59c5e9293362a1d492cbf35fbe67184484f2188dde8740fbcbaa1c1cadace1b697deeccf8100dc24dfbcd168334b182683103677cedb35697b3960697b20fe49874e996226120fbc5e89c5cea2b06a54751e5b596aeec04e8fdd566a86f36a499691061dadb9ac8679941fa089cb9e9bac6d49b77aa23720a6766b0cce6f20c3af38aac9902ec570ab4e904d9d75d9006d4f4425a1c7f80076df2515b56df14a6f79a745aea5f38a46c5b365a4838515090aa97691d94a1de7e04d3e711a9248e92eca71bd9f7aba035371f6d2e46d5ed1f11d91cd1de8f308d544c65e717c4e4c37178f8bba9f47eb45a0d57a9bae3a28cc860ea3f16688a6540b657fcd540d71fc2332611d20d29ad9769cfdbe1f009ff369dd4848fb9e66c7b73e726ea978931f4efa7b539df98f1491d86782fa5d3d62a0ed2d0b5822cdcc8a1cceb31bfc6be5b3f6614da2aa7358292210d830ef9eafecbe4296f272c7dc54f0575c5e97f42a7f555ba640c77e8d3357f3f30e9cfc232ec1629f4ad9eee64f9a3523eb1ccbbf586f74b1e444b52dee790b0a02fe7668bbc18cef2e73def6934c8c375df7ea7e0219767b78565d459bd8441d94cb852b880e87eafcb640cfbf5d60b2d1fe94bf98caf3e1cf1a1989428ee51b060347abf10d29277808f0c6e51db450d7a957b5725bc4a4f113c75ff7a0d473eda816fb4ade59f7ff516b189c45e48d5ea5baf7e9e181ef92f891dcc39aad26277c4575e296a36162792e2578075ca5a514d6b4cb9f6174fffada5b5b1cf0299980472a73fc8457c400f5ce13944706fba7c6a2f5db92723a2b2188a51e9549dacceb2f1ddeda00eebc49cad1ad1fd05dca7f09c7aacfd3e9c0cf04ebc52f018c85ab5e65c2405dce18b029ce43483a5cb034e21866451ca9a7ef72d88459b9a2109be19a3fe3e4d72d060b66df962f706fe083c2e5f4c770e1c3d9435c29913a062be4331e2b49422a9ee2ebe3938edda88d6e8cf8f2b05a9f72b7411ce882b6efe1ec068cc6fd0a37f5d5b69b90653350aae59486fedfb93a19eeabd5d57c356225b294b639d748c92db9c3bd81de64ba3fd0da3567e1ce257770133fb4a1af983f693ee47537a6a65d8bc188cd08b49ef4e7a12460aabc1198ce5bbc92b43b02ef4cf2e3a5f62bb4448982e3ca62eb3816898a670fb9c1f7cc72c0474718bee2fb8b33c3be64f8dd681a15ceae18a2a320d6fbd201228dfd6b1f1e34eb1962ce414f4fdb087cb0e93ee9ec8ce5c1799c0e0ceb71566203970a95d2ce817132dc6f5c9d27a3414aa55a9f59b4e743b07e622f10a71e96226afc2056837022a0663858bad576d2cf30bb827e7caa778722101530ab0ea6b1c0b424f3990ea61d8d3afffd1b1816703ff81f91b2b73b298a475a41117b1df626aa549b36b5add90da311ea8b8fa31e437aca2fff12b4ee1feda01ac308a05c984c207aea4c6f5a23b695571f655272b05a3d5ec8d218f9b77e8f8b8f95096b2eb66847ec431dbe1fe1d4d94452b961a67e1efecf36cb7b3af0b075009a210123efe9cded3eaf6da4186a160f29c7355e70e6596e00d578e44d665286de0ec7e55126b248748f78e7e9e66cd9d7773081271005e43cfc565c0f3bd7f11812116c24c5f1198d70cece64f40eaa28f7a7ec9f4f411aedbf861d633afc295b0f4db03f89a204880e8cb4385ccec55f9be950ac76b2293f1333ab0c87f8f9e2aacabcfa53f7aeadd7a186791b8e2b99be2e5232b86b6450e6286f24bbf434ecb82a0692b7d9309d9bc3d9cde797e1e2c354e516c6008e2	2026-09-22 10:19:18.477597+00	html	html
234186b1-d59f-4360-934c-68cefe1a07f4	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-22 13:00:00+00	2026-08-22 14:10:00+00	Cancelled	\N	df48c3e0-cea9-480d-9e91-1f91629c6913	\N	8000	2026-08-13 09:42:54.827179+00	2026-08-14 08:18:11.040655+00	\N	f	r0j33l72rv627do9j38f5shl0k	acb2d172-d161-48e7-b3d5-5622199e2839	in_1U3vAvGZ7O0g85MyaelUWgek	\N	\N	55c2d705-10eb-47df-bf0a-bfae2d8a3609	2026-08-13 09:43:52.926373+00	f	f	\N	UJ5LF8YI-0007	\N	f	\N	2026-08-20 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
b9bf6d97-e416-4885-8638-e4cbb8d85ae7	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-16 19:00:00+00	2026-09-16 19:50:00+00	Confirmed	pi_3UDKxdGUETlNTofG3tnCc3RQ	d3956098-a535-427c-94d3-189176c551c0	\N	3500	2026-09-08 09:05:05.798333+00	2026-09-08 09:05:06.115838+00	\N	t	qcpjif4sbberhj5jge1eb3g3nk	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
60734e80-8f29-4e9b-9323-086b546bd055	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-05 10:00:00+00	2026-09-05 11:00:00+00	Cancelled	pi_3UBzGvGunz6NhwSQ1SZZQH9n	b05de965-26da-40f5-a252-561ad48c12a1	\N	31	2026-09-04 15:43:26.283016+00	2026-09-04 15:46:54.942166+00	2026-09-04 15:46:12.726181+00	t	20anqam73jd3aphramses7mi6k	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	t	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
dc394852-be73-4eed-a136-fced539491aa	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-10-02 19:00:00+00	2026-10-02 19:50:00+00	Confirmed	pi_3UDl1UGUETlNTofG33JxZcPn	c358918e-b626-46ac-926a-3e401d45b212	\N	2500	2026-09-09 12:54:48.878233+00	2026-09-15 19:21:50.013744+00	\N	t	i0c2orp75renakvrudn4m7hp6k	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	d06a0ed3-f629-49c5-ba6a-14110212efff	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
74f85fbd-2035-4722-a0db-525be6853e21	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-11 14:30:00+00	2026-09-11 15:30:00+00	Confirmed	\N	df8e6927-7457-4cb6-88fd-ed4fa79af687	\N	0	2026-08-21 14:27:42.690005+00	\N	2026-09-10 14:33:52.989993+00	t	b6ja89n8cm9h0hs7ruuga19660	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	\N	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\\x014b6ca4a9410191e0b90cb717c601f4fec38e903be670d93d592ed46b72e20800f23a5d100e79fbbc4b218c17c8d160ea898cc25bac0492cced1e7dfcdb7d9bd284f49a5d6f8f3818ecc49d06eac97f8a10146d016ed9baf502c35f9a5322384c0346ffb598cbba3577e8de0b9cfe87f517cc950f68cd415256780ebf8fc17cffbffaa0f748efbffd00c8c199dec6edc11300160ebad70af4f88f89f0881947d125452d034fe4b262db8ab41ed9ef46e117b840651769a2ae6e823af4ae298a90922cbdc8923e0d5a022e1ac85f481b598af59cddff46988e6992c9f2a3123ef2ab1b0e0d476a872f2a83e3e5cc95fb65b08fce0daef2ceb60e647c22ff1f91173cb41d5ca6	2026-09-17 11:07:15.483203+00	\N	\N	text	text
ee72642d-a5ea-4a84-81b9-3da37088140e	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-17 17:00:00+00	2026-06-17 18:00:00+00	Confirmed	pi_3TixvEGunz6NhwSQ0eRIUR51	005f500d-0f15-49ed-87bf-8045bec85a40	\N	5000	2026-06-16 14:25:03.952206+00	2026-06-16 14:25:03.997704+00	2026-06-17 05:03:00.563595+00	t	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	0f9a6849-fbe2-4378-b63d-926f489d4377	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
154a6d96-2476-428c-acae-992dcda0c402	bd48e910-a161-46b2-9204-8346500fd85e	2026-06-23 11:30:00+00	2026-06-23 12:30:00+00	Pending	\N	ca47c2d3-9745-4338-94ca-08a5869f81bf	\N	6000	2026-06-20 10:54:46.966725+00	2026-06-20 10:55:02.558461+00	\N	f	\N	6ae879dd-17a5-4fe3-885b-ebadac35060c	\N	\N	\N	7318e5fd-f32c-47f0-bbbe-cdaeef268ff0	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
273bd8e2-b0ff-4181-a10a-965ca7e1f52b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-08 20:00:00+00	2026-09-08 20:50:00+00	Confirmed	pi_3U9SrnGUETlNTofG3P9pfGY2	8401c626-98b3-4fba-97ea-2620ad8257c6	\N	2500	2026-08-28 16:43:02.480484+00	2026-09-07 08:39:14.248623+00	\N	t	4ed7c492sfcbibih7qnd7600gc	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
7e04db97-3096-4b78-9fb4-e0e35601bb2f	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-24 21:00:00+00	2026-07-24 21:50:00+00	Confirmed	pi_3TrmUVGUETlNTofG2gqocsNt	ac6c10c5-e82f-4507-8dd3-5089c769e662	\N	4000	2026-07-10 22:01:54.552233+00	2026-07-10 22:01:54.883055+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
069bddc3-0cc9-445b-9f4d-466bc2cfe8d1	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-25 10:00:00+00	2026-07-25 11:00:00+00	Confirmed	pi_3TtNIMGZ7O0g85My1N8XMM44	842981b6-9bdf-4410-804b-1e84c3fa0341	\N	5000	2026-07-15 07:31:57.73503+00	2026-07-15 07:31:58.057625+00	\N	t	\N	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	0aa204b6-004d-4161-a1fe-0275da723904	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
a1f06db7-14b9-4d5c-85b3-388219303870	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-12 11:00:00+00	2026-09-12 12:00:00+00	Confirmed	\N	752b0bc3-6c12-41fe-90ce-37ea2abdf3e0	\N	5000	2026-09-08 16:18:32.516209+00	2026-09-08 16:24:59.466292+00	2026-09-11 11:01:37.041612+00	t	pc2kooa1djmv0tef9f2rigbq4c	f251d5a4-4886-4425-a63f-3775952cf80a	in_1UDRjiGZ7O0g85My7hcjnekF	\N	\N	06df22a6-8663-4f29-959c-e022ff69233e	2026-09-08 16:19:09.431923+00	f	f	\N	UJ5LF8YI-0013	2026-09-08 16:24:59.466241+00	f	\N	2026-09-10 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
8e443605-74a3-418f-ade2-0db7fd290ab2	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-05 17:15:00+00	2026-08-05 18:15:00+00	Cancelled	\N	5dbb0d7a-c964-4fa2-ba6c-fc38c5ed2852	\N	5000	2026-07-23 07:48:12.930998+00	2026-07-23 07:48:28.332429+00	\N	f	ipjmdhc0rjfauqhooj0r4593vo	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
d443413f-9ca3-4d31-9177-74b41f8f444d	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-02 15:00:00+00	2026-09-02 16:00:00+00	Confirmed	\N	217be3c5-654c-4fc9-857d-40ae63afdf24	\N	4000	2026-09-01 13:30:43.024295+00	2026-09-01 20:05:56.119992+00	2026-09-02 03:01:09.209098+00	t	ogce31t680f8id097sj5lkm778	a6455293-058b-4aca-b001-0a8868aa69b3	in_1UArn5Gunz6NhwSQxju6r5UK	\N	\N	c9751178-17c2-47d8-8c75-f84e5e0ac89b	2026-09-01 13:31:58.994512+00	f	f	\N	KUGSYF8I-0009	2026-09-01 20:05:56.119953+00	t	2026-09-01 13:34:35.829922+00	2026-08-31 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
c3ea408c-688a-4a30-859e-f7f411c17ab9	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-12 21:00:00+00	2026-08-12 22:30:00+00	Confirmed	pi_3TzOehGUETlNTofG3oGUyjQi	db52e549-f344-445e-8d5d-d10d8eba981d	\N	6500	2026-07-31 22:11:54.664192+00	2026-07-31 22:11:55.042326+00	\N	t	ummrftm35c4nkacajc027lln8s	dfba3c75-ac1c-49da-b22f-ef5f6244935a	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
a526f6be-4b70-4bf2-b036-62847e0f2013	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-07 20:00:00+00	2026-09-07 20:50:00+00	Confirmed	pi_3U6EsaGUETlNTofG11OH151y	35f418b3-e997-43ec-9ebc-07ca5d635929	\N	3500	2026-08-19 19:10:32.122795+00	2026-08-19 19:10:32.429522+00	\N	t	vjm088e80com2b5qnj5k04ksa4	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	7bcc6880-0a24-4836-9190-077734a05bba	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
82f35dde-8756-4cc1-9b5f-81f71357f19e	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-14 15:00:00+00	2026-08-14 16:00:00+00	DNA	pi_3U3xTUGunz6NhwSQ15Y8BYuh	a00815b6-75d9-4557-b3dc-349e4e32525f	\N	5000	2026-08-13 12:11:12.092289+00	2026-08-29 11:13:01.56177+00	2026-08-14 03:01:02.798551+00	t	mbv0n07qoa8i747jjus80k33ps	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	0f9a6849-fbe2-4378-b63d-926f489d4377	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
fd16c5e0-0e91-4a2f-9af3-39bed9a04262	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-28 21:00:00+00	2026-09-28 21:50:00+00	Confirmed	pi_3UG4VnGUETlNTofG0LcugixS	4ef4d5a6-6ec7-452b-91b5-6a481acbad08	\N	2500	2026-09-15 22:07:37.941733+00	2026-09-15 22:07:38.261597+00	\N	t	ogpccsmus5m778hrv8pt838tao	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	f516b85e-c084-4caf-be52-c413017520ee	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
0df7638e-074f-4e18-9896-5876410bbfb6	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-22 10:00:00+00	2026-08-22 11:00:00+00	Confirmed	pi_3U2CIsGZ7O0g85My1cPRkN0g	4cb136ad-3bac-4c34-bb8f-df44823649e4	\N	6000	2026-08-08 15:36:58.514081+00	2026-08-08 15:36:58.828257+00	2026-08-21 10:03:13.245174+00	t	749ordpodnc78q02lju0b477rk	3dea6e5c-75b7-494e-92c4-1eab47cc8272	\N	\N	\N	99a4df01-2fa1-4714-9cdc-d7b054aef464	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
b1097f48-d843-4943-b6c0-2ae7d7661f0f	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-22 11:00:00+00	2026-08-22 12:00:00+00	Confirmed	\N	67c19641-df6e-404c-8aa4-394037c41a76	\N	5000	2026-07-29 17:40:50.103875+00	2026-07-31 23:21:40.882611+00	2026-08-21 11:03:37.110654+00	t	3jlkd6svofhoshbuhfnocq6unc	f251d5a4-4886-4425-a63f-3775952cf80a	in_1TybTKGZ7O0g85Myw1Mukj6m	\N	\N	b38cf33e-25ec-43da-aa75-ab9480df74ad	2026-07-29 17:40:53.744398+00	f	f	\N	UJ5LF8YI-0006	2026-07-31 23:21:40.882571+00	f	\N	2026-08-20 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
ccf45c5d-e68b-4bc9-b744-eea543457c2a	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-09-10 19:00:00+00	2026-09-10 20:00:00+00	Confirmed	pi_3UCCSvGZ7O0g85My3wdhV19W	6470f6aa-0162-49ec-81e8-b3e5243b3ed9	\N	5000	2026-09-05 05:48:41.220663+00	2026-09-05 05:48:41.543813+00	2026-09-09 19:03:32.568129+00	t	qmbp1u5agv3evlrpem114m8frc	f2d4f68e-8457-4dc7-a7f3-09267e51e60a	\N	\N	\N	8778e261-6cf1-4428-8f91-1594b89a93c8	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
a4beac7c-ee94-45e5-a976-2f9ca6f3957e	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-27 19:00:00+00	2026-08-27 20:00:00+00	Confirmed	pi_3U78bVGZ7O0g85My18643V6N	b7bf3867-f20e-4295-89f2-f4b099384bc0	\N	5000	2026-08-22 06:40:37.121539+00	2026-08-22 06:40:37.446215+00	2026-08-26 19:04:41.501211+00	t	82ulde7mhjt5lhlorpqdh5hn4k	f2d4f68e-8457-4dc7-a7f3-09267e51e60a	\N	\N	\N	8778e261-6cf1-4428-8f91-1594b89a93c8	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
093273a8-c1c4-46fa-9e95-f83d46376640	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-03 21:00:00+00	2026-07-03 22:00:00+00	Cancelled	\N	e16902b0-68cf-4be1-87df-6b8de6da5c0c	\N	2000	2026-06-24 18:53:29.192442+00	2026-06-26 07:11:12.929947+00	\N	f	1vlje7u2qgf0aqf52k06v5js0c	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
d243af55-ae01-4bad-b12c-9c2027e26ecb	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-03 21:00:00+00	2026-07-03 21:50:00+00	Confirmed	\N	9f75529a-501e-4869-886a-e73b4913dbea	\N	2500	2026-06-26 07:19:03.595396+00	\N	\N	f	mh1ma6sqqeh4q7ut4e7ifkpdug	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	5133a2c0-2307-439e-b6be-1ae4401b3891	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
1b039a83-cb7e-46fa-b53e-855b49acb802	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-25 12:00:00+00	2026-07-25 13:00:00+00	Confirmed	\N	bd3e8413-f376-4119-855f-26a856b74c08	\N	5000	2026-07-11 12:03:51.643183+00	2026-07-11 12:05:34.340204+00	\N	t	64dkd1bks2gi21tksshq51vqr4	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
41f6874e-4c95-435b-ab6c-32c8c054c49e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-14 16:00:00+00	2026-07-14 16:50:00+00	DNA	pi_3TqfUZGUETlNTofG0S34jIFY	449d24e7-0602-4f6a-ac03-6613faacf1ec	\N	3500	2026-07-07 20:21:22.734842+00	2026-07-16 14:52:44.434038+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
ddc64961-dc69-4c91-b9ab-3acbbb102e0f	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-10 18:45:00+00	2026-05-10 19:35:00+00	Cancelled	\N	ef66d20e-1561-448c-b03e-da66b39fe832	\N	5000	2026-05-10 15:40:47.080219+00	2026-05-10 15:41:29.830205+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	bedb6631-8b9a-42e3-853e-15e500cd7435	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
5fb390e9-54d2-417c-b5ae-354cbc43a385	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-11 09:15:00+00	2026-05-11 11:05:00+00	DNA	\N	07d3c189-36e7-43c9-ad0f-030e5c0592bb	\N	0	2026-05-10 15:47:34.286609+00	2026-05-11 09:49:40.414073+00	\N	f	\N	\N	\N	\N	\N	f5506a34-ab36-44b5-8d4b-3342f503185c	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a9d100e2-e79c-4cae-915e-5f39d07e1239	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-10 11:30:00+00	2026-05-10 12:20:00+00	Cancelled	\N	1a3f69c1-407c-4266-95df-fb2a786f9b42	non-payment	5000	2026-05-09 15:16:09.552735+00	2026-05-11 08:55:21.158424+00	2026-05-10 09:31:37.580583+00	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TVpX2Gabf5vsP4Jm5ilkljm	2026-05-11 08:55:22.309441+00	https://doxy.me/davidhouliston	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a008b475-48f2-488b-8d7f-32c621e4c516	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-13 08:00:00+00	2026-05-13 08:50:00+00	Cancelled	\N	ed27409c-c606-4b71-bdca-8638423e4cb6	\N	5000	2026-05-11 09:36:46.410463+00	2026-05-11 09:45:12.92101+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a048b10d-efe5-4b15-8a47-0e0bd1492f62	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-10 09:30:00+00	2026-05-10 10:20:00+00	DNA	\N	b358b393-3c25-4fca-841c-8e5a3881b4b0	\N	5000	2026-05-09 15:15:04.467444+00	2026-05-10 09:57:03.326186+00	2026-05-10 07:31:22.380036+00	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://meet.google.com/bpz-xeqh-zeg	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
81163151-401c-424d-b990-c507e411aade	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-09 17:15:00+00	2026-05-09 18:05:00+00	Confirmed	\N	33a5d38d-deef-4fa9-ab4e-d0f55b01eb7d	\N	5000	2026-05-09 15:14:05.615273+00	\N	2026-05-09 15:17:04.718631+00	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
249f5663-9c73-4ca9-87f1-6cb22b51942c	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-09 17:15:00+00	2026-05-09 18:05:00+00	Cancelled	\N	5ea9f373-2db8-47e1-9a82-718190934559	\N	4000	2026-05-09 14:00:11.034424+00	2026-05-09 15:13:47.818843+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e598bc30-11aa-4bf0-902f-4334383f4247	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-09 19:15:00+00	2026-05-09 20:05:00+00	Confirmed	\N	1c06112b-596f-4480-a2f6-25c58e9f85c7	\N	5000	2026-05-09 15:08:52.629312+00	2026-05-09 15:09:00.110464+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
d7aa2392-6cea-45d0-afca-bbcec136ea7b	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-09 14:00:00+00	2026-05-09 14:50:00+00	Cancelled	\N	62d9912a-173f-4465-8160-feb0030630fc	\N	5000	2026-05-09 12:34:14.352829+00	2026-05-09 12:34:46.540718+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
fbb8e4aa-82c2-473e-8083-44606bfde06f	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-09 18:30:00+00	2026-05-09 19:20:00+00	Cancelled	\N	db2d8d8e-f99e-4ea7-826f-307ec954d9ae	\N	4000	2026-05-09 14:07:26.940666+00	2026-05-09 15:08:27.920859+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
0f335cf5-2cd6-42b4-8729-7c6ba2c5b1ce	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-06 11:15:00+00	2026-05-06 12:05:00+00	Cancelled	\N	9371b01e-6636-4f68-b14d-91410bcbcd2e	non-payment	5000	2026-05-04 09:48:14.224058+00	2026-05-06 08:15:44.335071+00	\N	f	kng1goe8i56piocbkhcen02pic	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TTJ6pGabf5vsP4JqXd1dEus	2026-05-06 08:15:47.926655+00	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
304d229c-fc2b-4810-8aba-ee8cc4bc5dd7	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-06 10:15:00+00	2026-05-06 11:05:00+00	Confirmed	\N	f8f479e9-9760-41b3-b189-db2ebc763576	\N	5000	2026-05-04 08:09:29.706821+00	2026-05-04 08:12:19.725899+00	2026-05-06 08:15:44.646918+00	t	7dh2em279a857p0vbe9jkesbus	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TTHZdGabf5vsP4JLdBILLwz	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
2b2fe901-9ae4-4e93-ae01-aee072ff544a	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-07 12:45:00+00	2026-05-07 13:35:00+00	Confirmed	\N	846e2bb5-4796-47ee-b5e9-ef4bae2100f7	\N	5000	2026-05-07 07:35:04.882199+00	\N	2026-05-07 10:47:13.89505+00	f	1rbambgm1l248qfp2ah4l65id4	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e3d0d257-9a08-43fd-87a5-58ee3e336df7	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-05 17:15:00+00	2026-05-05 18:05:00+00	Cancelled	\N	1af543b2-13d2-4495-9569-af3c6a4b9cfb	non-payment	5000	2026-05-04 13:59:28.545667+00	2026-05-04 16:15:40.305613+00	\N	f	nclllisqohbp5f36ptvrr6hb0g	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TTN1yGabf5vsP4J6hTMYrYN	2026-05-04 16:15:42.168125+00	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
f9fb03a9-704b-4ebd-8b09-e9b226cfa8aa	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-07 14:15:00+00	2026-05-07 15:05:00+00	Cancelled	\N	fecdd591-5b6a-4920-89ed-b13035dff6f9	non-payment	5000	2026-05-07 07:46:21.085134+00	2026-05-07 08:44:53.315765+00	\N	f	6burh08vpvclpbl2282dvg5748	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TUNMEGabf5vsP4JiVdzWp5Y	2026-05-07 08:44:54.341904+00	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e0dbe630-779f-4f24-8476-a3ae0f41fc1f	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-09 16:45:00+00	2026-05-09 17:35:00+00	Cancelled	\N	c2fcc1ff-07ac-46e7-8bb6-37fd1481e753	\N	5000	2026-05-09 13:59:01.333421+00	2026-05-09 13:59:58.65976+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3c16b90f-f58b-4c7f-b148-81c07d031922	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-06 12:15:00+00	2026-05-06 13:05:00+00	Confirmed	\N	ee7302e0-c85b-4397-ad0e-9624724b990d	\N	5000	2026-05-06 09:00:30.556637+00	\N	\N	f	vpmua3ljllcoqla8vqq6dloa9k	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
6b0ae875-fb0a-4ef9-bed7-a304aaef78f8	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-09 15:15:00+00	2026-05-09 16:05:00+00	Confirmed	\N	79b690c7-4da3-453a-935e-30fc83a9f6d0	\N	4000	2026-05-09 13:54:56.30637+00	2026-05-09 13:56:36.041119+00	2026-05-09 13:58:12.703465+00	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
dd90835d-9292-48e5-b62f-40a96edfdd69	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-06 13:30:00+00	2026-05-06 14:20:00+00	Cancelled	\N	50d532b6-e061-4872-8686-36a52128cd3d	non-payment	5000	2026-05-04 09:53:51.756031+00	2026-05-06 08:15:47.97319+00	\N	f	rcplftke9dstgad1jreicvrjj4	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TTJCGGabf5vsP4JvAyvXS1E	2026-05-06 08:15:48.753267+00	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
7469bb1a-d2be-491e-8915-d5c7c837cc1e	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-22 17:00:00+00	2026-07-22 18:00:00+00	Confirmed	pi_3TtTieGunz6NhwSQ0VwThGpY	d23abccb-522a-4c3d-b04f-2d4c6840c99d	\N	5000	2026-07-15 14:23:32.585136+00	2026-07-15 14:23:32.887566+00	2026-07-22 05:03:03.052431+00	t	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	0f9a6849-fbe2-4378-b63d-926f489d4377	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
3ec12220-2bae-4747-af83-85d31f0a64da	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-18 11:00:00+00	2026-07-18 12:00:00+00	Confirmed	\N	0551dd9a-92d1-4e47-bae0-3331b363104a	\N	5000	2026-07-06 17:41:54.4322+00	2026-07-08 09:20:15.151243+00	\N	t	\N	f251d5a4-4886-4425-a63f-3775952cf80a	in_1TqrGYGZ7O0g85My1BfuqaWB	\N	\N	b38cf33e-25ec-43da-aa75-ab9480df74ad	2026-07-08 08:55:42.397464+00	f	f	\N	UJ5LF8YI-0004	2026-07-08 09:20:15.151241+00	f	\N	2026-07-16 00:00:00+00	\N	\N	\N	\N	\N	\N	text	text
dba5a30f-7557-41bc-b194-6efa79e17a0e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-30 16:00:00+00	2026-07-30 16:50:00+00	DNA	\N	cc499e69-2533-42aa-8e68-eaa407a969f8	\N	3500	2026-07-23 13:23:33.324257+00	2026-07-31 10:55:36.665985+00	\N	t	n5r51ib2nhjskfa439s85l7910	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
f04d61b0-efae-4a0d-8fba-72bc7b3cb516	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-12 08:15:00+00	2026-05-12 10:05:00+00	Cancelled	\N	bc0e7b55-2456-48db-9227-4c6da7a68e3f	\N	4000	2026-05-11 09:34:48.147135+00	2026-05-12 09:02:59.427285+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	575ca44f-4e73-4884-8289-44ce8914364f	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
d7f7f43a-b3cc-40ea-b90e-c974c6043f58	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-13 10:30:00+00	2026-05-13 11:20:00+00	Cancelled	\N	6ffb6d12-195a-4c82-bcb8-058a9f5d871a	non-payment	5000	2026-05-11 10:15:46.900973+00	2026-05-12 09:31:48.893634+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TVr50Gabf5vsP4Jz8Yjf0JF	2026-05-12 09:31:51.123577+00	\N	6589fc5e-b998-43f6-b1c6-0cddbb7f73af	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e0d7926b-b6ea-4a0d-a4bb-f9f9203146be	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-14 12:00:00+00	2026-05-14 13:00:00+00	Confirmed	pi_3TWDUZGabf5vsP4J1KAHcWVa	d8189000-07f9-487a-a47c-9abd76f09eef	\N	4000	2026-05-12 10:24:47.029491+00	2026-05-12 10:25:31.535131+00	\N	t	\N	f37dc415-9f9a-4464-a06b-8453ff11bf40	\N	\N	\N	8deb6b3b-4506-4afe-92b8-f0fa2bff8231	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e5f5a473-3a63-4390-976a-b51227ce5824	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 11:30:00+00	2026-05-15 12:20:00+00	Cancelled	\N	05b8f2ca-5eb2-4ad2-b29c-55a3dbe81800	\N	5000	2026-05-13 11:19:15.417532+00	2026-05-13 13:13:28.606453+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://doxy.me/davidhouliston	864977ce-f74b-409d-8158-763ec40e6919	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3099de59-ca3d-4042-9f28-30b4169df24a	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 11:45:00+00	2026-05-15 12:35:00+00	Cancelled	\N	ac1d1e10-f053-4ef8-9f12-251eb5c32760	\N	5000	2026-05-13 13:41:29.417258+00	2026-05-13 14:22:12.900521+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	864977ce-f74b-409d-8158-763ec40e6919	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3c20253a-c923-4f8d-9bbb-b6b4d07f3dd0	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 11:30:00+00	2026-05-15 12:20:00+00	Cancelled	\N	0bc8a509-af72-4cc1-90b3-9b33b1ecc92c	\N	5000	2026-05-13 14:49:48.055261+00	2026-05-13 15:03:16.093821+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://doxy.me/davidhouliston	864977ce-f74b-409d-8158-763ec40e6919	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
f4e57dc4-3718-4aa6-a44f-df388337c259	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 11:45:00+00	2026-05-15 12:35:00+00	Cancelled	\N	226a52db-e975-41a3-bb61-162eb9d3c7f4	\N	5000	2026-05-13 15:19:42.747534+00	2026-05-13 15:27:00.728061+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://doxy.me/davidhouliston	864977ce-f74b-409d-8158-763ec40e6919	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
80d18f68-9dba-4aa2-85ec-e85c26033f1c	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 11:30:00+00	2026-05-15 12:20:00+00	Cancelled	\N	c3d355bb-58ee-41d0-803b-b3cab697fc0f	\N	5000	2026-05-13 15:41:06.573113+00	2026-05-13 15:41:15.77425+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://doxy.me/davidhouliston	864977ce-f74b-409d-8158-763ec40e6919	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
18dd0370-3a40-4fdf-ae14-a6cb3d4f6446	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 12:15:00+00	2026-05-15 13:05:00+00	Cancelled	\N	2bccef9f-cf63-44fb-b714-30c69cc068fb	\N	5000	2026-05-13 15:55:39.643074+00	2026-05-13 15:55:48.551856+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://doxy.me/davidhouliston	864977ce-f74b-409d-8158-763ec40e6919	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a9bcafb1-fd4c-47bb-a499-5c82ec1415da	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-15 11:00:00+00	2026-05-15 11:50:00+00	Cancelled	\N	7c7ee403-b909-4448-8f63-8e8e1e57513d	\N	5000	2026-05-13 16:06:40.903197+00	2026-05-13 16:06:49.996405+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://doxy.me/davidhouliston	864977ce-f74b-409d-8158-763ec40e6919	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
2d12a05f-2d19-4a3a-8531-79f239dbdffe	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-14 13:15:00+00	2026-05-14 14:05:00+00	Confirmed	\N	59e8af82-3c07-42fc-a714-93e00f2809a1	\N	5000	2026-05-12 09:04:02.400948+00	2026-05-12 09:04:23.894896+00	2026-05-14 11:15:53.135288+00	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	575ca44f-4e73-4884-8289-44ce8914364f	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
28af0e2a-54f8-405c-8022-2639a938bc58	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-20 09:00:00+00	2026-05-20 09:50:00+00	Pending	\N	5bad5c23-7c7d-4cb1-b9c7-10f188eed467	\N	1	2026-05-18 09:53:37.039125+00	\N	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
200d3e3c-1077-4138-a168-022a2e247eeb	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-21 09:00:00+00	2026-05-21 10:00:00+00	Pending	\N	75e4d6e7-846d-4b96-9363-0219456aec50	\N	1	2026-05-18 15:56:37.749943+00	\N	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a247844c-20dd-43a1-8f39-da13a28478d8	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-21 10:00:00+00	2026-05-21 11:00:00+00	Pending	\N	87b38685-86c4-4776-8294-05fbef2304e3	\N	1	2026-05-18 15:56:52.845962+00	\N	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
91290e6a-7015-457c-892d-7dc5ef01c282	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 09:00:00+00	2026-05-25 10:00:00+00	Pending	\N	96c2b1c8-c8ba-484e-b300-f4d092ff8086	\N	1	2026-05-18 16:06:04.252447+00	\N	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
d8663ad4-0952-4b94-b4dc-af139ba90bc7	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 15:00:00+00	2026-05-25 16:00:00+00	Pending	pi_3TYXJIGhYYveDEf608nNzHnv	ff90f078-f23d-45ec-9c93-9fed1ca92322	\N	35	2026-05-18 19:58:43.293669+00	2026-05-18 19:58:44.499569+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
533fe709-57af-4604-b60a-2007f9866748	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 16:00:00+00	2026-05-25 17:00:00+00	Pending	pi_3TYXJyGhYYveDEf60ImzTe6W	c72eab65-c2c7-4386-812f-7fe6169bfcb9	\N	35	2026-05-18 19:59:26.18057+00	2026-05-18 19:59:26.770154+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
5eefe036-4ee3-4714-8d44-dca49dd050f0	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 14:00:00+00	2026-05-25 15:00:00+00	Pending	pi_3TYiskGxIyacOeL8127b431e	03c0c9fd-24da-497b-8b74-f8a16c840fe4	\N	35	2026-05-19 08:20:04.404411+00	2026-05-19 08:20:07.094514+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3efb6ca8-a069-4313-a375-7d69db48dea2	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 17:00:00+00	2026-05-25 18:00:00+00	Pending	pi_3TYitPGxIyacOeL80gpBGmMs	c9073521-68af-4676-b9e7-3b2b1818469f	\N	35	2026-05-19 08:20:46.658101+00	2026-05-19 08:20:47.460842+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
af31ff77-398d-45aa-9fba-4c28ea4cac75	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 18:00:00+00	2026-05-25 19:00:00+00	Pending	pi_3TYjHxGxIyacOeL80tbeAulD	7e08b91b-18d9-497e-9ac7-787c49a9bf3a	\N	35	2026-05-19 08:46:08.416379+00	2026-05-19 08:46:09.430879+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a0f04f75-2d96-4ffb-9f57-27c28a937ca4	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-22 09:00:00+00	2026-05-22 10:00:00+00	Pending	\N	6982f7be-7d3f-478b-8f6e-537b6bc25aba	\N	35	2026-05-19 11:35:33.951927+00	2026-05-19 11:35:38.452718+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
b187789b-247b-4617-a7c4-1084cd2366a7	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 10:00:00+00	2026-05-25 11:00:00+00	Cancelled	pi_3TYTydGTnPNz4Eca2c5jpLLK	4235ff78-77ca-487e-8d1c-81791a5a30eb	\N	35	2026-05-18 16:25:10.552951+00	2026-05-22 19:32:43.639643+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
aa360c62-7fdd-4c6c-a1b0-81ae8b1a2c62	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 12:00:00+00	2026-05-25 13:00:00+00	Confirmed	pi_3TYTzkGTnPNz4Eca0TXJ7Ra2	91f8810b-1d02-4a00-914b-cc8bfb2bef20	\N	35	2026-05-18 16:26:19.971818+00	2026-05-24 10:16:01.00285+00	2026-05-25 10:04:51.810826+00	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a5551422-fdb4-4771-be7d-621f359a5ca7	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 11:00:00+00	2026-05-25 12:00:00+00	Cancelled	\N	0a2d292c-8e11-4863-ab51-36aa2a61e560	\N	35	2026-05-18 16:48:26.565624+00	2026-05-22 19:34:23.335815+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
1eb9e74c-60aa-478f-9986-eb6223b9b41f	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 19:00:00+00	2026-05-25 20:00:00+00	Cancelled	pi_3TYkNYGX0TyWmhJa1keIhob5	ee0721db-c333-4993-a54c-715047a6532d	non-payment	35	2026-05-19 09:55:59.691624+00	2026-05-25 19:54:07.96801+00	\N	t	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	in_1TYm3OGgOqknbIQ3taE82Cwn	2026-05-24 18:03:07.131928+00	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	2026-05-19 13:28:42+00	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
862d9db0-674d-44d7-bc75-90514243c82d	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-25 13:00:00+00	2026-05-25 14:00:00+00	Cancelled	pi_3TYicHGxIyacOeL80sOP3G41	af74ed4c-8746-47e4-b4a0-62032415753a	\N	35	2026-05-19 08:03:03.780474+00	2026-05-24 20:23:59.550813+00	\N	t	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	t	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
d61c70a1-2541-46e6-b4b0-1cb6fbcc2e22	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-22 10:00:00+00	2026-05-22 11:00:00+00	Cancelled	pi_3TYkPsGX0TyWmhJa2t6vdp2d	aea4f1de-a275-4d53-8b60-9f0cbac2d9e6	\N	35	2026-05-19 09:58:23.609184+00	2026-05-24 20:21:51.906468+00	2026-05-22 08:51:45.091164+00	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	t	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
fbbfb9f0-09de-4847-abca-5c9b748006b7	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-20 13:00:00+00	2026-05-20 14:00:00+00	Pending	\N	156fdcbc-e610-4ddd-9590-617855269b68	\N	36	2026-05-19 11:47:24.861042+00	2026-05-19 11:47:27.561386+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
8c2b56e4-8cd9-47a5-9f3d-0631b7f8a912	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-21 11:00:00+00	2026-05-21 12:00:00+00	Pending	\N	8e31b1e6-d0a1-4fa2-9abb-8498d9d0ac71	\N	36	2026-05-19 14:07:27.536843+00	2026-05-19 14:07:30.681818+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
75f251b7-eeb9-403c-ac43-a204c6b17834	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-23 12:45:00+00	2026-05-23 13:45:00+00	Pending	\N	a59ab30e-2367-40f2-a85f-8bc3b8d4fb79	\N	35	2026-05-22 16:18:38.915248+00	\N	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	48aaf5c7-cb34-4dfd-bea9-b1d4468b4002	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
8ced4f91-551a-4938-9e72-7e6be84a2794	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-28 13:00:00+00	2026-05-28 14:00:00+00	Cancelled	\N	1c67e345-7aff-414d-9407-7783e8b54629	\N	2500	2026-05-24 10:18:25.595509+00	2026-05-24 10:18:47.196628+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
9da30aed-0e12-4755-9fde-c6f5dd889744	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-26 09:30:00+00	2026-05-26 10:30:00+00	Pending	\N	f384bde3-0437-4ab7-81c3-f2cb5b0d00b9	\N	35	2026-05-22 16:58:19.850811+00	2026-05-22 19:31:12.769039+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	https://doxy.me/whatever	48b65fa5-71b5-4de4-ad09-19854cb18f16	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
9a2b8843-4ace-4c6b-9fc2-eb2f4e1e741b	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-20 16:00:00+00	2026-05-20 17:00:00+00	Confirmed	\N	22d1fac2-b3bd-49a1-898b-335d0488e342	\N	35	2026-05-19 14:01:48.159646+00	2026-05-19 15:03:45.185684+00	2026-05-20 14:01:37.307836+00	t	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
7b5c8cd9-f66a-46a3-9530-51c70c87fc3b	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-29 11:00:00+00	2026-05-29 12:00:00+00	Cancelled	pi_3TaitrGgOqknbIQ31kQ0O1mf	642a60fb-625f-40b6-a425-91d431f68d03	\N	33	2026-05-24 20:45:34.75596+00	2026-05-24 20:49:03.047887+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	t	33	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
fa5308f5-c605-4e50-82f0-2ea036b94526	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-21 13:00:00+00	2026-05-21 14:00:00+00	Confirmed	\N	b9b87530-e65d-42d5-bfb5-7d4bb90286af	\N	35	2026-05-19 14:45:50.080434+00	2026-05-19 14:46:29.711331+00	2026-05-21 11:02:49.906749+00	t	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
ced0c1b8-ded3-420b-abf4-1f96d27302aa	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-22 11:00:00+00	2026-05-22 12:00:00+00	Cancelled	\N	2aeb174b-dd94-41a5-b5df-c837806d7d3e	\N	35	2026-05-19 13:30:19.656698+00	2026-05-22 08:47:04.578508+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
b74daa0b-5723-4b6a-a20c-f279fd03031a	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-21 12:00:00+00	2026-05-21 13:00:00+00	DNA	\N	6670bcd9-a0c3-4b0c-8f44-299354f678c8	\N	37	2026-05-19 14:32:11.22333+00	2026-05-22 08:48:18.476059+00	2026-05-21 10:02:44.117982+00	t	\N	f37dc415-9f9a-4464-a06b-8453ff11bf40	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
1ae68888-bc7f-4850-a0c5-925a51a52639	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-23 11:00:00+00	2026-05-23 12:00:00+00	Confirmed	\N	ff9499a4-2de2-49e6-9a2d-87b2294f79b7	\N	36	2026-05-22 16:17:54.621934+00	\N	2026-05-23 09:03:47.390452+00	t	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	e17eb33b-dcbf-46c4-a713-4a9be7c2af35	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
75d183db-254d-4b56-8a43-8904ae1ea22c	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-26 12:00:00+00	2026-05-26 13:00:00+00	Pending	\N	fd263dae-c5fb-4138-83b1-48840bc7731f	\N	36	2026-05-23 12:43:22.034159+00	\N	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	jeramr	48aaf5c7-cb34-4dfd-bea9-b1d4468b4002	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
da5e62fc-95fe-4b19-818a-b497a2417653	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-24 08:15:00+00	2026-05-24 09:15:00+00	Confirmed	\N	3b83d2ee-597a-4916-85e0-c49c2cceaf59	\N	35	2026-05-22 09:22:42.866874+00	\N	2026-05-24 06:18:38.387623+00	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
f76fd5ac-f257-43fd-8686-6390ad9c4314	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-24 09:45:00+00	2026-05-24 10:45:00+00	Confirmed	\N	e097f923-0491-4032-90ff-8c704bfb591d	\N	35	2026-05-22 09:23:59.816367+00	2026-05-22 10:05:32.022988+00	2026-05-24 07:48:44.057139+00	f	\N	f37dc415-9f9a-4464-a06b-8453ff11bf40	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
4b3e5588-d6c3-4ac8-9667-0419e0b27fdc	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-29 09:00:00+00	2026-05-29 10:00:00+00	Pending	\N	b46f3c5d-2e5b-4a42-9747-e4564d331325	\N	2500	2026-05-24 10:22:12.49999+00	2026-05-24 10:22:18.201898+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
5ba8824b-173c-4c7a-8488-828e681ea5e4	bd48e910-a161-46b2-9204-8346500fd85e	2026-05-28 09:00:00+00	2026-05-28 10:00:00+00	Confirmed	\N	5a9ab31a-95fd-4e42-b725-97cdcf2e7b0a	\N	1000	2026-05-25 17:00:28.033361+00	\N	2026-05-28 03:00:57.731849+00	f	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	\N	a80393f0-28ae-4960-a134-5f823cc3e520	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
0513fe75-5382-4439-95a6-a4b4daa742ba	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-28 10:00:00+00	2026-05-28 11:00:00+00	Confirmed	\N	020ea287-4a01-4bcd-b586-1afaa59956a6	\N	35	2026-05-22 20:33:24.2956+00	2026-05-24 13:02:56.74121+00	\N	f	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	0e83389d-dabd-48fd-9a5b-fcc435dd26bd	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
2ecc3ad0-f9e0-4e0c-be0f-2fddc22dff5b	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-23 15:15:00+00	2026-05-23 16:15:00+00	Cancelled	\N	ec3473a3-1626-441d-bbf1-53ab1f98808f	\N	36	2026-05-22 16:22:34.130117+00	2026-05-24 18:09:03.900001+00	\N	t	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	https://doxy.me/davidhouliston	4d0def63-70e5-44a5-b6ed-2256db01f809	\N	t	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
6915b44e-0816-4310-88b4-c3d78644aa14	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-06-01 10:15:00+00	2026-06-01 11:15:00+00	Cancelled	\N	99490529-a43c-45ba-9d75-cb302df3d761	non-payment	33	2026-05-25 09:54:11.20833+00	2026-05-31 09:23:12.659865+00	\N	f	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	in_1TazNFGgOqknbIQ3epfHoKQK	2026-05-31 09:23:14.004152+00	https://doxy.me/client	6d3712ae-074d-44ad-9815-4c2c667f720d	2026-05-25 14:21:01.265885+00	f	f	\N	NLNFFSVW-0003	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
cde26898-910d-4d8d-b331-d0c453792285	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-28 12:45:00+00	2026-05-28 13:45:00+00	Cancelled	\N	970134ad-7499-4097-a21c-d61d1635bd83	\N	35	2026-05-25 12:21:53.383216+00	2026-05-25 12:22:47.689055+00	\N	f	8ejfgdhbgi28l1cbcnus7pq8pk	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	48b65fa5-71b5-4de4-ad09-19854cb18f16	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
5a75802a-5628-4a7c-a607-a964a40a9605	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-26 14:00:00+00	2026-05-26 15:00:00+00	Confirmed	\N	8eb78e93-9f9e-47a2-a836-665ddf7c930d	\N	36	2026-05-23 15:02:28.647163+00	2026-05-25 08:44:36.824771+00	\N	t	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	in_1TatyjGgOqknbIQ3mZmC4cLG	\N	https://doxy.me/booking	6d3712ae-074d-44ad-9815-4c2c667f720d	2026-05-25 08:35:20.54494+00	f	f	\N	NLNFFSVW-0002	2026-05-25 08:44:13+00	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
4989271e-aad9-4a1b-8989-b23455f35ba8	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-06-01 12:15:00+00	2026-06-01 13:15:00+00	Confirmed	\N	aa7a9015-a654-4819-a89d-c8c54bb13943	\N	33	2026-05-25 10:05:40.941016+00	\N	\N	t	\N	b0a6d7dc-5b87-47a9-a29b-51c365527892	\N	\N	https://doxy.me/client	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
7313671b-3707-46b9-94f3-580d2ce75d73	bd48e910-a161-46b2-9204-8346500fd85e	2026-05-28 10:15:00+00	2026-05-28 11:15:00+00	Pending	\N	159f7380-7831-48b7-81e7-997786af8119	\N	1000	2026-05-25 16:30:30.955325+00	\N	\N	f	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	\N	0725377a-2a75-4fc2-a340-068025ddbf1e	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
344126b6-a04c-4943-92f7-481f8c24f52a	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-29 10:00:00+00	2026-05-29 11:00:00+00	Pending	\N	92921978-57a4-4b08-b164-0c449601327a	\N	35	2026-05-24 10:34:50.213044+00	2026-05-26 07:31:31.776581+00	\N	t	\N	b95d0ce9-289d-45d0-9871-ab9580d36811	\N	\N	\N	bbff92b1-9293-4cef-bb47-35b0a36e5945	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
c849d76a-72d4-4793-9d69-26620840e1db	bd48e910-a161-46b2-9204-8346500fd85e	2026-06-01 10:00:00+00	2026-06-01 11:00:00+00	Cancelled	\N	9277df20-6ea4-49aa-834b-d3518ccec1ae	\N	1000	2026-05-25 17:03:30.01192+00	2026-05-25 17:04:33.34284+00	\N	f	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	\N	59ce34f8-14f2-4023-a207-006434716536	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
63d5105d-8bf2-4c8c-81eb-af67a195104e	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	2026-05-29 12:30:00+00	2026-05-29 13:40:00+00	Confirmed	\N	f556ce93-978a-464a-9ee9-f0f91073584b	\N	5000	2026-05-26 07:38:56.830871+00	\N	\N	f	hrc23n5thildbkeu1b4j557nvs	aeb060b8-173c-4bc9-9afd-9886e140904e	\N	\N	\N	6d3712ae-074d-44ad-9815-4c2c667f720d	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a6e4091b-af91-4964-b9f0-0d2f24aa2ad6	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-03 17:00:00+00	2026-06-03 18:00:00+00	Confirmed	pi_3TdsDEGunz6NhwSQ15IuypfZ	9a108c2b-696d-4214-a9ab-34abc0743f15	\N	5000	2026-06-02 13:18:37.145628+00	2026-06-02 13:18:37.541512+00	2026-06-03 05:03:36.106376+00	t	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	0f9a6849-fbe2-4378-b63d-926f489d4377	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
efaab694-65e1-427a-a207-86b3295ca869	bd48e910-a161-46b2-9204-8346500fd85e	2026-06-04 10:15:00+00	2026-06-04 11:15:00+00	Confirmed	\N	8c8030bd-a8f5-4303-97cb-2eefe02a1d2a	\N	1000	2026-06-04 08:22:40.176318+00	\N	2026-06-04 08:26:24.196734+00	f	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	\N	a80393f0-28ae-4960-a134-5f823cc3e520	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
1f9bcd1a-22ff-4b2c-8ce7-f1abc904de0d	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-30 16:00:00+00	2026-06-30 17:00:00+00	Confirmed	\N	93a59a00-6bba-4a2b-b206-639eaab0d054	\N	2000	2026-06-26 07:10:44.021165+00	\N	\N	f	55q9u9sp6lgsu0m237gel6j6fg	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
912f9f6e-4079-4dc0-b4ca-2ff3ff8dea0c	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-10 11:15:00+00	2026-06-10 12:15:00+00	Cancelled	\N	d0b02f38-0931-4450-ba2b-0e7df81beb95	\N	5000	2026-06-06 08:27:33.671987+00	2026-06-07 17:33:14.440551+00	\N	f	4g4881plkt38tprp9laivdn44o	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	067a1648-6f8e-4832-b666-069677893a96	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
d531706e-b8a7-4a3d-b758-a6533caf45e5	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-08 18:00:00+00	2026-06-08 19:00:00+00	Confirmed	pi_3Tfk0YGunz6NhwSQ0K8oRpdi	3701433c-9593-491e-a87d-27ed319ecd78	\N	5000	2026-06-07 16:57:14.45502+00	2026-06-07 16:57:15.250981+00	2026-06-08 06:04:23.117506+00	t	\N	fceec855-c5ea-426a-9b9f-bc46c470a6b5	\N	\N	\N	202f75a9-cd59-412f-83d5-2b8b8868da8a	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
04b19b93-172b-49ba-b74a-fe336ad2f02e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-10 16:00:00+00	2026-06-10 17:00:00+00	Confirmed	\N	56fd41b2-9203-4d42-a099-82ed6321f079	\N	2000	2026-06-09 18:25:44.294827+00	\N	\N	t	tia7tc1nvf7solmqjkbcjdqibk	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
6be9035e-b99a-4f94-a45c-9d1556a20046	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-29 16:15:00+00	2026-06-29 17:05:00+00	Cancelled	\N	b43b3f4e-f131-4abe-849f-7696fb4eb30b	\N	4000	2026-06-08 12:50:27.939028+00	2026-06-08 12:50:47.032027+00	\N	t	bfdpj1cimm63jr514khq8frsn8	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
ba3ad644-f803-439d-9bfd-5859fd6abe96	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-12 19:00:00+00	2026-06-12 20:00:00+00	Cancelled	\N	ac226e9c-e354-4cb3-9737-3488a5757d62	\N	2000	2026-06-09 18:27:59.365178+00	2026-06-09 18:34:23.829558+00	\N	t	b46kt9ekritvm2svce5b7rjvg0	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
99ec9eba-71cb-428e-a2dd-bb9de96e1aaa	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-10 21:00:00+00	2026-06-10 22:00:00+00	Confirmed	\N	bfd24ac0-a0e4-43e2-976f-fa838d0a7501	\N	2000	2026-06-09 18:26:03.096598+00	\N	\N	t	dr9cvhp14v986mjc8rckogbt8s	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e9b05891-59e6-47fd-a0e0-80bac3ef942d	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-15 16:00:00+00	2026-06-15 17:00:00+00	Confirmed	\N	72e2bd06-8c32-4374-ba99-14acf9d110a2	\N	2000	2026-06-09 18:30:13.398297+00	\N	\N	f	pbte2f4fqlllp8k3vlcst05dsg	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3d991ba3-3a85-4b8c-893c-9bf7d633eaf1	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-15 20:00:00+00	2026-06-15 21:00:00+00	Confirmed	\N	a6c3fe98-6404-4860-8cf6-84077042906a	\N	2000	2026-06-09 18:30:31.756119+00	\N	\N	f	9lh6cf6t6aac1meam3i5a9qji0	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
265823cf-34c7-4a6b-ac10-a4c3080c5232	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-17 19:00:00+00	2026-06-17 20:00:00+00	Confirmed	\N	027611f5-17f8-4b39-9b85-115a3ce36a33	\N	2000	2026-06-09 18:31:17.793169+00	\N	\N	f	m0bslum439o48bop2pltot18t8	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
94e6dbfc-74db-4aaf-b588-0fb85ac43d5a	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-22 16:00:00+00	2026-06-22 17:00:00+00	Confirmed	\N	7ea6a73e-6216-4638-ae2e-5a36c8f2de10	\N	2000	2026-06-09 18:32:06.339046+00	\N	\N	f	a7ciakli0lbdtjsnufvla16f1c	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
2e0e0992-1960-453b-a078-bc23b15b0cb2	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-24 19:00:00+00	2026-06-24 20:00:00+00	Confirmed	\N	4a8c72a9-079f-4142-99e1-92201d063246	\N	2000	2026-06-09 18:32:26.821475+00	\N	\N	f	a8vt6gjsio3jqt998pctg0bkoo	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
6a2d7016-c0be-44b8-bd2d-29a5afb9249e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-29 16:00:00+00	2026-06-29 17:00:00+00	Confirmed	\N	f818bba4-3b17-4a21-aae4-c26f85ce1a29	\N	2000	2026-06-08 12:51:00.006948+00	2026-06-09 18:32:48.520465+00	\N	f	dn21081rc5losnuv5n6ago3prg	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
c497d376-41c9-46a6-b606-5821d6e88df0	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-10 19:00:00+00	2026-06-10 20:00:00+00	Confirmed	\N	774c715b-b6fd-40d5-8adf-0c31dd3fd249	\N	2000	2026-06-09 18:34:15.113643+00	\N	\N	f	ahguc2j4c746u0g1pspp33kl2s	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
6e0154ca-eb35-4bf1-bbfe-144d160bc7d4	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-09 21:00:00+00	2026-06-09 21:50:00+00	Cancelled	\N	c8ad7bdb-739c-4a38-8c6f-b54ce3ac43ff	non-payment	2500	2026-06-09 18:28:51.323892+00	2026-06-09 21:09:32.873728+00	\N	f	0n8od8oalmcp4g83pkjotafmv4	0607aabc-240c-4c0a-8adf-ad69519eb59e	in_1TgUOOGUETlNTofG6zCRmuQh	2026-06-09 18:29:51.349667+00	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	2026-06-09 18:28:55.617865+00	f	f	\N	22DSHH4A-0001	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	text	text
57b44bbc-65aa-497d-873f-85449054487c	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-16 19:00:00+00	2026-06-16 20:00:00+00	Confirmed	\N	d6ff48e5-6999-4ffd-8f70-d4c625749ecc	\N	2000	2026-06-09 21:08:45.888486+00	2026-06-09 21:08:55.292688+00	\N	f	lvvs6e2mk9gjju0cf48je84j60	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
c63d9b1b-0d58-4683-9ad1-d9224f3db890	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-12 19:00:00+00	2026-06-12 19:50:00+00	Confirmed	pi_3TgXGlGUETlNTofG2mLicN6H	ca921307-a4f5-4117-9c71-15020c66dc07	\N	2500	2026-06-09 21:39:33.384391+00	2026-06-09 21:39:33.419389+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	7ad8918b-f750-44f1-9c17-f8b101f9d826	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a1eb5953-9b52-412c-a7ed-b89595cc2b6e	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-25 11:30:00+00	2026-06-25 12:30:00+00	Confirmed	\N	fe8e7c35-9bf0-4dfd-85cd-400690f4f766	\N	0	2026-06-06 08:26:16.578996+00	\N	2026-06-24 23:32:27.573592+00	f	is5t8s0u42tinmfjdmumvo6d0c	82870962-db92-4530-938e-2de4fe4fab77	\N	\N	\N	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
4fe4617d-18c6-4c7d-bb76-cf5be232f50f	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-16 21:00:00+00	2026-06-16 22:00:00+00	Confirmed	\N	cc32e10d-ca56-42e9-8f63-fd01c86abf56	\N	2000	2026-06-10 20:49:32.747548+00	\N	\N	f	qdcn68ni49rlsifjpml2pv9l6c	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
5474bdcd-4c5a-4973-a480-57a1c6b4b810	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-23 19:00:00+00	2026-06-23 20:00:00+00	Confirmed	\N	ed27be9d-9a1f-42f6-ab65-cd40a26d121d	\N	2000	2026-06-10 20:50:38.017165+00	\N	\N	f	r1uilsdfu49r9h4lq8jg8esfo8	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
27403870-d898-43d6-8173-b84dd96546fb	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-23 21:00:00+00	2026-06-23 22:00:00+00	Confirmed	\N	a6b8e4f4-664b-4f73-9b6b-8d57cc316a78	\N	2000	2026-06-10 20:50:51.208627+00	\N	\N	f	q3inpjrb7cshpomvb6ppfe48lg	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
9811767d-379d-4397-8d77-aecd746fdac2	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-17 11:00:00+00	2026-06-17 12:00:00+00	Confirmed	\N	2e83d2f1-c0d6-4f94-ab05-2563368a4f6f	\N	5000	2026-06-09 20:25:32.39554+00	2026-06-16 07:57:40.373916+00	2026-06-16 23:01:37.607056+00	t	7dun3si1ulktcjn8gia9s9s6bc	fceec855-c5ea-426a-9b9f-bc46c470a6b5	in_1TgWDKGunz6NhwSQG0ITDDVf	\N	\N	996ee20a-1f97-4cbf-81e4-af863dfdb336	2026-06-09 20:25:37.443048+00	f	f	\N	KUGSYF8I-0003	\N	f	2026-06-15 09:10:48.363277+00	\N	\N	\N	\N	\N	\N	\N	text	text
6f4fb509-0e20-4fad-8b47-20b3f7250be9	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-26 15:30:00+00	2026-06-26 16:30:00+00	Confirmed	\N	317ce27c-6c9d-4b0f-80d5-5c404570078c	\N	2000	2026-06-10 20:51:29.351071+00	\N	\N	f	m6lb0v0bu6rliajfc15cgumnoo	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
37539993-6889-4bab-a535-e321248ea811	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-30 19:00:00+00	2026-06-30 20:00:00+00	Confirmed	\N	a99b969f-f2f0-46db-824a-49419e6ea420	\N	2000	2026-06-10 20:52:10.618838+00	\N	\N	f	a21iuladasl6636qs4fo91lrqk	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
ed6479b9-6ee8-4d4e-b5c4-1ff9bfbcb0e5	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-12 10:15:00+00	2026-06-12 11:15:00+00	Cancelled	\N	1720b907-33d1-4757-9fac-3aade667181c	non-payment	31	2026-06-09 15:54:39.114867+00	2026-06-16 10:14:42.389928+00	\N	f	s7r6jd10ic8ke3cg01ep6842gg	70bc90d8-3f54-4915-a105-5fcad923bc5e	in_1TgRzAGunz6NhwSQW3wVg40t	2026-06-10 09:27:12.87525+00	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	2026-06-09 15:54:43.31799+00	f	f	\N	KUGSYF8I-0001	\N	t	\N	\N	\N	\N	\N	\N	\N	\N	text	text
9ac61a62-251e-4b73-8360-0a7c6ac0a2f9	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-01 21:00:00+00	2026-07-01 21:50:00+00	Confirmed	pi_3TjDj1GUETlNTofG3KdvooBr	60ac4577-aaea-4d5c-9141-e697fc7a1ba3	\N	3500	2026-06-17 07:17:30.461133+00	2026-06-17 07:17:30.843855+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	7bcc6880-0a24-4836-9190-077734a05bba	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
2d0fb21e-a5f2-46a5-85d4-e392ca0e3470	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-06-20 10:30:00+00	2026-06-20 11:30:00+00	Cancelled	\N	5ee151c4-a0c8-49f1-8f3f-e1e7a47243df	\N	31	2026-06-16 10:15:20.583056+00	2026-06-16 10:17:13.382265+00	\N	t	e60k8h9bciocbn0ckfvqhb37n8	70bc90d8-3f54-4915-a105-5fcad923bc5e	in_1Tiu1dGunz6NhwSQtqCHREOl	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	2026-06-16 10:15:24.254302+00	f	f	\N	KUGSYF8I-0004	2026-06-16 10:16:43.875218+00	f	\N	2026-06-18 00:00:00+00	\N	\N	\N	\N	\N	\N	text	text
f51918ef-fdc8-4804-a607-bfe1b2657bb9	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-23 16:00:00+00	2026-06-23 16:50:00+00	Confirmed	\N	f8919b85-528b-4976-9912-e431cb298419	\N	3500	2026-06-16 11:21:52.166294+00	\N	\N	t	bm446cut5q1snfhl51024hsvhk	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
d18a083d-9f98-495c-b1c5-8b321b8485dd	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-22 20:00:00+00	2026-06-22 20:50:00+00	Confirmed	pi_3TizJRGUETlNTofG11rPNvpR	1bcd17be-98a4-48ac-907a-1f929f5eba5e	\N	2500	2026-06-16 15:54:07.765116+00	2026-06-16 15:54:07.778433+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
7663b13b-934b-4e4d-b494-88f10fcfe738	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-22 21:00:00+00	2026-06-22 21:50:00+00	Confirmed	pi_3TjluwGUETlNTofG32hgBjrf	f133fe99-7ef7-4757-a0da-75ad6d662ee5	\N	3000	2026-06-18 19:48:05.526929+00	2026-06-18 19:48:05.548027+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
9779d377-9af1-4cdc-9831-ecb7d381da43	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-24 21:00:00+00	2026-06-24 21:50:00+00	Confirmed	pi_3Tk2MEGUETlNTofG0yThM03s	e8777f36-f987-4308-9a6f-a0467179fd24	\N	2500	2026-06-19 13:21:21.744153+00	2026-06-19 13:21:21.774454+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	f516b85e-c084-4caf-be52-c413017520ee	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a0102c08-81ad-4d34-8af2-2401e03efe56	bd48e910-a161-46b2-9204-8346500fd85e	2026-06-24 12:00:00+00	2026-06-24 13:00:00+00	Confirmed	\N	f021da6b-590c-482d-a282-eb7897afe10a	\N	5500	2026-06-20 10:56:57.891815+00	\N	\N	f	\N	11a355ad-276b-4777-b890-409d0be8b66e	\N	\N	\N	38f3ddb5-83ca-46d1-b545-ae066b442dd0	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
dc2a5b89-378b-4c93-a5d8-9e21da8e631f	bd48e910-a161-46b2-9204-8346500fd85e	2026-06-24 10:45:00+00	2026-06-24 11:45:00+00	Confirmed	\N	204a83b8-7dda-42eb-a7d1-4105c75a91e0	\N	6000	2026-06-20 10:55:49.44431+00	2026-06-20 11:03:41.467856+00	\N	t	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	\N	d1ee8786-5701-4da4-a7f9-5b5809c7b30e	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
6c42e829-1385-4e08-b228-4a2a1d1818f6	bd48e910-a161-46b2-9204-8346500fd85e	2026-06-22 10:00:00+00	2026-06-22 11:00:00+00	Confirmed	\N	8e7cd29a-cb70-4e3e-9853-5c7bb2d3dfa1	\N	1000	2026-06-20 10:52:28.653404+00	\N	2026-06-22 04:04:33.782551+00	t	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	\N	b86d2e4b-da0b-4286-a274-9cfdc5d7e60a	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
36ef4cb2-1a7d-490d-9f94-4cd9f7a607d6	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-26 19:00:00+00	2026-06-26 19:50:00+00	Confirmed	pi_3Tl7WKGUETlNTofG2BPSdELJ	0e35531d-a69b-4a9d-bf25-e18d613332c3	\N	3000	2026-06-22 13:04:15.060918+00	2026-06-22 13:04:16.345821+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	0d60d8c7-7987-47de-a39a-6319eb6e877a	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
cc345e07-3c3d-40c7-9d29-e5e60e0cc278	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-30 21:00:00+00	2026-06-30 22:00:00+00	Confirmed	\N	5a0ddbbd-af7c-4b32-89af-87d51cbb9eab	\N	2000	2026-06-23 18:52:59.243092+00	\N	\N	t	shkn2m462t45vhqek9cajecis0	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
b37118db-54e8-48d8-9b94-47b73ee758bf	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-06 16:00:00+00	2026-07-06 17:00:00+00	Confirmed	\N	5d45fa91-8456-4182-81aa-ebdda603d32f	\N	2000	2026-06-23 18:53:51.441176+00	\N	\N	f	6gn7h3dvf2ej2emjhh2vb8s300	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
87a7bcfc-5f39-43f3-bb08-b093f77d0fe5	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-29 20:00:00+00	2026-06-29 20:50:00+00	Confirmed	pi_3TlZrJGUETlNTofG2NkABgrb	c546b129-7270-4282-8cff-6ad60eb0a8da	\N	3000	2026-06-23 19:19:49.355644+00	2026-06-23 19:19:49.381288+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e1a90e7e-8750-4424-b5a3-b776f8cbd93e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-01 19:00:00+00	2026-07-01 19:50:00+00	Confirmed	pi_3TlvXDGUETlNTofG3guGQuUo	77b7bd7e-457a-4977-ab71-9d1734f5f35a	\N	2500	2026-06-24 18:28:30.177058+00	2026-06-24 18:28:30.488067+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
8666e12b-ef53-445d-92e7-053bfb442894	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-08 19:00:00+00	2026-07-08 20:00:00+00	Confirmed	\N	037b16b0-0941-4ce8-bf7c-fa637187c739	\N	2000	2026-06-24 18:52:32.291798+00	\N	\N	f	d820qo31f6955q63ofue0hpf4g	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3d1c59fb-4be0-469c-beeb-cf91e14c46ff	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-09-07 11:30:00+00	2026-09-07 12:30:00+00	Confirmed	\N	342ea455-1e13-42db-9e02-13880882d095	\N	4000	2026-09-05 16:23:45.139266+00	\N	2026-09-06 11:31:05.337429+00	t	jh8piuouu9u7seflcktidp12bk	a6455293-058b-4aca-b001-0a8868aa69b3	\N	\N	https://doxy.me/davidhouliston	c9751178-17c2-47d8-8c75-f84e5e0ac89b	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
94e9c576-9ae1-42d2-a83b-15cad6eb9165	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-03 15:30:00+00	2026-07-03 16:30:00+00	Confirmed	\N	f93946a4-68a6-4cbc-a1a8-f895a9ae8eec	\N	2000	2026-06-26 15:37:44.211878+00	2026-06-26 15:37:57.294959+00	\N	f	p5pqh3khtg8sks768nledlsino	1a215749-c7f4-46cc-bb50-7ecf86a9fe6a	\N	\N	\N	541effab-e1ee-480a-ac20-ab78235f4c10	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
29c664ed-fd4f-424f-9102-dbe165ffaf5e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-06-26 21:00:00+00	2026-06-26 21:50:00+00	Cancelled	pi_3TjRFXGUETlNTofG1b3hTehd	bb54bb5a-c523-4e34-9c29-cc3205c43a93	\N	4000	2026-06-17 21:43:59.47042+00	2026-06-27 10:37:45.721683+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	t	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a423c8f9-4c01-42f5-8d1f-4654cd8baf4b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-02 21:00:00+00	2026-07-02 21:50:00+00	Confirmed	\N	78020ca1-408d-4bac-981c-aae6cc20d00a	\N	4000	2026-06-27 10:47:09.181602+00	\N	\N	t	utck910nf8tekv05sg1lebfi8k	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
ec6e990f-ac6d-4777-89ee-d44c949ec426	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-02 16:00:00+00	2026-07-02 16:50:00+00	Confirmed	\N	f427e400-e2e8-4def-94de-595e0326c25c	\N	3500	2026-06-29 12:37:15.220733+00	\N	\N	t	ekort9bd8osrfpoev7415ur150	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a44b0ca9-80c0-4ba6-a4a2-1f26ccdca5d8	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-02 12:00:00+00	2026-07-02 13:00:00+00	Cancelled	pi_3Tnf2nGunz6NhwSQ1VS4kxNs	05624c69-5baa-4a45-a0c3-ddca612a6392	\N	31	2026-06-29 13:16:18.658897+00	2026-06-29 13:16:54.139709+00	\N	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
0069348d-16d1-464d-a256-74c747139c1b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-03 19:00:00+00	2026-07-03 19:50:00+00	Cancelled	pi_3TmgsRGUETlNTofG1URCrFYd	8ad28777-df6a-4cb0-b29e-2fb509bbe984	\N	4000	2026-06-29 16:13:16.529201+00	2026-06-29 20:03:11.871889+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
42de805e-7a8e-4f97-92c8-ec2e1ffa259b	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-06 20:00:00+00	2026-07-06 20:50:00+00	Confirmed	pi_3To7u2GUETlNTofG1Gh8jgkp	c0f45273-2968-48f4-a1af-1b965213d8f7	\N	3000	2026-06-30 20:05:09.704196+00	2026-06-30 20:05:11.176286+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
563fad88-20ed-41c6-9a3b-ee5e51d545b3	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-07 19:00:00+00	2026-07-07 19:50:00+00	Confirmed	pi_3Toi1GGUETlNTofG2IDuVGE2	74f1a8ac-4e84-4657-bbbe-cfdfd47b0a2c	\N	2500	2026-07-02 10:39:01.553018+00	2026-07-02 10:39:01.859681+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e6b9237e-e08e-474b-9bdf-85928adcff90	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-17 21:00:00+00	2026-07-17 21:50:00+00	Confirmed	\N	dd9236e6-597b-4cb0-9a18-85fdf2ea867b	\N	2500	2026-07-03 21:02:13.157828+00	\N	\N	t	6vlpman343hkjuuhi6bhmi2iag	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	5133a2c0-2307-439e-b6be-1ae4401b3891	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
165785a8-12bf-44be-b8f5-bf6c8d4243e6	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-13 20:00:00+00	2026-07-13 20:50:00+00	Confirmed	pi_3TqG0PGUETlNTofG1C47Ffpo	7f29c19a-8430-46d8-a178-70a35ec3452b	\N	3500	2026-07-06 17:08:32.540773+00	2026-07-06 17:08:32.846861+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	7bcc6880-0a24-4836-9190-077734a05bba	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
e8d899a6-1b8e-4459-a91c-31d998fb73ad	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-11 11:30:00+00	2026-07-11 12:30:00+00	Cancelled	\N	c3bd96b4-dfc8-4bb2-a6d1-78ce3021e581	\N	5000	2026-07-06 17:37:43.453699+00	2026-07-06 17:39:31.647993+00	\N	f	\N	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	0aa204b6-004d-4161-a1fe-0275da723904	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
3ab9de84-ae6b-4c88-8b20-69d9c29892c9	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-11 12:00:00+00	2026-07-11 13:00:00+00	Confirmed	\N	d9a6f136-c5e4-43e9-af80-f1140257051d	\N	5000	2026-07-06 17:40:22.88711+00	2026-07-06 17:42:32.571793+00	\N	f	\N	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
9d1a29ed-dcb6-4f1e-b2cd-019aca1de566	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-11 13:00:00+00	2026-07-11 14:00:00+00	Cancelled	\N	127e1881-98bc-40f1-b5ab-67729f831a8d	\N	5000	2026-07-07 08:14:37.564756+00	2026-07-07 10:38:08.386765+00	\N	f	mnb3146i2avfitlrobb9flu688	f2d4f68e-8457-4dc7-a7f3-09267e51e60a	in_1TqU9mGZ7O0g85My4vEFs0iH	\N	\N	55130fe8-186f-481e-8db4-1d6e49c9ae13	2026-07-07 08:15:09.78486+00	f	f	\N	UJ5LF8YI-0002	\N	f	\N	2026-07-09 00:00:00+00	\N	\N	\N	\N	\N	\N	text	text
644902eb-7436-4953-9ddb-e9f4ef642317	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-11 11:00:00+00	2026-07-11 12:00:00+00	Confirmed	\N	a1d1db9e-fa54-4d89-8ea1-0db9b0c0b888	\N	5000	2026-07-06 17:39:47.768209+00	2026-07-08 08:27:37.291119+00	\N	t	\N	f251d5a4-4886-4425-a63f-3775952cf80a	in_1TqWPOGZ7O0g85MymY5G0aqc	\N	\N	0aa204b6-004d-4161-a1fe-0275da723904	2026-07-07 10:39:25.359873+00	f	f	\N	UJ5LF8YI-0003	2026-07-08 08:27:37.291061+00	f	\N	2026-07-09 00:00:00+00	\N	\N	\N	\N	\N	\N	text	text
bfed2702-bbaf-4920-8dee-4d22ba16195a	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-07-11 10:00:00+00	2026-07-11 11:00:00+00	Confirmed	\N	ac1cdeb0-739b-4d3c-acea-f422b918ed7c	\N	5000	2026-07-06 17:37:25.062597+00	2026-07-08 09:44:13.3075+00	\N	t	\N	f251d5a4-4886-4425-a63f-3775952cf80a	in_1TqHNKGZ7O0g85MyZ6nBwKOD	\N	\N	99a4df01-2fa1-4714-9cdc-d7b054aef464	2026-07-06 18:36:17.23107+00	f	f	\N	UJ5LF8YI-0001	2026-07-08 09:44:13.307499+00	f	\N	2026-07-09 00:00:00+00	\N	\N	\N	\N	\N	\N	text	text
ec971718-23ea-482e-8347-1bc7eb15ddd7	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-09 14:00:00+00	2026-07-09 15:00:00+00	Cancelled	pi_3TquDZGunz6NhwSQ0ojV4v4S	506a3ee4-48e3-4e25-be6a-e305bcfe2d52	\N	31	2026-07-08 12:04:50.475058+00	2026-07-08 14:12:30.287591+00	\N	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	6fe67340-b48f-48e0-86f9-84d62f68bd08	\N	t	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
54cc45b4-76dc-40df-920a-2fa9ac8cc3fb	bd48e910-a161-46b2-9204-8346500fd85e	2026-07-09 10:45:00+00	2026-07-09 11:45:00+00	Confirmed	\N	f564236e-5932-425d-a7a1-4ad1fa7eb082	\N	250	2026-07-07 11:28:35.906319+00	\N	2026-07-09 04:49:08.833753+00	f	\N	aa3afc95-4772-4884-bfc6-c9fe9d898f3f	\N	\N	\N	1ba98f28-7476-4801-9786-f69733a4dc8f	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
fba90547-4e55-463d-b7e7-3c8ffea82332	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-07-02 11:00:00+00	2026-07-02 12:00:00+00	Confirmed	pi_3TneahGunz6NhwSQ1O7ItzVE	73f10e64-7494-4648-8e92-57391ff4369f	\N	31	2026-06-29 13:48:17.284505+00	2026-06-29 13:48:17.590713+00	2026-07-01 23:04:54.926884+00	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
a8e6c7ba-e2a5-4d7b-af2b-e3d7983dcee6	bd48e910-a161-46b2-9204-8346500fd85e	2026-07-13 10:15:00+00	2026-07-13 11:15:00+00	Confirmed	\N	35b259b1-0263-4b75-b60f-528a0af599eb	\N	6000	2026-07-07 10:54:15.331455+00	\N	2026-07-13 04:15:12.173821+00	f	\N	6ae879dd-17a5-4fe3-885b-ebadac35060c	\N	\N	\N	1ba98f28-7476-4801-9786-f69733a4dc8f	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
b599c9fe-68aa-4eea-b04e-09f23222f182	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-10 21:00:00+00	2026-07-10 22:30:00+00	Confirmed	pi_3TorfqGUETlNTofG1kMsSuul	4602de8d-8bb0-4a9b-a247-02919c6950a7	\N	6500	2026-07-02 20:57:34.43823+00	2026-07-15 09:15:18.858164+00	\N	t	\N	dfba3c75-ac1c-49da-b22f-ef5f6244935a	\N	\N	\N	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	\N	f	f	\N	\N	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	text	text
80c16857-1b9f-4c59-9396-f9b158a6adfa	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-09-16 16:00:00+00	2026-09-16 16:50:00+00	Confirmed	pi_3UEFatGUETlNTofG3K4fBZuQ	169c6624-42ad-4804-9971-b69f47c54b20	\N	2500	2026-09-10 21:33:23.220435+00	2026-09-10 21:33:23.657892+00	\N	t	b7spdvqcfs4fre87sr323d0cq4	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	74577f33-d5a1-46a8-a5d7-fdbac56718d7	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
f55f14b1-62d0-4732-8316-1254dbe32547	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-20 21:00:00+00	2026-07-20 21:50:00+00	Confirmed	pi_3TtY42GUETlNTofG15SAWH9h	bf4f603f-c522-4edc-bdb0-55013deef153	\N	3000	2026-07-15 19:01:54.89827+00	2026-07-15 19:01:55.220686+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
69cac9e5-ee8b-4dfc-b7c1-21e3e4a2fd86	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-07-27 20:00:00+00	2026-07-27 20:50:00+00	DNA	pi_3TwRNuGUETlNTofG3v472j35	f1ca6b87-04fd-4734-8ae1-1e24292d8ba1	\N	3000	2026-07-23 18:30:22.88726+00	2026-07-27 19:30:55.502163+00	\N	t	\N	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	758d9e7d-469b-4f37-a796-7561858f5c18	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
b6cb5ce5-9902-43ea-af14-5f46a50ffb3e	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-10-10 11:00:00+00	2026-10-10 12:00:00+00	Pending	\N	b65032f6-3712-424a-a02c-7cc3178790fc	\N	5000	2026-09-19 12:01:30.117648+00	\N	\N	f	vp3jlsihg3jb0nq5h7hcn2s2es	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	74149353-981c-4862-8b0c-0ae0ddf5b2d9	\N	f	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
876a8dd8-4e25-414c-b7cb-f9672c4096f8	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	2026-08-04 21:00:00+00	2026-08-04 21:50:00+00	Confirmed	pi_3U0JjjGUETlNTofG3qXlffrv	c137bda6-7cb4-42aa-a61e-92868c60f84c	\N	2500	2026-08-03 11:08:54.212257+00	2026-08-03 11:08:54.515628+00	\N	t	7mjm8bp7qrp71qc6cco8mudeoc	0607aabc-240c-4c0a-8adf-ad69519eb59e	\N	\N	\N	f516b85e-c084-4caf-be52-c413017520ee	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
8395b74b-aa5f-4d26-8beb-f869c65bcc9b	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	2026-08-08 12:00:00+00	2026-08-08 13:00:00+00	Cancelled	\N	1028df1e-bf7e-4c4f-b8c4-3c7731b5ce06	\N	5000	2026-07-11 12:06:24.862262+00	2026-08-06 21:23:29.798018+00	\N	f	sdh927tn8qm14lsu8n1r8s21hg	f251d5a4-4886-4425-a63f-3775952cf80a	\N	\N	\N	8053fd6c-fa8b-46c0-80ed-085283b90eec	\N	t	f	\N	\N	\N	f	\N	\N	\N	Therapist	\N	\N	\N	\N	text	text
40863962-755c-4d3d-bb62-331fbb9d5410	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-03 10:00:00+00	2026-08-03 11:00:00+00	Cancelled	pi_3TyoZKGunz6NhwSQ07SAMFcz	4908433d-2d10-4def-9ae4-f6ef59066d5e	\N	31	2026-07-30 07:41:20.48044+00	2026-07-30 07:50:54.792496+00	\N	t	\N	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	de2eece9-2c1e-4168-80eb-29e1fa596755	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
d30c3b7a-e149-4634-8855-7555bd8a3e65	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-17 09:00:00+00	2026-08-17 10:00:00+00	Cancelled	pi_3U2qnRGunz6NhwSQ0l1p1bk6	05cb6f5e-86fb-4302-9be3-2d00b30ab932	\N	31	2026-08-10 10:51:13.330767+00	2026-08-10 14:50:53.554992+00	\N	t	u4uj82gvp37vkt5kb2jg6oc9pg	70bc90d8-3f54-4915-a105-5fcad923bc5e	\N	\N	\N	2daf5d4d-4775-4f80-b0c2-bb725fa6d530	\N	f	f	\N	\N	\N	f	\N	\N	\N	Client	\N	\N	\N	\N	text	text
7f618e90-01b8-4de2-bbef-448bafaef54f	47884d7a-9e96-4245-bcec-f5ab308a54f4	2026-08-27 12:00:00+00	2026-08-27 13:00:00+00	Confirmed	\N	34d12620-946e-4ab6-b054-8948290ba673	\N	5000	2026-08-13 17:26:58.171663+00	2026-08-17 09:41:12.755333+00	2026-08-27 00:01:37.366711+00	t	rjeal12eq2ghlt3it5ac6vgi44	fceec855-c5ea-426a-9b9f-bc46c470a6b5	in_1U5LfFGunz6NhwSQWbWZz8dI	\N	\N	8b0a8b68-a2f2-4983-b72c-621f75da48a7	2026-08-17 08:13:04.247583+00	f	f	\N	KUGSYF8I-0007	2026-08-17 09:41:12.755332+00	f	\N	2026-08-25 00:00:00+00	\N	Therapist	\N	\N	\N	\N	text	text
\.


--
-- Data for Name: Breaks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Breaks" ("Id", "TherapistId", "Label", "StartTime", "EndTime", "CreatedAt", "UpdatedAt") FROM stdin;
e9137b09-2ccc-416b-b280-456179203737	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	\N	2026-08-28 19:00:00+00	2026-08-28 20:00:00+00	2026-08-14 08:05:44.691638+00	\N
5a0b6b64-10bd-461c-9635-aae147156470	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	\N	2026-08-28 21:00:00+00	2026-08-28 22:30:00+00	2026-08-14 08:05:55.197688+00	\N
ba733b3a-2ec0-4f4b-94b9-2b1c2c519e5d	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	\N	2026-08-28 15:00:00+00	2026-08-28 16:30:00+00	2026-08-14 08:06:48.916142+00	\N
0a0a1424-9eb4-4c76-8814-bcdfdde35602	47884d7a-9e96-4245-bcec-f5ab308a54f4	Going out to the movies	2026-08-20 13:00:00+00	2026-08-20 15:00:00+00	2026-08-19 07:46:24.936129+00	\N
d038214e-0c36-4882-9fa7-70238fff6f08	47884d7a-9e96-4245-bcec-f5ab308a54f4	Movie	2026-08-20 16:15:00+00	2026-08-20 19:00:00+00	2026-08-19 07:48:01.482773+00	\N
741786ec-528a-4f6d-a520-eb53ee2b5996	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	\N	2026-08-27 16:00:00+00	2026-08-27 17:00:00+00	2026-08-26 13:38:56.03131+00	\N
d0568edf-e11a-4534-b0c2-48ec95ac3890	47884d7a-9e96-4245-bcec-f5ab308a54f4	\N	2026-09-02 09:00:00+00	2026-09-02 10:00:00+00	2026-09-01 08:27:34.229297+00	\N
77c25ca1-826d-464b-8c4b-e00bdeeabc1d	47884d7a-9e96-4245-bcec-f5ab308a54f4	\N	2026-09-04 13:00:00+00	2026-09-04 14:00:00+00	2026-09-01 08:29:10.285289+00	\N
476e7d45-495c-45bf-804e-2bf9011a7c26	47884d7a-9e96-4245-bcec-f5ab308a54f4	\N	2026-09-04 15:00:00+00	2026-09-04 16:00:00+00	2026-09-01 08:29:30.541616+00	\N
544ec052-61b3-4767-be19-dda70c5cf546	47884d7a-9e96-4245-bcec-f5ab308a54f4	\N	2026-09-02 14:00:00+00	2026-09-02 15:00:00+00	2026-09-01 13:38:30.022587+00	\N
3de1b4bf-bb8f-4f10-8106-7d94b5453040	47884d7a-9e96-4245-bcec-f5ab308a54f4	Break	2026-09-07 09:00:00+00	2026-09-07 11:00:00+00	2026-09-06 15:52:42.918685+00	\N
941216bc-995a-4868-af95-f17da793152e	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	\N	2026-09-08 21:00:00+00	2026-09-08 22:00:00+00	2026-09-07 08:39:35.653765+00	\N
643a92ee-8fe6-448a-a45e-66d4a6230754	4e7214dc-b42b-4462-aa74-5026e3b4c8e7	\N	2026-09-17 16:00:00+00	2026-09-17 17:00:00+00	2026-09-11 19:00:16.58348+00	\N
2bba59e9-7f21-407c-9540-7509c5403175	47884d7a-9e96-4245-bcec-f5ab308a54f4	\N	2026-09-16 12:00:00+00	2026-09-16 19:00:00+00	2026-09-15 06:07:44.257812+00	\N
\.


--
-- Data for Name: CalendarPrefs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."CalendarPrefs" ("Id", "TherapistId", "Calendar") FROM stdin;
\.


--
-- Data for Name: ClientIdentityTypes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ClientIdentityTypes" ("Id", "Name") FROM stdin;
5c1f6d0a-3b7e-4e0c-9a2d-1f8b4e6c7d01	Enquirer
8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02	Client
\.


--
-- Data for Name: ClientIdentities; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ClientIdentities" ("Id", "ClientId", "ClientIdentityTypeId") FROM stdin;
f673aeba-63fd-4d9f-a788-6da584d9f69d	02ba73e0-f4bc-4812-a41f-07be773c8eae	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
6cc2bb97-cbfa-4e5f-a643-5df1f9be7d65	067a1648-6f8e-4832-b666-069677893a96	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
22be8426-3562-40e2-918a-e7db4f3252ae	06df22a6-8663-4f29-959c-e022ff69233e	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
3efde45b-0e52-4835-98d3-4a8fb046427a	0725377a-2a75-4fc2-a340-068025ddbf1e	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
27ac3107-0794-4bee-8c48-b8d66264b46d	09b065c5-a8f7-431a-be7a-f4f6d3a94916	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
092fa67f-3015-4ccd-82c2-1b3ea6ebfd1d	0a0c45bd-8af0-4c8b-8d1a-908554c0f00b	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
f3166d10-fe69-4676-af12-ce1154438ffc	0aa204b6-004d-4161-a1fe-0275da723904	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
aab0b8e0-594f-409b-a045-1305c7a11efb	0c3d11e6-fdde-48e4-9b88-755d674448c1	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
f2479e96-a6d5-48df-9e91-254239e0da22	0d60d8c7-7987-47de-a39a-6319eb6e877a	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
465529dd-4f4c-4099-9952-fea9192c684a	0e3710cd-d335-4841-a7f8-c998a743b9a4	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
47c161b3-1576-4c3c-a6bb-a69bcf7d7972	0e83389d-dabd-48fd-9a5b-fcc435dd26bd	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
3ce54c17-08ea-4062-aa70-41e09c7f95b0	0f9a6849-fbe2-4378-b63d-926f489d4377	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
20808b7f-2246-4ace-ada2-68351972ce6a	106de2f0-45f6-43fa-8f89-6a0118d15da4	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
ea01688c-136d-44a0-8fa0-25cd5dec7b7e	1ba98f28-7476-4801-9786-f69733a4dc8f	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
95b56053-345f-4ff6-80d5-0ca1030bc362	1bd257e2-a016-4dac-a0ab-027d8172fc26	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
ab99c2a7-3c94-4d46-b44b-7f8c91854bdb	1e1368e6-38d3-4b5f-821e-753912f772be	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
5d9ef046-5d30-4f95-9971-233537375ba1	202f75a9-cd59-412f-83d5-2b8b8868da8a	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
ad98e626-4c03-46d2-a22f-166e154db28f	29104fc4-9636-470a-adcf-431de2f88aa6	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
d9f0998c-e380-45da-bfff-2b5a0ba6a7c2	291d4a94-d2a2-4151-93c3-89b21ae8c30e	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
82400538-ec57-43ef-b864-66339b089f94	2d16f712-3c60-4ba9-8801-776dc423aa26	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
dae56b57-0f15-4cdf-a6e1-c18ded894904	2daf5d4d-4775-4f80-b0c2-bb725fa6d530	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
3aead0c5-e552-4f09-9fe5-90847b6a599d	2eae7ffe-555e-4c73-b66c-a7b44af25693	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
ecab8151-d447-4b79-b08c-e2d2afd5c95b	2eb0b0fa-3294-4d66-8841-f4d6c7016818	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
c26b48fb-aee6-486c-8b4e-e3a6fc0031ed	31704edb-c0a2-4a1f-8e7a-4f8967f4fdc9	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
f6a061c6-3106-4666-984b-9693b61af4c9	33990723-6e30-40a2-96f1-72dc705737ac	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
eee8f3cd-6620-4eff-a593-2ddeb9ad01dc	38f3ddb5-83ca-46d1-b545-ae066b442dd0	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
9cf73a40-1eab-4f7c-b609-63cd3cf95b06	4016c344-a3cf-4d82-a87e-2c94cd89abc2	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
e6c98222-adc6-42d2-aa94-647a2b61bbec	435de98e-26a0-4b08-8979-5c984f92849c	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
1740dc1e-0491-407c-bb08-147769a02f8a	4487faf2-6de9-47ff-83cb-2fd596695390	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
c7945fa7-ae5b-4cc2-ac65-3c87aa5fbccc	44c935ee-ac12-47f5-abd8-858ea37692d0	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
60328c1b-f048-431d-8691-83239209e733	48aaf5c7-cb34-4dfd-bea9-b1d4468b4002	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
63031b76-5288-4dd9-a3af-19be5b4503f3	48b65fa5-71b5-4de4-ad09-19854cb18f16	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
afd98099-60bd-443f-a540-87005e3c5247	4d0def63-70e5-44a5-b6ed-2256db01f809	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
0b3d7387-7e4d-4d39-8980-a62dad9212a4	4d5d4435-662e-4ea4-909a-8573d37e5a12	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
41336a2f-5c6a-482f-aa81-37f9fdeb3c25	508444c1-a065-4639-9e11-c798406eb3d1	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
28772aac-513a-4fc6-b12e-ee5bb3bf65d2	5133a2c0-2307-439e-b6be-1ae4401b3891	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
67e097f2-7c5a-4442-8ca8-fd2047708a1a	541effab-e1ee-480a-ac20-ab78235f4c10	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
0c08e730-a453-4168-857e-a99fe203c8b3	55130fe8-186f-481e-8db4-1d6e49c9ae13	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
7d3c663a-3fdc-42d7-a3d2-f6e222eccfbb	55c2d705-10eb-47df-bf0a-bfae2d8a3609	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
d1aa6808-e723-4884-a35d-546072570787	562c519f-8dca-46be-a9c6-cef031bd3c34	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
028cbd76-c9bb-4b2c-904a-91152c39ade1	575ca44f-4e73-4884-8289-44ce8914364f	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
57a3264f-972f-4df4-b7dc-633e9b5bed20	5954c672-1e1a-4820-b729-d88f2b8e3b55	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
4ea05dd9-7a2d-43d3-9df2-73e7d9b0a3e4	59ce34f8-14f2-4023-a207-006434716536	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
5a77865c-e10b-414f-bd82-ddc8937d3ec9	604ae139-05d5-4679-a06c-9ef366488dc2	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
cd20c23c-f723-4ba4-8b11-7daf5eea2bf1	624fec2c-7b62-49bb-af61-f35746d37ad2	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
bb352f41-a257-447a-a566-b59da152f493	6589fc5e-b998-43f6-b1c6-0cddbb7f73af	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
f117db75-490f-41ea-a154-3febd03b2eca	6af59927-94ab-413d-b2d1-6fc173656aca	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
335e95d1-3f4b-4c21-a3a7-cc32d0ca307a	6d173ef8-8f2c-49d0-94a6-a7ac6be1a8e0	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
aedd3117-6043-48a3-ac84-901a2c8a1736	6d3712ae-074d-44ad-9815-4c2c667f720d	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
4e5c9d2e-91e9-4a0f-88ee-ee9ae334577a	6fe67340-b48f-48e0-86f9-84d62f68bd08	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
191986cf-1e74-4ab4-a41c-e62ed3fc1cae	702e92bb-32a2-4426-a5c0-47c0b95a0a0c	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
6691437e-5596-4c4b-a252-64546cbd737d	70feded2-98f2-483f-a56f-e74a33e05752	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
7bf74d38-e77d-48cc-b4da-1174cf24f06b	7318e5fd-f32c-47f0-bbbe-cdaeef268ff0	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
353ac8ce-a5b0-433f-91c0-c3667eec33e5	74149353-981c-4862-8b0c-0ae0ddf5b2d9	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
b16f5766-062e-4ffc-80c5-8e5a256f4605	745017df-0b22-41b1-bcdb-8ac6bc92a7c5	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
0e521be2-bcc7-4c9e-8150-6b85e3689713	74577f33-d5a1-46a8-a5d7-fdbac56718d7	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
6de2ccb3-b0c7-49a6-a267-99a01a7add35	758d9e7d-469b-4f37-a796-7561858f5c18	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
e0556cd8-e9ff-45a9-b43d-2075edde56d4	7ad8918b-f750-44f1-9c17-f8b101f9d826	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
4d96a9c4-41ba-4862-a5dc-26050cf1e69e	7bcc6880-0a24-4836-9190-077734a05bba	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
acc58f5d-7212-47cd-b12f-28c25b105420	8053fd6c-fa8b-46c0-80ed-085283b90eec	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
855c42fc-c504-4980-920c-e93889485896	834bdeba-60ea-42eb-a194-88d8f0f9d776	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
149e63c2-90ff-4c00-91b3-bfd5b0f75ab8	864977ce-f74b-409d-8158-763ec40e6919	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
d84cbb2f-c545-4f85-9394-ba2ead4ccdd6	8778e261-6cf1-4428-8f91-1594b89a93c8	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
cff3bbe5-43b4-40e4-8986-2dddd9795df8	88de853a-2cd3-443d-802c-8e410899fa01	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
a4bdf74c-25c3-492c-bfd1-57527bb301f3	8b0a8b68-a2f2-4983-b72c-621f75da48a7	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
98eaebe4-5154-4dd5-83c6-a7f0589a8868	8cbc71a0-5191-4832-abd6-78be7544eb42	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
bcae6457-6d6b-4263-a761-3d83964e09f0	8deb6b3b-4506-4afe-92b8-f0fa2bff8231	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
04db6c02-fbb9-40b0-8230-154cdf60b130	8f1f8e39-770f-47c6-9e7b-ef8c7d04ab1a	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
df9eaed4-be44-4cf6-a177-a9b0dd49d752	9624d78f-c155-4908-a9ee-01f1e54f5ab5	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
ed002155-3235-4495-9744-4947ddb57953	9799c585-9a2b-4a80-ad19-8904771bf758	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
0c6261cf-eddb-400b-a727-1031834cb30d	996ee20a-1f97-4cbf-81e4-af863dfdb336	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
e4b849ea-947f-464d-8b76-a18a930aa92c	99a4df01-2fa1-4714-9cdc-d7b054aef464	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
3aa4c58c-36a7-49c0-a2eb-edd51c88aca7	9ec95932-cd2b-4c41-b052-2156ec454d44	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
246f3e6c-a407-422c-a028-d2ed4ce9a9aa	a5b49aef-9809-4265-ba52-96e3039411bb	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
22d9cae3-faa2-420d-a865-4d5e119fab70	a73d9024-84af-4937-b298-f1a0d948e7ba	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
da0ba084-12d0-4953-9658-851f95342e01	a80393f0-28ae-4960-a134-5f823cc3e520	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
6516ff5a-a0b0-4165-b6ac-e8193c0a031c	a8c9ee29-6ebd-433d-a7e9-e33a32a4a481	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
0b4d9157-6dda-447a-bbdc-0fe245d4d58f	a9e61101-c01f-4fb9-9869-1293646d14ad	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
56c8b5d7-ba33-44c8-8ea7-ffa2e52b7089	b12e0857-a8ae-470e-bb4f-fd2aebb3a5db	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
c7aac79e-081f-41cc-b81b-313966adafc1	b38cf33e-25ec-43da-aa75-ab9480df74ad	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
5319e75e-c738-4caa-ba41-10c5487cf050	b4f61a8a-fed1-47f7-9dd6-5532f064ec96	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
cc05156b-667c-4c91-8715-4c51e9a18575	b86d2e4b-da0b-4286-a274-9cfdc5d7e60a	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
67bf899e-4d5d-4fbc-b63d-c243b914b584	bbff92b1-9293-4cef-bb47-35b0a36e5945	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
0f06a2b3-7a5f-4c34-8d61-a967a548a3ad	bedb6631-8b9a-42e3-853e-15e500cd7435	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
03f9f59e-5ec5-4e4c-886d-0c2fb5e9d55a	c8f76055-fef3-4aac-ac85-8cc72674b157	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
cb47da19-a0e2-43ae-8aab-26b42009b6df	c96dc826-0d5b-4915-9f42-ad4819298201	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
8291a1ba-1f33-4bdf-ba4d-eb620f73925a	c9751178-17c2-47d8-8c75-f84e5e0ac89b	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
b993570d-93ff-4c25-8e9c-479d800ebd21	d06a0ed3-f629-49c5-ba6a-14110212efff	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
06b4db3e-adbf-4ce7-8921-9bb09d79a668	d163e0da-714e-419e-9757-f14c2e2f18a8	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
a2a97b6d-0ddd-46d6-a318-8f4d45120bc4	d1ee8786-5701-4da4-a7f9-5b5809c7b30e	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
9690ecc8-a56f-4dc8-b710-70ca071ff01c	dd2aa615-f230-443d-91b7-8d910f74eaae	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
1ff6939b-c755-491b-a4f4-171a2a85c284	de2eece9-2c1e-4168-80eb-29e1fa596755	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
3ebc044e-e923-4e85-9e1c-2dc7537ad411	e04d944f-65df-4fed-b326-697b50753b12	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
76f7e517-fc0d-46e9-a53c-719d67de94ab	e17eb33b-dcbf-46c4-a713-4a9be7c2af35	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
57eae5e4-e0c1-4951-a1ad-8dd17e652304	ed2b1782-07bd-44e8-8df2-c2fc10b020bd	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
bbd738e2-2c9d-401d-83fb-71902cf73db9	edf0bb4f-39b9-44d8-910e-e9cfbf36ddb1	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
32c01a52-9109-441b-a936-b24cf277af3a	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
c13db6c8-c275-4919-9cdb-f1016654d390	f516b85e-c084-4caf-be52-c413017520ee	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
f61ab322-1061-436d-9a1a-8d0903566021	f5506a34-ab36-44b5-8d4b-3342f503185c	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
a8de0c7e-b92f-4d48-80e6-846c9477a1df	f942823f-e523-4eae-9237-9f22c7f2d02b	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
6f909b8a-5ff3-479b-9fa2-b765bf5285cd	feee1fc0-5a59-446d-a271-0afd19b7be45	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
18fcd4aa-cde2-46c2-812d-84433b44900a	ff51c829-7a78-4eb8-a267-63e6f443d3f6	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
e265dd47-27aa-412f-aa4c-21dbd5c491cb	34b1ca19-a0fe-41ea-9836-3f8620181f97	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
f2477a61-2d24-4ffd-bafa-f18a4581b7b2	35b86aa5-d532-430c-93b2-3fa0bd31ba8f	8e2a7b1c-4d9f-4f3b-b6e5-2a9c5d7e8f02
6595f201-60fb-4735-94d0-43e3e7fd1d40	a15dd1b0-3451-43c3-bc9f-6d50992ca1c9	5c1f6d0a-3b7e-4e0c-9a2d-1f8b4e6c7d01
\.


--
-- Data for Name: ClientUnsubscribes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."ClientUnsubscribes" ("Id", "TherapistId", "ClientId", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: Emails; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Emails" ("Id", "Type", "Subject", "Body", "SentByTherapistId", "RecipientCount", "CreatedAt", "BodyFormat") FROM stdin;
08d89949-d4c5-47a2-a606-648d0b53433b	Admin	How are you finding the BookMyTherapy practice management system?	Thanks again for signing up to BookMyTherapy!\n\nI would love to know how you are getting on with it.  Does it gel with the way you practice? What works well for you? What doesn't work so well? What could be changed to make it better?\n\nWhat new features would you like to see? \nLet me know either by email:\nfeedback@bookmytherapy.co.uk\nor on our Canny board:\nhttps://bookmytherapy.canny.io/\n\nPlease also report any bugs. You can raise a ticket here:\nhttps://bookmytherapy.on.spiceworks.com/\nor report it here. \nhttps://bookmytherapy.canny.io/bugs-reports\n	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	2026-06-06 14:14:44.770142+00	text
5d8cfecc-cd51-4a06-ae49-252874aa7802	Client	just testing	hello	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	2026-06-07 05:46:42.191615+00	text
1814c0b7-f09d-4e32-908e-19b594177e81	Client	Booking issues	Apologies, there have been issues with the booking system.  I have been assured that they have now been resolved.\n\nAny problems please drop me an email and I'll book the sessions for you.\n\nThanks for your patience.\nDebi	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b	5	2026-07-13 18:54:12.609559+00	text
3d7b6593-6dce-4fe1-ab3f-184de959dc72	Admin	Updates to the system	\nHere are the details of some recent updates:\n\n- You can now add breaks as well as client bookings, supervision and intro calls. This is useful for breaks which are one-off - breaks which occur every week are better managed on the Availablity page.\n- 10, 15 and 20 minutes added to session types\n- Indication whether the booking was made by the client or by the therapist\n- The booking confirmation screen shown to the client now includes the therapist name and the date and time of the booking.\n- The therapist’s email address included at the bottom of all emails sent to the client\n- Bug fixes\n\nPlease let me know if you have any suggestions for improving the system.\n\nSupport\nhelp@bookmytherapy.on.spiceworks.com\n·\nHelp Desk\nhttps://bookmytherapy.on.spiceworks.com	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	22	2026-07-18 10:16:47.894989+00	text
a2b5fc07-68a9-493d-a99d-2cfa4c30159e	Admin	Managing Bookings on BookMyTherapy	One of the reasons I created BookMyTherapy was to effectively manage client payments, cancellations and no-shows. Of course, not everyone works in the same way, or has the same frustations. So BookMyTherapy is flexible enough to allow for different ways of booking and getting paid.\n\nPayment in Advance.\n\nEnsuring you receive payment before the session guards against last-minute cancellations and no-shows. You can set this up in Integrations > Non-Payment Policy > Enable non-payment policy.  Enter the number of hours before the session when payment is expected by. If you are renting a room on an ad-hoc basis you may want to set this greater than you rental cancellation notice period. Fill in the policy text which will show up on booking notifications to the client. Good idea also to include it in your client contract.\n\nSelf-booking.\n\nClients can self-book. If you are connected to Stripe payments it will also collect payment. There is a cancellation link on their confirmation email. You can refund them from the Payments page or your Stripe dashboard (link is at the bottom of the BookMyTherapy dashboard.\n\nMaking a booking for your client.\n\nYour client attends a session and you agree on the date of the next session. If so, you can book them in on the Schedule page. If you would like them to confirm then leave the Status at “Pending” and enable  “Ask client to confirm” (this is a new feature) . Once you click the “Book session” at the bottom the client will receive an email giving them options to Confirm or Cancel. The system will update according to their response.\n\nConfirmation does not imply that payment has been received. If you are connected to Stripe and you wish to invoice clients then tick “Enable Stripe Invoicing” on the Integrations page. Select Invoice Due > Before Session.  Choose the number of days before the session on which the invoice is due (this will be reflected on the invoice).  There is also an option to add a memo on the invoice.\n\nWhen creating a booking on the Schedule page and you wish to invoice the client enable “Create and send Stripe invoice to client”. Once the invoice has been paid the system will update to “Paid”. You can also manually select “Paid” (the client has sent funds to your bank account, for example). \n\nPayment after the session.\n\nYou may prefer to invoice the client after the session. In that case tick “Enable Stripe Invoicing” on the Integrations page. Select Invoice Due > After Session. Enter the number of days after the session in which the invoice is due. \n\nAn alternative is to use the Send Invoice button on the Payments page. You can also refund them here as well. \n\nWhether you choose to send invoices before or after the session, you have the option to send reminders - these can be - on due date, a number of days before due date, or a number of days after due date.\n\nI hope this helps. Please contact me if you have any questions / things not working / have a suggestion.	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	20	2026-07-22 11:30:43.686735+00	text
1b53be21-9676-4185-9f6e-476ce7659d63	Admin	How is it going?	Thanks again for signing up to BookMyTherapy!\n\nI've noticed that although you have completed (or nearly completed) setting up ready for accepting bookings, you haven't used it as yet.  To help me gain a better understanding I would be really appreciative if you could complete this feedback form. Just 3 short questions!\n\n{{FEEDBACK_LINKS}}	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	2026-07-27 19:57:41.458676+00	text
c290f721-f24a-4d02-9232-53bd16bdfc12	Admin	No recent activity	II noticed you haven't taken your first booking yet. Would you mind telling me why? Three quick questions:\n\n{{FEEDBACK_LINKS}}	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	2026-07-27 20:06:42.567441+00	text
aeb56644-bac2-498c-be13-7fa52c911e3c	Admin	No recent activity on your account	II noticed you haven't taken your first booking yet. Would you mind telling me why? Three quick questions:\n\n{{FEEDBACK_LINKS}}	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	2026-07-27 20:07:38.533728+00	text
ca6fb042-f2a5-4db5-8fa0-474174e2151b	Admin	Noticed no recent activity on your account	I've noticed you haven't taken your first booking yet. Would you mind telling me why? Three quick questions:\n\n{{FEEDBACK_LINKS}}	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	2026-07-27 20:08:48.524997+00	text
500925bc-f27d-4d4f-9a98-53a0e0227a7f	Admin	Noticed no recent activity on your account	I've noticed you haven't taken your first booking yet. Would you mind telling me why? Three quick questions:\n\n{{FEEDBACK_LINKS}}	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	16	2026-07-27 20:10:04.609242+00	text
11a460cd-dcb5-41ea-b0f3-0bab1bc8a89d	Admin	New feature - Booking Availability	Each of your session types now has a Booking Availability setting, found in the session type editor on the Session Types page. Choose Any client (the default — no change from how things work today), New clients only, or Existing clients only, and that session type will only be offered to the right people.\n\nIt applies everywhere: on your public booking page, clients only see the types they're eligible for, and when you add a booking yourself from your schedule, the session type list narrows once you've chosen the client. A client counts as existing once they've attended at least one session with you — either a confirmed session that has already taken place, or previous sessions you've recorded on their client record. This is handy for things like an intro call you only want new enquiries to book, or a discounted block you reserve for people already in your care. \n\nIf someone who's booked with you before tries to book a new-clients-only session on your public page, they'll be recognised from their email address and shown the right options instead — they won't be able to slip through, and they won't have to start over.\n\nIf you add additional Session Types don't forget to check when they are available to your clients. You can now add multiple session types to each availabilty period. Find this on the Availability page. \n	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	19	2026-08-11 08:08:07.059634+00	text
e77b7d20-ea5a-45cb-a9a2-867883cff44d	Admin	A quick update on BookMyTherapy (and no rush on your end)	\nThanks again for getting back to me a while ago — it's genuinely useful to hear where people are at, even (especially) when the answer is "not yet."\n\nI wanted to give you a quick heads-up on a change I'm making. I'm simplifying BookMyTherapy's pricing: instead of a separate free plan and paid plan, everyone now gets full access to the whole platform for 28 days when they start a trial, so you can properly try it out before deciding anything.\n\nSince you mentioned you're not quite ready to start taking bookings through it yet, there's nothing you need to do right now, and no clock is running on your account. When you do want to get set up, just log in and click "Start 28-day trial of Pro features" from your dashboard — that switches on full access for four weeks. And if the 28 days runs out before you've decided whether to continue, you won't lose your account or your data — it just settles into a lighter free version until you're ready to subscribe or start another trial.\n\nIf it'd help to have a quick look now anyway — even just to see whether it'd fit how you work once you're up and running — I'm happy to walk you through it, no pressure either way. Just reply and let me know.\n\nWishing you well with getting the practice off the ground.\n	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	1	2026-08-25 14:33:50.142252+00	text
054bb51b-9127-45af-b5f9-c6961db7d404	Admin	BookMyTherapy — a new way to try the full version	I wanted to let you know about a change to BookMyTherapy. I'm moving away from a separate paid tier you'd have to commit to upfront, and instead giving everyone the option to try full access to the whole platform — scheduling, payments, calendar sync, the lot — with a 28-day free trial.\n\nYour account isn't changing because of this — you'll stay on the same free plan you're on today either way. But if you'd like to properly put BookMyTherapy through its paces, log in and click "Start my 28-day trial" on your dashboard. That's the only step. If the 28 days pass and you decide it's not for you right now, you'll simply land back on the free plan you already have — nothing is removed, and nothing is charged unless you choose to subscribe.\n\nIf you signed up but haven't had a chance to look at it yet, or if something wasn't clear when you first tried it, I'd genuinely like to know — just reply to this email. I read every one myself, and it helps me make the product better for the next counsellor who signs up.\n\nThanks for giving BookMyTherapy a look in the first place.	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	16	2026-08-25 14:49:52.290227+00	text
1786be6f-d73b-484e-a39d-b305da578ed5	Admin	New in BookMyTherapy: Monthly accounting views	See the money side of your practice without exporting anything into a spreadsheet - we've added an Accounting page to BookMyTherapy. \n\nWhat it shows:\n\nPick a month and you get four views of it:\n\n• No of sessions — sessions you actually delivered, by session date\n• Invoiced — what you billed, by invoice date\n• Paid — what came in, by payment date\n• Outstanding — what was still owed at the end of that month\n\nEach tab breaks down by client, and clicking a client opens every booking behind their total, with invoice numbers and the date each invoice was paid, even if the payment landed in a different month. Underneath, a six-month chart shows the trend for whichever tab you're on.\n\nYou can go back two years, and filter any month by session type — useful if you want supervision or couples work counted separately.\n\nYou'll find it in the sidebar just below Payments. This is a Pro feature - also available on the free 28-day trial. \n\nAs always, just reply to this email if something looks wrong or you want a figure you can't see yet.\n	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	19	2026-08-29 13:13:40.827419+00	text
\.


--
-- Data for Name: Enquiries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Enquiries" ("Id", "ClientId", "Details", "EnquiryOrigin", "CreatedAt", "UpdatedAt") FROM stdin;
46d273e6-b819-4eff-95e0-3b99aee01346	2eb0b0fa-3294-4d66-8841-f4d6c7016818	Online. Worried about AirBNB guest so may switch to phone.	CD	2026-05-31 10:47:50.523016+00	\N
6a1f34b3-7487-4b49-b248-45a54345844f	a15dd1b0-3451-43c3-bc9f-6d50992ca1c9	I want to peruse my dreams and goals. But my mind is holding me back. There’s alot of unpack and I need help with it	\N	2026-09-21 19:42:08.678384+00	\N
\.


--
-- Data for Name: Feedbacks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Feedbacks" ("Id", "UserId", "Token", "Question1Answer", "Question2Answer", "Question3Answer", "CompletedAt", "CreatedAt", "Comments") FROM stdin;
88a41746-254f-4d30-bfac-a9df1d0a9970	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	059d4e1f-9c8d-435e-a49b-91255d4da173	\N	\N	\N	\N	2026-07-27 19:57:40.189151+00	\N
55dfac57-85ca-4e96-be54-820c1ce4f3b3	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	46a5f23a-f798-485a-80ed-2a43ff14e750	\N	\N	\N	\N	2026-07-27 20:06:42.171879+00	\N
65e384f5-bab3-4899-a3e2-c7b9d5185f15	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	514092aa-d7d3-478e-8e1a-def3f1a7c943	\N	\N	\N	\N	2026-07-27 20:07:38.20168+00	\N
00b07ff1-111d-490a-a24c-a382eb702a44	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	d55fe6a9-c6fb-4dc8-b3aa-e2d958bfb760	\N	\N	\N	\N	2026-07-27 20:08:48.17014+00	\N
457c02c0-65b7-444a-9375-9179437bb473	7de40fde-1f9a-471a-8d37-e9c04bc79f8e	0e230c1f-de3a-4fbd-a44d-c5b622bfa5a0	\N	\N	\N	\N	2026-07-27 20:09:58.898874+00	\N
f634a647-9a10-4f9b-94cb-b6d8a452624b	47884d7a-9e96-4245-bcec-f5ab308a54f4	f30fa1ef-9cee-49c7-9c50-f3ba66fe9a32	\N	\N	\N	\N	2026-07-27 20:09:59.241689+00	\N
5520cf67-dcfd-423e-9f70-02c4ebaa3264	7f855dc1-2b6d-4c01-ae97-293eaef2837d	1d8bef25-9277-415f-95b5-58fa3acf16a3	\N	\N	\N	\N	2026-07-27 20:09:59.557746+00	\N
a8628a15-69f5-4cd4-8f39-f1acb9f1e7e7	1810faf2-d25b-4e98-ad68-780aef6b823e	6cb27860-f1bb-45be-9c5e-d442895e540c	\N	\N	\N	\N	2026-07-27 20:09:59.896047+00	\N
cbc65cdd-f0f4-419d-b5c1-5589a5323fba	0dacfd12-575a-4c56-bff0-c73fc3f74e20	3382a80b-1d04-404d-9b71-d3f937f9eb0a	\N	\N	\N	\N	2026-07-27 20:10:00.217969+00	\N
d0db9f7b-9c7f-45ef-9852-89f1ca896c4a	434df510-d7ef-4e2c-aead-bfa8af97140d	f03d5ca6-718e-4ab9-8ebb-71acf764198a	\N	\N	\N	\N	2026-07-27 20:10:00.562021+00	\N
0a5a2b69-c245-43bf-995a-5a3a7d3e99ab	415c8847-3da1-4e70-805d-fd13beb95aa9	c4d95000-430d-418c-8315-38ed9c4eb6be	\N	\N	\N	\N	2026-07-27 20:10:00.912238+00	\N
6f69b6e1-04a9-4d8d-bf53-6686b2f6b328	7e2ec244-8fa6-4f98-a72e-82cf1d2eca12	e8d2f3df-fb16-4b25-a082-8c15b453395a	\N	\N	\N	\N	2026-07-27 20:10:01.384564+00	\N
686573c6-ad13-42b5-9a84-d3461f4f6a17	bd48e910-a161-46b2-9204-8346500fd85e	b8b51b41-6b99-474b-8267-5573252386bf	\N	\N	\N	\N	2026-07-27 20:10:01.704165+00	\N
15fa31d5-f803-4e75-89a7-6c6710ea00d4	ba74c380-d26a-438d-962f-65c1425cde6f	1a6e2706-b204-400a-9727-1b61547bf8be	\N	\N	\N	\N	2026-07-27 20:10:02.014084+00	\N
2af529ae-c475-4f3e-9f6b-3b30f3f28f6d	5bc2515e-19e0-480f-b1a6-8b4f9d51fdf9	7107f857-bf62-48af-9f8f-8210a159f4d9	\N	\N	\N	\N	2026-07-27 20:10:02.338661+00	\N
9a717614-c46b-4cd3-8048-7059a61abe53	ccac4768-056c-468f-b179-770f4a8c6d8b	ae467a17-b05c-4cf9-9632-4f581aa74ae7	\N	\N	\N	\N	2026-07-27 20:10:03.009677+00	\N
dd5d53b3-97e4-45a5-8d36-bebb6d1f2264	8106bfc7-b15a-4a05-aa40-f214bf7ebb77	fcd1ff81-ed2e-4f9a-b1ca-bb148ec361ed	\N	\N	\N	\N	2026-07-27 20:10:03.317618+00	\N
9296a754-dd55-4318-bc88-2b4aaf9268c8	95aca459-bc65-4a3a-8b0c-8440c2de2b87	3373237b-bb96-48fd-a1ab-2a900f0d76bc	\N	\N	\N	\N	2026-07-27 20:10:03.619796+00	\N
607d4f02-7776-4e3c-a444-4c54062b8405	d2ec7542-c806-44f7-87a0-626bbf61a8d8	ea553268-35bb-48e7-a694-7392b389248f	\N	\N	\N	\N	2026-07-27 20:10:04.268898+00	\N
f45afe6f-8da8-4551-971a-681ed15ce1d9	9ab24c5a-5210-4342-ab21-472b1a091f10	b3c96a77-6b98-41c1-afcc-051084572656	no_time	nothing	maybe_later	2026-07-27 20:44:21.468692+00	2026-07-27 20:10:03.936287+00	\N
\.


--
-- Data for Name: HelpQuestions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."HelpQuestions" ("Id", "Section", "SectionOrder", "Slug", "QuestionText", "SortOrder") FROM stdin;
0ca3d189-85c4-46a8-9af9-24cf9158c2a8	Session Types	3	st-video	How do I add a default video call link for a session type?	3
0e2b3208-c128-43d8-b35a-01b168c73d1d	Schedule	5	sc-create	How do I create a booking manually?	2
0eb68c47-6138-4327-8dd1-b548d0bae801	Clients	6	cl-history	Where can I see a client's session history?	3
0f45e59c-fb34-47ea-a027-00eaddd690a6	Plan & Billing	11	pb-trial	How does the free trial work?	3
1552e730-6521-49ed-9de9-901e66760f9e	Getting Started	1	gs-wizard	What is the getting-started wizard?	1
1bf14017-f2c5-4a58-acb6-ea5fb8492c61	Public Booking Page	8	bp-portal	What is the Client Portal?	4
216a787d-d686-484c-813d-5d8770e9aa1c	Clients	6	cl-fee	How do I set a negotiated fee for a client?	2
45394593-e807-42d2-a970-6cfcce6aff3a	Schedule	5	sc-supervision	What is a supervision booking?	4
4eb776a1-8b8d-4a10-8163-9a8d01d805e7	Settings	9	se-frame	What is the therapeutic frame?	3
4ed01a47-8a17-4e41-af53-b1c6ecbab9d3	Getting Started	1	gs-password	How do I reset my password?	4
505fbe45-fbab-4f24-aa57-ccd04212a738	Session Types	3	st-hide	Can I hide a session type from clients?	2
59ce7bc8-5366-433b-879e-b1f02be77fd6	Schedule	5	sc-edit	How do I edit or cancel a booking?	3
67909065-a3d2-48e6-b6f4-6fe5a7f5adc3	Getting Started	1	gs-plans	What's the difference between Free and Pro?	2
68f8e435-1858-49ea-830b-dc5805a6b03b	Payments	7	py-statuses	What do the payment statuses mean?	1
6ec1b3c3-09dd-4841-ba82-8d5a3fa97d08	Dashboard	2	db-quickbook	How do I create a quick booking from the dashboard?	3
70ce3beb-7b06-496b-b4fb-d6b9f485f839	Availability	4	av-weekly	How do I set my weekly availability?	1
734fea58-df47-4851-9607-1d44bce9427d	Clients	6	cl-add	How do I add a new client?	1
7b3877a5-4230-4fe7-97f1-1d1b4a5dca4f	Dashboard	2	db-clinical	What are “clinical hours”?	2
84011da2-1187-4fed-a4cc-422dd7133f1f	Integrations	10	in-stripe	How do I set up Stripe to accept client payments?	2
85e87af7-55bd-4641-8db6-8fef5ebb609c	Payments	7	py-invoice	How do I send an invoice?	2
8fc52e86-520d-4d6f-8f5f-3602dc4c4644	Dashboard	2	db-badges	What are gap and review badges?	4
935c0f68-a321-4ecc-b563-c46116de159b	Payments	7	py-nonpayment	How does the non-payment policy work?	3
97e17adb-21fc-4b20-8d5c-3687d2d6496a	Public Booking Page	8	bp-flow	What does the client see when they book?	2
a21658e5-2dd9-40ee-ba18-9f774117a199	Plan & Billing	11	pb-manage	How do I manage or cancel my subscription?	2
a46f3986-ca16-44fb-a1fd-0597611ce121	Schedule	5	sc-nav	How do I navigate the schedule?	1
a5d9d8c0-5594-45ff-ae9a-56b17f87aba8	Plan & Billing	11	pb-pro	What extra features does Pro include?	1
aa18ae24-860a-4ffd-ac97-6592a7b57de0	Public Booking Page	8	bp-cancel	How can a client cancel their booking?	3
afff1f33-1a41-44c1-909a-30a462c115d4	Integrations	10	in-gcal	How do I sync with Google Calendar?	1
b6180236-9296-4e5a-92e5-89304873e32f	Session Types	3	st-order	How do I reorder session types?	4
b95da80a-7f09-404f-8885-3157e4f51235	Availability	4	av-block	How do I block dates for holidays or breaks?	2
bbf73f58-90c5-4abb-8ebb-636cea4ee808	Availability	4	av-windows	What do the booking window settings do?	3
c43e052b-e929-411c-a9fd-c73e7f834cc1	Session Types	3	st-create	How do I create a session type?	1
cef86db3-70e3-4290-a899-cbb875b9b927	Settings	9	se-reminders	How do session reminders work?	2
d83f8533-1d7a-4d4b-be7a-59bdb03c74c6	Dashboard	2	db-stats	What do the stats cards show?	1
e1ca275f-6d7a-4e06-bb16-49bedb37c88c	Settings	9	se-cancel	What is the cancellation policy setting?	1
e6611880-1eb2-4fc1-841d-90face5cd67f	Public Booking Page	8	bp-link	What is my booking link?	1
f5b30abe-2eac-4612-b1e1-4b0a6c91255b	Getting Started	1	gs-upgrade	How do I upgrade to Pro?	3
\.


--
-- Data for Name: HelpAnswers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."HelpAnswers" ("Id", "QuestionId", "Content", "SortOrder") FROM stdin;
00fa321e-df05-4ad2-8f33-3ff50bd5f660	c43e052b-e929-411c-a9fd-c73e7f834cc1	Go to <strong>Session Types</strong> in the sidebar and click <strong>Add session type</strong>. Give it a name, set the duration (in minutes), buffer time after each session, and your standard fee. You can also pick a colour to distinguish it on the schedule grid.	1
136f228c-8a98-4ac9-a7ce-d8a4e726758e	e1ca275f-6d7a-4e06-bb16-49bedb37c88c	Under <strong>Settings → Cancellation policy</strong> you set how much notice a client must give to receive a full refund (e.g. 48 hours). You can also enter a text description of your policy that is shown to clients on the booking page before they pay. Cancellations within the notice period are not automatically refunded — you manage refunds manually via Stripe.	1
162f8e96-7264-4ed5-b03a-180228bda870	935c0f68-a321-4ecc-b563-c46116de159b	Configure it under <strong>Settings → Non-payment policy</strong>. You set a number of hours after which an unpaid booking can be flagged or automatically cancelled. When an overdue booking is detected it is highlighted on the Payments page with an alert. If <strong>Auto-cancel unpaid bookings</strong> is enabled, the booking status changes to Cancelled automatically and the client receives a notification.	1
1734afbd-1683-47ba-87d2-f6ed9f046ec7	f5b30abe-2eac-4612-b1e1-4b0a6c91255b	Click <strong>⬆ Upgrade to Pro</strong> in the sidebar footer, or navigate to <strong>/upgrade</strong>. You'll see the pricing options and can subscribe via Stripe. A free trial period may be available — the trial end date is shown on the account page once you subscribe.	1
24c4d7c5-f4d0-4997-a484-ee7abfb82234	4ed01a47-8a17-4e41-af53-b1c6ecbab9d3	On the login page, click <strong>Forgot password?</strong> and enter your email address. You'll receive a reset link. Follow the link and choose a new password. The link expires after a short period — request a new one if it has expired.	1
27e1a1e3-33f1-4bf7-a6e7-70f2149ffe49	734fea58-df47-4851-9607-1d44bce9427d	Go to <strong>Clients</strong> and click <strong>Add client</strong>. Enter the client's name and email address — these are the minimum required fields. You can also add phone number, notes, a preferred session type, and set a negotiated fee at this point or later.	1
302a3340-8318-4890-b9df-339d09200988	afff1f33-1a41-44c1-909a-30a462c115d4	Go to <strong>Integrations</strong> and click <strong>Connect Google Calendar</strong>. You will be redirected to Google to authorise access. Once connected, confirmed bookings are automatically added to your Google Calendar and cancellations remove the event. Existing bookings are not back-synced. Google Calendar sync is a <strong>Pro plan</strong> feature.	1
3662d79c-a8c0-4287-ac79-05ec54122252	97e17adb-21fc-4b20-8d5c-3687d2d6496a	The client selects a session type, picks an available date and time, enters their name and email, and pays by card via Stripe. They receive a confirmation email with the session details, a calendar invite, and a cancellation link. Returning clients who sign in via the Client Portal see their previously used email pre-filled.	1
3729e533-e73b-4d23-a0d0-97e37d3fc3dd	59ce7bc8-5366-433b-879e-b1f02be77fd6	Click an existing booking on the grid to open the booking detail drawer. From there you can update the session notes, video link, or status. To cancel, click <strong>Cancel booking</strong> — you will be asked to confirm. If a Stripe payment was taken, a refund option will be shown.	1
39bae4f7-ebc5-47ed-9fc1-c15d190aea22	68f8e435-1858-49ea-830b-dc5805a6b03b	<ul><li><strong>Pending</strong> — booking confirmed, payment not yet collected.</li><li><strong>Paid</strong> — card payment or invoice paid in full.</li><li><strong>Outstanding</strong> — invoice sent but not yet paid, or overdue.</li><li><strong>Advance</strong> — payment collected before the session took place.</li><li><strong>Cancelled</strong> — booking was cancelled (with or without refund).</li></ul>	1
3c98df76-71e3-49ab-b07a-aca082729598	b6180236-9296-4e5a-92e5-89304873e32f	Use the drag handle (⠇) on the left of each row to drag session types into your preferred order. The order is reflected on your public booking page.	1
3cc8a99f-cd88-4cbf-bf5f-e3f7c432487d	0eb68c47-6138-4327-8dd1-b548d0bae801	Click the client's name in the Clients list to open their record. The <strong>Session history</strong> tab shows all confirmed and past sessions with dates, duration, and payment status. You can also view a count of attended sessions and the date of their last session. The <strong>Client logs</strong> page provides a fuller searchable view across all clients.	1
3d0cb150-7f99-473a-941b-02bd1558d643	d83f8533-1d7a-4d4b-be7a-59bdb03c74c6	The dashboard shows your running totals for the current month: confirmed sessions, revenue collected, and hours worked. It also shows a <strong>Today's sessions</strong> panel listing any bookings for the current day and a quick-action button to create a new booking.	1
3d9f4238-9c70-4156-ab71-f7dd0d208a5e	a21658e5-2dd9-40ee-ba18-9f774117a199	Click your name in the sidebar footer to open <strong>My Account</strong>, then click <strong>Manage subscription</strong>. This opens the Stripe Billing Portal where you can view invoices, update your payment method, or cancel your subscription. On cancellation, Pro features remain active until the end of the current billing period.	1
3fc0e0a4-eaa6-4212-8ef5-bf584eb55863	216a787d-d686-484c-813d-5d8770e9aa1c	Open the client record and edit their <strong>Fee</strong> field. When this is set it overrides the session type's standard fee for all new bookings with that client. This is a <strong>Pro plan</strong> feature. The negotiated fee is pre-filled when you create a booking for the client from the schedule.	1
41ad3ed2-de9f-425a-9daf-b719c89ad03b	84011da2-1187-4fed-a4cc-422dd7133f1f	Go to <strong>Integrations → Stripe payments</strong> and click <strong>Connect Stripe</strong>. You'll be taken through Stripe's onboarding to create or connect your account. Once fully verified (<em>Active</em> status), client card payments are deposited directly into your bank account by Stripe. This is separate from the platform subscription (Pro plan billing) and is a <strong>Pro plan</strong> feature.	1
45a43ea1-284a-4e63-98b0-ace2912ddaa9	a46f3986-ca16-44fb-a1fd-0597611ce121	Use the <strong>← Previous</strong> and <strong>Next →</strong> buttons to move week by week, or click <strong>Today</strong> to jump back to the current week. The schedule shows a 7-day grid with your availability hours highlighted. Click any slot to create a booking.	1
494b4921-4f34-4e04-9d23-6ca9350449d5	45394593-e807-42d2-a970-6cfcce6aff3a	Supervision bookings track your clinical supervision sessions separately from client sessions. They appear on the schedule grid in a different colour and are counted in your supervision hours totals on the dashboard. Supervision logs are a <strong>Pro plan</strong> feature.	1
4bb62a5a-bedf-4e89-9596-bb134760f954	aa18ae24-860a-4ffd-ac97-6592a7b57de0	Every confirmation email contains a <strong>Cancel this booking</strong> link. Clicking it takes the client to a cancellation page where they can confirm. Whether a refund is issued depends on your cancellation policy (configured under <strong>Settings → Cancellation policy</strong>). You also receive an email notification when a client cancels.	1
594adbea-f882-4ac3-87c9-84734f29c1b7	0e2b3208-c128-43d8-b35a-01b168c73d1d	Click an empty slot on the schedule grid. A drawer opens where you can select the client, session type, and optionally override the fee or add a video call link. Manually created bookings are set to <em>Confirmed</em> immediately — no payment is taken.	1
5ed39297-8ff3-4362-b0cc-1ec5d4037747	cef86db3-70e3-4290-a899-cbb875b9b927	Enable reminders under <strong>Settings → Reminders</strong> and choose how far in advance the reminder is sent (e.g. 24 hours before). The reminder email is sent automatically to the client and includes the session time, video link (if applicable), and a cancellation link. Reminders are sent for Confirmed bookings only.	1
6a3a423e-2883-41f1-bbca-f65380dc2411	0ca3d189-85c4-46a8-9af9-24cf9158c2a8	Edit the session type and enter your video URL (Zoom, Teams, Google Meet, etc.) in the <strong>Video call link</strong> field. This link is included automatically in confirmation emails for any booking of that session type. You can also override the link on individual bookings.	1
81554290-7318-48c1-b1dc-0a6e37ed71ba	70ce3beb-7b06-496b-b4fb-d6b9f485f839	Go to <strong>Availability</strong> and add rules for each day you work. For each day, set a start time and end time. You can add multiple blocks per day (e.g. morning and afternoon). Slots outside these windows will not appear on your booking page.	1
8ec0d649-ee03-45fd-bd1d-0fc88465e48b	67909065-a3d2-48e6-b6f4-6fe5a7f5adc3	The <strong>Free plan</strong> gives you unlimited clients, bookings, and access to the public booking page with card payments.<br><br>The <strong>Pro plan</strong> adds: Google Calendar sync, supervision logs, negotiated per-client fees, multiple session types, Stripe Connect (direct client payments to your bank account), invoicing, non-payment policy enforcement, and detailed client history badges. Look for the lock icon (🔒) next to any feature that requires Pro.	1
8f05609b-f016-45bb-87fc-cb4749a6aad9	a5d9d8c0-5594-45ff-ae9a-56b17f87aba8	Pro adds: Google Calendar sync, supervision logs and hours tracking, negotiated per-client fees, Stripe Connect (direct bank payments), invoicing, non-payment policy enforcement, multiple session type management, and full client history with session count badges.	1
8f3c8753-9528-4b9c-a85d-7574373eece2	bbf73f58-90c5-4abb-8ebb-636cea4ee808	Found under <strong>Settings → Booking windows</strong>:<ul><li><strong>Minimum notice</strong> — how far in advance a client must book (e.g. 24 hours). Slots sooner than this will not be shown.</li><li><strong>Maximum advance</strong> — how far ahead clients can book (e.g. 8 weeks). Slots beyond this window will not be shown.</li></ul>	1
91001d33-c50b-461a-b823-8e3421d02b9c	e6611880-1eb2-4fc1-841d-90face5cd67f	Your public booking page is at <strong>bookmytherapy.co.uk/book/[your-slug]</strong>. Your slug is based on your name and is shown in the <strong>Integrations</strong> page. Share this link with prospective clients so they can book and pay online without you needing to be involved.	1
9f31d4d6-6cb0-4e5f-98f6-b7b3692e9812	b95da80a-7f09-404f-8885-3157e4f51235	In the <strong>Availability</strong> page, use the <strong>Blocked dates</strong> section to add date ranges you are unavailable. Clients will not be shown any slots during blocked periods. Existing bookings are not automatically cancelled — you will need to contact those clients separately.	1
a4bd3749-8432-442a-a2b3-08a194235c96	8fc52e86-520d-4d6f-8f5f-3602dc4c4644	Gap badges flag clients who have not had a session for more than the number of weeks you configure under <strong>Settings → Therapeutic frame</strong>. Review badges appear when a client has had the number of sessions you set for a periodic review. Both are visible on the Clients list and help you keep track of your caseload.	1
c06307f1-20fd-4185-a19a-b4d522de531a	1552e730-6521-49ed-9de9-901e66760f9e	When you first log in, a four-step wizard walks you through setting up your practice: accepting terms, adding your practice details and bio, entering your professional information, and configuring your booking preferences. Once all steps are complete the wizard is dismissed and you reach the main dashboard. You can return to it at any time via the <strong>Get started</strong> sidebar item.	1
c7ad6c6b-3af0-4761-a682-dde6a2991987	6ec1b3c3-09dd-4841-ba82-8d5a3fa97d08	Click the <strong>New booking</strong> button in the dashboard header or navigate to the Schedule and click any empty slot. Bookings created from the dashboard go straight to <em>Confirmed</em> status — no payment is required when you create a booking on behalf of a client.	1
d6d444c7-0013-4073-bfcf-f87e30be49a8	4eb776a1-8b8d-4a10-8163-9a8d01d805e7	The therapeutic frame settings (under <strong>Settings → Therapeutic frame</strong>) let you define:<ul><li><strong>Review after N sessions</strong> — a review badge appears on the client record after this many confirmed sessions.</li><li><strong>Flag gap after N weeks</strong> — a gap badge appears if the client hasn't had a session in this many weeks.</li></ul>Both badges are visible on the Clients list to prompt you to follow up.	1
dcbca44a-549c-43c4-9d31-60d27f3f3f33	505fbe45-fbab-4f24-aa57-ccd04212a738	Yes. Edit the session type and toggle <strong>Visible on booking page</strong> off. The session type will no longer appear on your public <strong>/book</strong> page but remains available when you create bookings manually from the schedule.	1
e08557d5-186c-4f91-aa33-965fb8e94c17	0f45e59c-fb34-47ea-a027-00eaddd690a6	When you subscribe to Pro, a free trial period may be offered. During the trial you have full Pro access with no charge. Your card is charged automatically when the trial ends. The trial end date is shown on your <strong>My Account</strong> page. You can cancel before the trial ends with no cost.	1
eb5da0aa-00a5-4400-904e-d565ddb940a8	1bf14017-f2c5-4a58-acb6-ea5fb8492c61	The Client Portal (<strong>/client/book/[slug]</strong>) is a separate booking flow for existing clients. Clients sign in with their email address and, once verified, can book their next session. If you have set a negotiated fee for that client, it is applied automatically. This keeps returning client bookings separate from new enquiries.	1
f75a8918-71de-48c8-a406-fe3d8a12ba9e	85e87af7-55bd-4641-8db6-8fef5ebb609c	Invoicing requires a connected Stripe account (Pro plan). Enable invoicing under <strong>Integrations → Invoicing</strong>. Once enabled, you can send an invoice from the booking detail drawer. Stripe emails the invoice directly to the client and you can track its status on the Payments page.	1
ffa1ada9-a668-4e8a-b082-d8ea7471f05b	7b3877a5-4230-4fe7-97f1-1d1b4a5dca4f	Clinical hours are calculated by dividing total session minutes by 50 (the standard therapy session length), not 60. This matches the way supervision bodies and accreditation organisations count practice hours — one 50-minute session equals 1.0 clinical hour.	1
\.


--
-- Data for Name: IntroCallSettings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."IntroCallSettings" ("TherapistId", "SelfBookingEnabled", "Heading", "Description", "DurationMins", "UpdatedAt", "DefaultVideoUrl", "DefaultDeliveryTypeId") FROM stdin;
\.


--
-- Data for Name: IntroCalls; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."IntroCalls" ("Id", "TherapistId", "Name", "StartTime", "EndTime", "Outcome", "Email", "Phone", "CreatedAt", "UpdatedAt", "GoogleEventId", "ReminderSentAt", "VideoUrl", "ClientId", "DeliveryTypeId") FROM stdin;
055ed16c-8dc0-485d-8e1e-8c0820c92364	47884d7a-9e96-4245-bcec-f5ab308a54f4	Tom	2026-07-29 10:30:00+00	2026-07-29 10:45:00+00	\N	\N	\N	2026-07-27 16:48:03.608929+00	\N	c762qaeue9s2rfjftla81r9hjk	\N	\N	\N	\N
de93f155-a702-4e26-bee1-52d57b4e883e	47884d7a-9e96-4245-bcec-f5ab308a54f4	Becca	2026-06-02 17:00:00+00	2026-06-02 17:20:00+00	Good engagement. I didn't think she was ready to commit. Sent her booking link or said she could email me. Says shes going away next week.	lubrinbecca@gmail.com	0781778150	2026-05-31 10:47:50.523016+00	2026-06-02 20:29:40.385348+00	g2pccj5hr69c21ms48si44eubs	\N	\N	2eb0b0fa-3294-4d66-8841-f4d6c7016818	\N
ddedb503-bfde-4d05-b48c-a02692bb34e9	47884d7a-9e96-4245-bcec-f5ab308a54f4	mawgan	2026-09-21 14:00:00+00	2026-09-21 14:15:00+00	(Actual time 18:30) Dreams of being in the military. Suffers from depression, sometimes thinks about suicide. Lives at home with family. Father would keep him safe in a crisis. Says he would like to book online - maybe Friday at 6:30. Asked if he could come every second week. Prefers private as of NHS army will know about this mental health	mawganluff@8gmail.com	\N	2026-09-21 19:48:19.964147+00	2026-09-21 20:05:43.706933+00	eb4n5in2c6r3vajnohqv2edtb0	\N	\N	a15dd1b0-3451-43c3-bc9f-6d50992ca1c9	c7d2f9b8-6a3e-4b4c-8d7f-1e8a2b3c4d02
3efcf475-a89e-4c70-987e-b97e451fe269	47884d7a-9e96-4245-bcec-f5ab308a54f4	Richard Meier	2026-08-26 16:00:00+00	2026-08-26 16:30:00+00	\N	\N	\N	2026-08-25 13:26:48.60362+00	\N	\N	\N	\N	8f1f8e39-770f-47c6-9e7b-ef8c7d04ab1a	\N
b16cbd2b-56ca-479d-a778-5684be1feb67	47884d7a-9e96-4245-bcec-f5ab308a54f4	Mawgan  Luff	2026-09-21 18:30:00+00	2026-09-21 19:00:00+00	\N	\N	\N	2026-09-19 10:23:13.29203+00	\N	\N	\N	\N	a15dd1b0-3451-43c3-bc9f-6d50992ca1c9	\N
\.


--
-- Data for Name: Newsletters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."Newsletters" ("Id", "FirstName", "Email", "ConsentGiven", "ConsentText", "ConfirmToken", "CreatedAt", "EmailConsentGiven", "EmailConsentText", "EmailConsentDateTime") FROM stdin;
1e18f093-fde6-4478-9089-8d54ee8976cc	David	david@davidhoulistoncounselling.com	t	Keep me posted on what BookMyTherapy's building — new features and resources for practitioners, every so often, nothing spammy. I can opt out whenever.	065fd61c-41d1-479c-b83c-074adc33cc3b	2026-09-15 09:35:17.369751+00	f	\N	\N
6f4ccfbd-074f-4419-b244-c2d22e924cae	David web	websites@davidhoulistoncounselling.com	t	Keep me posted on what BookMyTherapy's building — new features and resources for practitioners, every so often, nothing spammy. I can opt out whenever.	35fb26cc-9681-417e-90f8-3b0faa161686	2026-09-15 09:42:01.425695+00	t	Thanks for your interest in BookMyTherapy. Click below to confirm you'd like occasional emails from us.	2026-09-15 09:42:18.007911+00
\.


--
-- Data for Name: PlatformSettings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."PlatformSettings" ("Id", "UpgradeMode", "UpgradeRequestEmail", "ContactEmail", "ContactName", "ProTrialDays") FROM stdin;
1	Stripe	\N	\N	\N	30
\.


--
-- Data for Name: SupervisionBookings; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."SupervisionBookings" ("Id", "TherapistId", "SupervisorName", "StartTime", "EndTime", "Notes", "CreatedAt", "UpdatedAt", "GoogleEventId", "ReminderSentAt", "Format", "NumberInGroup", "SignedBySupervisorAt", "DeliveryTypeId") FROM stdin;
ba593f4e-0613-4bf7-ac2b-5e8472f886b5	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	456	2026-05-10 17:15:00+00	2026-05-10 18:15:00+00	\N	2026-05-10 15:39:55.52569+00	\N	\N	\N	individual	\N	\N	\N
734f7eb5-942f-44bc-83af-12db19210a67	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	dsfdsf	2026-05-13 07:45:00+00	2026-05-13 08:45:00+00	\N	2026-05-11 09:36:18.714652+00	\N	\N	\N	individual	\N	\N	\N
f71a7521-a900-4290-829d-2389548a0334	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	jan	2026-05-14 10:15:00+00	2026-05-14 11:15:00+00	\N	2026-05-12 08:26:49.082497+00	\N	\N	\N	individual	\N	\N	\N
1b09dd93-d87e-4267-9469-722c36a7b644	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	sally	2026-05-27 12:15:00+00	2026-05-27 13:15:00+00	\N	2026-05-25 11:11:25.359697+00	\N	\N	\N	individual	\N	\N	\N
2ed4a6bf-1f66-4db8-a6b7-9a1fc57733b5	bd48e910-a161-46b2-9204-8346500fd85e	Fred	2026-06-04 12:15:00+00	2026-06-04 13:15:00+00	Bring notes	2026-06-04 08:22:58.782542+00	\N	\N	\N	individual	\N	\N	\N
0bcfbbea-e28d-4f94-8a7f-fce3e6c8224e	bd48e910-a161-46b2-9204-8346500fd85e	Dana	2026-06-22 11:00:00+00	2026-06-22 12:00:00+00	\N	2026-06-20 10:53:58.849037+00	\N	\N	\N	individual	\N	\N	\N
d85d6c8e-979f-478a-b3e2-77857b14e23c	47884d7a-9e96-4245-bcec-f5ab308a54f4	Zola	2026-08-19 11:00:00+00	2026-08-19 12:30:00+00	\N	2026-08-19 07:49:38.783334+00	\N	i6krm3iqo6d12j34oqk21upggg	2026-08-19 07:53:46.27011+00	individual	\N	\N	\N
b125b77a-6e3d-4b27-a592-9e4986db6a4b	3f615b21-f9ca-4473-b8b2-0aaf471fb45d	Zola	2026-09-17 13:00:00+00	2026-09-17 14:30:00+00	\N	2026-09-16 13:00:24.157915+00	\N	\N	\N	individual	\N	\N	\N
8fb71cf8-5d75-462c-ac8f-19f2d7585195	47884d7a-9e96-4245-bcec-f5ab308a54f4	Zola	2026-07-15 11:00:00+00	2026-07-15 12:00:00+00	\N	2026-06-10 08:23:41.783743+00	\N	9cs2dfpdjiklginqdcsie2skm8	2026-07-06 11:00:24.129597+00	individual	\N	2026-09-19 14:35:09.531427+00	\N
f9aefa73-1318-40b1-bb3d-228ec39b0f75	47884d7a-9e96-4245-bcec-f5ab308a54f4	Zola	2026-06-09 11:00:00+00	2026-06-09 12:30:00+00	£30	2026-05-31 10:22:28.863765+00	\N	gb76749svctpj1tmepp2p8i79k	2026-06-08 11:01:11.099235+00	individual	\N	2026-09-19 14:35:15.081087+00	\N
bbc7cd5e-b357-404e-8c14-cd086a01eb30	47884d7a-9e96-4245-bcec-f5ab308a54f4	Zola	2026-05-29 11:00:00+00	2026-05-29 12:00:00+00	\N	2026-05-26 11:15:57.860558+00	\N	hvrb0l2mef0unah6g9uddekadc	\N	individual	\N	2026-09-19 14:35:19.936785+00	\N
98f54a6a-e72d-41ae-a0e2-3ae132f04061	47884d7a-9e96-4245-bcec-f5ab308a54f4	Zola	2026-09-17 13:30:00+00	2026-09-17 15:00:00+00	\N	2026-08-19 14:28:06.162689+00	\N	pulregmmjqhqgkq8ontgcm82jk	2026-09-17 01:33:19.919367+00	individual	\N	\N	d8e3a0c9-7b4f-4c5d-9e8a-2f9b3c4d5e03
870bb133-5662-4f62-aa90-3829081707bf	47884d7a-9e96-4245-bcec-f5ab308a54f4	Zola	2026-10-22 13:30:00+00	2026-10-22 15:00:00+00	Bring previous periods client log and supervision record as well as this one	2026-09-18 07:29:32.645374+00	\N	rfll3fusi5tmr7f8s9n51k8i10	\N	individual	\N	\N	d8e3a0c9-7b4f-4c5d-9e8a-2f9b3c4d5e03
\.


--
-- Data for Name: SupervisionAdditionalNotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."SupervisionAdditionalNotes" ("Id", "TherapistId", "SupervisionBookingId", "NotesCiphertext", "CreatedAt", "UpdatedAt", "NotesFormat") FROM stdin;
e1d0a48e-150c-4993-b64b-05ff8256439d	47884d7a-9e96-4245-bcec-f5ab308a54f4	d85d6c8e-979f-478a-b3e2-77857b14e23c	\\x017d581daedb86a41326ac6fc0b9544383cd631d1e6fb4bf3d4b5e93651a02467e148b88a6ecfdf816777321e539729afdeee94cbf3672736348cd31f3db1fda547cbe9c031b6bc431b85fe0174e0f0d2d9a88f04cfccc94be005b6680d6b786f85f2fd15db2591dcf9cb0a1904b	2026-09-19 14:34:54.48768+00	2026-09-19 14:34:54.48768+00	text
32afe4c1-d118-4e80-9927-2e08e668aefb	47884d7a-9e96-4245-bcec-f5ab308a54f4	8fb71cf8-5d75-462c-ac8f-19f2d7585195	\\x012c3d48cefeb17887206bc920d723dc77951136cba94a9830a5531e683c4967341480b2ca1507ab18270d4fea5b3d2e85b0f1c846969d6d8750eeacea43c44e7a394ba4e4005645bec78db5a5733a4b529066449143365ecc4a3849d602b596115b49f17f94bd162c5bc9e82a0fe8337ff2bd079509087b131572d635ade450be77eebe27d5236292d637753d562c	2026-09-19 14:43:16.620045+00	2026-09-19 14:43:16.620045+00	text
\.


--
-- Data for Name: SupervisionNotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."SupervisionNotes" ("Id", "TherapistId", "SupervisionBookingId", "ClientId", "NotesCiphertext", "CreatedAt", "UpdatedAt", "NotesFormat") FROM stdin;
3a2bd2fa-8c3b-4f3b-99c6-0c9b10251aee	47884d7a-9e96-4245-bcec-f5ab308a54f4	98f54a6a-e72d-41ae-a0e2-3ae132f04061	c9751178-17c2-47d8-8c75-f84e5e0ac89b	\\x015d3eb4d122cf8f627d3a5342df6132f4d52bfde9829e8ca19ddaa74ddee261d45c4e0d170bdb23860df36d77c13afd0b7fe9ca8f026be2d181062df0032bde8982aa948941f4a69fd1d432e0a9dc7d141be62d53a17d995f7a440447c2f738105eaea5d4caf0d55789f57188dbab946e4f54548aae7dc4981ebce30f8467c26c12cc555ebf08984963049778b0c9fde419de43daec8fb56946ab03e55971e5f38abe924fc78ac52b474be081dbc3d0d998dc789ec202dc310da2c804f6e0d6ea5eb9f6568e5ff23f3c4beb275e10f6beaa2a831d86b959b8a785da4bb7ccd93976ce9aeb758609a9930c03cc4b3d2db6848fb238d4ba7d0492266f093727e03351627ae54c337b9003b245eaf6e6ae1063d39812d0fe6b78106275080dac428e4e353c913a186ec3eb1635edd3a5779f0f205d1b96c259ddeb595d65597ea238b98c7feff8177b2c6a1f32392e13c6f4b5fc3a	2026-09-17 20:51:51.130267+00	2026-09-17 20:51:51.130267+00	text
7b43621a-e55e-47dd-86cb-8b434c26f36a	47884d7a-9e96-4245-bcec-f5ab308a54f4	98f54a6a-e72d-41ae-a0e2-3ae132f04061	8b0a8b68-a2f2-4983-b72c-621f75da48a7	\\x01487ae913778f8dcb86c309f36332cd1c73af4f1aa8f6974a1b84f3d8dc3045f690378fefbef94bd4a3757cbe1496b908505a00b7430a7707c6613167b0c5f5aabca16e7fdca83b82b5f17b156ebbd1d2a273d2e158f16cba3ffe2fbeaa190e0eb244b84314188525f49628bd3076c5ac7b32e18c328e46ab243f71b2e04d20db6c055d02133ed9149ead9b7f7891e16da3179d3634c8571eb95a2ed4f4523664ebb0b42f17b0bd2e2ec5a5c4292b84951e6056c55471fe5197a611677e949d6319b86a2931ba263a5a694f57d54625124ada850d92543a70264193239220a6afaf6f3c7c4e151131db506fcde62e3b0a592c96731207	2026-09-17 20:52:18.325878+00	2026-09-17 20:52:18.325878+00	text
1de7c30d-0d37-4815-b01a-c7e400a3cf68	47884d7a-9e96-4245-bcec-f5ab308a54f4	d85d6c8e-979f-478a-b3e2-77857b14e23c	e04d944f-65df-4fed-b326-697b50753b12	\\x0113a7d446da093177473e6c87306670d63a1761e10a52639132ac52b7998136a73de5dda6db03a735e0c8453b29149aec4b9638cc2561054cf6d05edbf787c7eb1ec00c76bb3a01862f068fef322467c06b6bc9c19be1bdb96e3eec	2026-09-19 14:33:32.742807+00	2026-09-19 14:33:32.742807+00	text
62674e12-f016-4f12-a5c3-0421060b7ff9	47884d7a-9e96-4245-bcec-f5ab308a54f4	d85d6c8e-979f-478a-b3e2-77857b14e23c	f3b310f3-b55c-44fc-ba1b-5d5e1970905e	\\x01409d5e2d6b56b20446b7073b18a0d1ec237a180e828093d736c28fd45f9b8c97b8353d22995ec3e082aec53f0906d49c5e2ed3e8298970402695278982fa5ea8b345840eb8da02bb9762ab889d0a3dc478b12cd0507a7d52b68acfc0545cd65e25453575ddb30ec00eeebb518dc9c1ff2f11fce9ce118fb71a1aba2fd6ddc7da5df7d7e38f6b8cb207c5deb7938b0fce005f9a	2026-09-19 14:33:50.620848+00	2026-09-19 14:33:50.620848+00	text
cd8398f9-0448-47cc-b05b-247a72290ec0	47884d7a-9e96-4245-bcec-f5ab308a54f4	d85d6c8e-979f-478a-b3e2-77857b14e23c	0f9a6849-fbe2-4378-b63d-926f489d4377	\\x0123c0be7e916465eae44f2981780d7881ec45917031d2ac5a6154c0ac39b793f76d69267571b12942f70082a51fa5390d085fdfa1f73cb287eb5e39e2cfe18a76b96917d69f06883fe763043741b4a71c49dede61c311ef11cddc935617fdec73b2a2ecaec248dc8bcc241ceda51a2b4ca2c2a9e6fd1c6616bd5c8da705048fe5d250668e6f8cfdf52c353e98ab94ef06719548d40cf0	2026-09-19 14:34:11.195994+00	2026-09-19 14:34:11.195994+00	text
1ab671e9-e7e4-47d1-8049-ae93da3f4140	47884d7a-9e96-4245-bcec-f5ab308a54f4	d85d6c8e-979f-478a-b3e2-77857b14e23c	8b0a8b68-a2f2-4983-b72c-621f75da48a7	\\x0164aa889bec981250865458b4cf13643dbd2f38351838b27ec618daacb549bb591d5d9366d2080f8c94888ee07e8fecac6177fe39acb53c02cd19effa3d33a484b25e4b6363aaad639b7e41928197f24594a0256a5ced45d5390356bad6bb2eb301323a4545e7759570a1cb0086388e5c60015cc5ab93617c1d410b117c39cab6f515903382345312a8	2026-09-19 14:34:28.042451+00	2026-09-19 14:34:28.042451+00	text
87963dc9-d809-4002-9279-842e9e4deb07	47884d7a-9e96-4245-bcec-f5ab308a54f4	8fb71cf8-5d75-462c-ac8f-19f2d7585195	996ee20a-1f97-4cbf-81e4-af863dfdb336	\\x0122b6529c78c4da290ca0895d04972b7ef777f482c3494489c630a0e8090990a4ed77ae2488c6ef11dcb838fbf6d1bc0f6a63485539fb77b8ece51181dec88cb8823c0f5b09c5876c47f8b250	2026-09-19 14:43:40.484112+00	2026-09-19 14:43:40.484112+00	text
b2285979-811d-4543-a414-2db7b27ab5df	47884d7a-9e96-4245-bcec-f5ab308a54f4	8fb71cf8-5d75-462c-ac8f-19f2d7585195	0f9a6849-fbe2-4378-b63d-926f489d4377	\\x01c246598380e2f5c848c06d95a8fde519d6e53cb413cd03ea539a8694b6863f71694d3e9a02f1c9b9abcbf8e7ac0b6224c7431bcd2a7483f5c15a4896ca03af0abbbf94be200b191e056302c9eb8ba03fba4565edd633fd9269d606e81457262b80c29954c7f0da5243d43b89d8ab3284442ef552c15625f62c0824bdfc557ea585e957a6d41128d79154459ed492c57f6399d7f4de7efeb34a549f3dee19f7d4b6837bed9511361772013aebb51bc1	2026-09-19 14:43:59.845071+00	2026-09-19 14:43:59.845071+00	text
83de8128-ea43-47d6-989f-3cc46f45faae	47884d7a-9e96-4245-bcec-f5ab308a54f4	f9aefa73-1318-40b1-bb3d-228ec39b0f75	202f75a9-cd59-412f-83d5-2b8b8868da8a	\\x0184a0c7605bea7a19f8d86c497da94265ee6f6f158ea599c50d2f48570ae04a112d6fa5fe62e0fa428dbb502dc3aa62c26806dad2a9f220df5791d7f7a6a2898624e321aa3b851dd5c15505de086eb3a930e5e33b1724b3b335239ef5a31a6ae74a06275d26c5ccff2d26d0e56bac0ffe58688f0d267b3e5bc901bf9ae202498086b1b345c360d392b913ffbef5c153bdfa6f60cc3aca188a4ce093ec862932ad91d2afd088f9b3943ffb0ca4bc1249039d796a2a1af1fabbc8358def8427e3cf87144d8df1dae93f1e9b828d59e5f3196c28ff466a1e9b14c9ed6eca72a5c2ca1858eec4710d23b541d5fe009d	2026-09-19 14:44:43.869856+00	2026-09-19 14:44:43.869856+00	text
4578ff23-cf9d-4444-b8c0-d226fbaa47fb	47884d7a-9e96-4245-bcec-f5ab308a54f4	f9aefa73-1318-40b1-bb3d-228ec39b0f75	0f9a6849-fbe2-4378-b63d-926f489d4377	\\x013eef676dde3d142e1dd70a267bd42f4c1d968d9b2e3a4c5822290e5f8c4a29bbf3eecc82bd1c5287f4b6c2cfa73c18e20464ae3349a1467c7efa62729832d5e0d5222f24bed794be06ea0df8ac0fb1d2a0606238729ac2fde59be7b5c687efe641e12c32f2f1521f6c67ec91846d83964dc6304faa85887dd8bf48bc3b0dc6fdc817848b15f1	2026-09-19 14:44:58.284925+00	2026-09-19 14:44:58.284925+00	text
\.


--
-- Data for Name: TermsAndConditions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."TermsAndConditions" ("Id", "Version", "Url", "CreatedAt") FROM stdin;
tac-v1	1	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/BookMyTherapy/Terms%20and%20conditions%20ver%201.pdf	2026-05-20 00:00:00+00
tac-v2	2	https://rnvyhdjrkhtmligkyvdk.supabase.co/storage/v1/object/public/BookMyTherapy/Terms%20and%20conditions%20ver%202.pdf	2026-06-07 06:23:48+00
\.


--
-- Data for Name: UserUnsubscribes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."UserUnsubscribes" ("Id", "TherapistId", "CreatedAt") FROM stdin;
14a0dc32-96b7-43b3-9236-07ecb63e0d4f	0dacfd12-575a-4c56-bff0-c73fc3f74e20	2026-07-27 20:10:33.580895+00
\.


--
-- Data for Name: WaitlistEntries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."WaitlistEntries" ("Id", "TherapistId", "ClientName", "ClientEmail", "PreferredDays", "Notes", "CreatedAt") FROM stdin;
\.


--
-- Data for Name: __EFMigrationsHistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "public"."__EFMigrationsHistory" ("MigrationId", "ProductVersion") FROM stdin;
20260414094417_InitialCreate	10.0.5
20260416072407_AddClients	10.0.5
20260418140008_AddSessionTypeConfigs	10.0.5
20260418140900_AddSessionTypeColor	10.0.5
20260418151054_AddSessionTypeBuffer	10.0.5
20260418152302_AddAvailabilityRuleSessionType	10.0.5
20260419102612_AddTherapistBookingWindows	10.0.5
20260419112513_AddCancellationPolicy	10.0.5
20260419115530_AddReminderSettings	10.0.5
20260419120629_AddBookingReminderSentAt	10.0.5
20260419135946_AddBookingIsPaid	10.0.5
20260419153326_AddGoogleCalendarFields	10.0.5
20260420094437_AddSupervisionBookings	10.0.5
20260421073827_AddClientSessionPreferences	10.0.5
20260421112537_AddOpeningHours	10.0.5
20260421141133_AddClientOtpFields	10.0.5
20260422125109_AddCancelNoticeFields	10.0.5
20260422131119_AddTherapeuticFrameSettings	10.0.5
20260429110001_AddTherapistRole	10.0.5
20260501131754_ReplaceSessionTypeWithFK	10.0.5
20260503101749_AddTherapistInvoiceSettings	10.0.5
20260503145502_AddBookingStripeInvoiceId	10.0.5
20260503211251_BlockedDateUseDateOnly	10.0.5
20260504075917_UseInstantDateTimeOffset	10.0.5
20260504093111_NonPaymentPolicy	10.0.5
20260509090550_AddOnlineVideoLinks	10.0.5
20260509125101_AddSessionTypeVideoLink	10.0.5
20260509141801_AddClientVideoLinks	10.0.5
20260509150406_AddBookingVideoCallUrl	10.0.5
20260510081338_SimplifyClientVideoLink	10.0.5
20260512074727_AddClientIdToBookings	10.0.5
20260512081814_NormaliseBookingClientId	10.0.5
20260513064351_AddTherapistSlug	10.0.5
20260513081431_PendingCheck	10.0.5
20260520092223_AddQualificationsAndTermsAccepted	10.0.5
20260520094821_AddProfessionalInfoFields	10.0.5
20260520131241_AddTermsAndConditionsTable	10.0.5
20260520144853_AddTermsAcceptanceAuditFields	10.0.5
20260523140018_AddVideoLinkPerSessionType	10.0.5
20260524134545_AddInvoiceSentAt	10.0.5
20260524141844_AddIsLateCancellation	10.0.5
20260524174917_AddBookingRefundFields	10.0.5
20260525063923_AddBookingInvoiceNumber	10.0.5
20260525071329_AddBookingInvoicePaidAtAndVoided	10.0.5
20260525113339_AddSupervisionGoogleEventId	10.0.5
20260526130002_AddWelcomeEmailSent	10.0.5
20260526140559_AddSessionTypeHideFromClients	10.0.5
20260526161832_AddTherapistPlan	10.0.5
20260527074115_AddSubscriptionIds	10.0.5
20260527075728_AddPlatformSettings	10.0.5
20260528085153_AddTherapistFreeTrialEndsAt	10.0.5
20260528122321_AddContactInfo	10.0.5
20260528152140_AddTherapistPhotoAndLogo	10.0.5
20260529165405_AddHelpContent	10.0.5
20260531083547_AddIntroCalls	10.0.5
20260531103812_AddIntroCallGoogleEventId	10.0.5
20260531110117_AddSupervisionIntroCallReminderSettings	10.0.5
20260606073053_AddClientDoNotEmail	10.0.5
20260606111341_AddEmails	10.0.5
20260606134327_AddUserUnsubscribes	10.0.5
20260606143326_AddClientUnsubscribes	10.0.5
20260608080451_AddSessionTypeIsIntroCall	10.0.5
20260610135439_AddClientPreviousSessions	10.0.5
20260611144357_AddPlatformFreeTrialDays	10.0.5
20260614204804_AddInvoiceReminderSentAt	10.0.5
20260615063508_AddBookingInvoiceDueDate	10.0.5
20260616083248_AddBookingSessionNotes	10.0.5
20260624101153_AddPractitionerVerification	10.0.5
20260625112955_BackfillVerificationForLiveTherapists	10.0.5
20260708102949_AddBookingBookedByAuthId	10.0.5
20260708125232_ReplaceBookedByAuthIdWithBookedBy	10.0.5
20260716162717_AddCalendarPrefs	10.0.5
20260718075348_AddBreaks	10.0.5
20260727101240_AddFeedbackTable	10.0.5
20260727160838_AddCommentsToFeedback	10.0.5
20260727171111_AddUserNameEmailToFeedback	10.0.5
20260727171931_RemoveUserNameEmailFromFeedback	10.0.5
20260810101758_AddSessionTypeBookingAvailability	10.0.5
20260810131741_AddBookingClientTherapistCompositeKey	10.0.5
20260810134106_AddSessionTypeOwnershipConstraints	10.0.5
20260810165934_AddAvailabilitySessionTypes	10.0.5
20260810173358_RemoveAvailabilityRuleSessionAndBufferMins	10.0.5
20260824095858_AddProTrial	10.0.5
20260901104826_AddTherapistSignupAttribution	10.0.5
20260908135924_AddTherapistGridHours	10.0.5
20260911164510_AddBookingClinicalNotesCiphertext	10.0.5
20260915084943_AddNewsletters	10.0.5
20260917084229_AddBookingProcessNotesCiphertext	10.0.5
20260917101854_AddClientIdentifier	10.0.5
20260917164341_AddSupervisionNotes	10.0.5
20260918082144_AddSupervisionFormat	10.0.5
20260918163458_AddSupervisionDelivery	10.0.5
20260919085513_AddSupervisionSignedBySupervisor	10.0.5
20260919140916_AddSupervisionAdditionalNotes	10.0.5
20260919155932_AddClientIdentities	10.0.5
20260919162800_AddClientIdentityPerType	10.0.5
20260920101809_ReplaceSessionTypeIsIntroCallWithIntroCallSettings	10.0.5
20260920134646_AddIntroCallMedium	10.0.5
20260920135746_AddIntroCallSettingsDefaultMedium	10.0.5
20260920150631_MoveIntroCallEnquiryToEnquiries	10.0.5
20260920152540_AddEnquiryUpdatedAt	10.0.5
20260920194911_AddIntroCallClientId	10.0.5
20260921101828_AddEmailBodyFormat	10.0.5
20260921154014_AddNotesFormats	10.0.5
20260922135326_AddDeliveryTypes	10.0.5
20260922165234_AddClientDemographics	10.0.5
\.


--
-- Data for Name: buckets; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets" ("id", "name", "owner", "created_at", "updated_at", "public", "avif_autodetection", "file_size_limit", "allowed_mime_types", "owner_id", "type", "versioning_status", "lifecycle_configuration", "lifecycle_configuration_generation") FROM stdin;
BookMyTherapy	BookMyTherapy	\N	2026-05-13 15:10:18.029344+00	2026-05-13 15:10:18.029344+00	t	f	\N	\N	\N	STANDARD	DISABLED	\N	\N
therapist-assets	therapist-assets	\N	2026-05-28 15:29:03.094032+00	2026-05-28 15:29:03.094032+00	t	f	\N	\N	\N	STANDARD	DISABLED	\N	\N
\.


--
-- Data for Name: buckets_analytics; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_analytics" ("name", "type", "format", "created_at", "updated_at", "id", "deleted_at") FROM stdin;
\.


--
-- Data for Name: buckets_vectors; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."buckets_vectors" ("id", "type", "created_at", "updated_at") FROM stdin;
\.


--
-- Data for Name: objects; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."objects" ("id", "bucket_id", "name", "owner", "created_at", "updated_at", "last_accessed_at", "metadata", "version", "owner_id", "user_metadata", "archived_at", "is_delete_marker", "is_versioned") FROM stdin;
83ff9a1c-74b2-4d72-b70d-e61ea3921dd4	BookMyTherapy	bookmytherapy (1).png	\N	2026-05-13 15:11:08.296079+00	2026-05-13 15:11:08.296079+00	2026-05-13 15:11:08.296079+00	{"eTag": "\\"f7852ac5992be62dd942919d9ccec27a-1\\"", "size": 13283, "mimetype": "image/png", "cacheControl": "max-age=3600", "lastModified": "2026-05-13T15:11:08.000Z", "contentLength": 13283, "httpStatusCode": 200}	9a963116-4839-4a4e-91b6-e5e624eb79a5	\N	\N	\N	f	f
0927b985-a029-4d48-988a-1b7ca31a97e7	BookMyTherapy	Terms and conditions ver 1.pdf	\N	2026-05-20 12:58:15.321426+00	2026-05-20 12:58:15.321426+00	2026-05-20 12:58:15.321426+00	{"eTag": "\\"03742484d812be2d378dd8cb1ca0e2f9-1\\"", "size": 212527, "mimetype": "application/pdf", "cacheControl": "max-age=3600", "lastModified": "2026-05-20T12:58:15.000Z", "contentLength": 212527, "httpStatusCode": 200}	9cb28581-2f0f-49f5-9805-7b23a3ec411e	\N	\N	\N	f	f
4a006d11-8d73-4541-9664-8797a5602cb0	therapist-assets	47884d7a-9e96-4245-bcec-f5ab308a54f4/photo	\N	2026-05-29 16:18:15.977809+00	2026-05-29 16:18:15.977809+00	2026-05-29 16:18:15.977809+00	{"eTag": "\\"bd8f502f4341f8f558cc581d58133f27\\"", "size": 972916, "mimetype": "image/jpeg", "cacheControl": "no-cache", "lastModified": "2026-05-29T16:18:16.000Z", "contentLength": 972916, "httpStatusCode": 200}	35ae8f8d-1767-417a-9192-a21585dd9581	\N	{}	\N	f	f
9723a2af-f2b9-48b8-99a7-5e082d86d84c	therapist-assets	47884d7a-9e96-4245-bcec-f5ab308a54f4/logo	\N	2026-05-29 16:18:38.340188+00	2026-05-29 16:18:38.340188+00	2026-05-29 16:18:38.340188+00	{"eTag": "\\"597daa5efb3c4ef812293cda4f42953a\\"", "size": 40372, "mimetype": "image/png", "cacheControl": "no-cache", "lastModified": "2026-05-29T16:18:39.000Z", "contentLength": 40372, "httpStatusCode": 200}	98cd39da-6790-45be-b0a1-6fd14441baea	\N	{}	\N	f	f
dbd41177-dced-442f-a09d-21dbf956101e	BookMyTherapy	Terms and conditions ver 2.pdf	\N	2026-06-07 06:22:56.398387+00	2026-06-07 06:22:56.398387+00	2026-06-07 06:22:56.398387+00	{"eTag": "\\"592b001eeab86c1d215f95a618244976-1\\"", "size": 253618, "mimetype": "application/pdf", "cacheControl": "max-age=3600", "lastModified": "2026-06-07T06:22:57.000Z", "contentLength": 253618, "httpStatusCode": 200}	d3cca886-0737-4db9-8402-b0f19b3865dd	\N	\N	\N	f	f
ff2d67df-acfa-4af4-8330-345f5ac0cc47	therapist-assets	4e7214dc-b42b-4462-aa74-5026e3b4c8e7/logo	\N	2026-06-09 14:46:14.46722+00	2026-06-09 14:46:14.46722+00	2026-06-09 14:46:14.46722+00	{"eTag": "\\"df6228bcf1369f54cbc3b527a7bdd1d8\\"", "size": 145185, "mimetype": "image/png", "cacheControl": "no-cache", "lastModified": "2026-06-09T14:46:15.000Z", "contentLength": 145185, "httpStatusCode": 200}	19df231e-d6b4-405b-a552-acd424653769	\N	{}	\N	f	f
e49f989b-6a65-49f8-9c37-4a8d45aa95f7	therapist-assets	4e7214dc-b42b-4462-aa74-5026e3b4c8e7/photo	\N	2026-06-09 18:09:56.308064+00	2026-06-09 18:09:56.308064+00	2026-06-09 18:09:56.308064+00	{"eTag": "\\"f03932c47a12f4c74e50084b1dfed406\\"", "size": 345781, "mimetype": "image/jpeg", "cacheControl": "no-cache", "lastModified": "2026-06-09T18:09:57.000Z", "contentLength": 345781, "httpStatusCode": 200}	a130eb02-9796-4af8-90ae-45a7dbc57a3c	\N	{}	\N	f	f
68df3f2c-e1f5-46a5-80ae-2ae8c1b8f43c	therapist-assets	7e2ec244-8fa6-4f98-a72e-82cf1d2eca12/logo	\N	2026-06-23 20:21:42.055224+00	2026-06-23 20:21:42.055224+00	2026-06-23 20:21:42.055224+00	{"eTag": "\\"7647254829c387b98704d443fb5f9c4c\\"", "size": 909803, "mimetype": "image/jpeg", "cacheControl": "no-cache", "lastModified": "2026-06-23T20:21:43.000Z", "contentLength": 909803, "httpStatusCode": 200}	efa9250d-2278-42f2-bc2d-280a5f4921b1	\N	{}	\N	f	f
9932c4b6-edfb-425b-9181-7617c4acd0ea	therapist-assets	482286c0-811a-4819-b38b-5f01a8a35e9a/photo	\N	2026-06-23 21:04:09.328392+00	2026-06-23 21:04:09.328392+00	2026-06-23 21:04:09.328392+00	{"eTag": "\\"ceaf3da87918d46a9da350ae71f6f896\\"", "size": 385210, "mimetype": "image/webp", "cacheControl": "no-cache", "lastModified": "2026-06-23T21:04:10.000Z", "contentLength": 385210, "httpStatusCode": 200}	4f559cc8-44aa-4441-98ba-e83d3085d14f	\N	{}	\N	f	f
1e93318a-d9c3-490c-8148-0042932b067d	therapist-assets	482286c0-811a-4819-b38b-5f01a8a35e9a/logo	\N	2026-06-24 19:50:58.645004+00	2026-06-24 19:50:58.645004+00	2026-06-24 19:50:58.645004+00	{"eTag": "\\"384189df7389119233a1dc4b5d8405f0\\"", "size": 640681, "mimetype": "image/png", "cacheControl": "no-cache", "lastModified": "2026-06-24T19:50:59.000Z", "contentLength": 640681, "httpStatusCode": 200}	41ec5135-0e82-412b-b812-53f893224e50	\N	{}	\N	f	f
fee6a189-06c3-4546-8258-1bcd5f9e066d	therapist-assets	ba74c380-d26a-438d-962f-65c1425cde6f/photo	\N	2026-06-26 20:40:12.783293+00	2026-06-26 20:40:12.783293+00	2026-06-26 20:40:12.783293+00	{"eTag": "\\"4acbfada4f1eb1d843c9cd8f1b4c9e3e\\"", "size": 86170, "mimetype": "image/png", "cacheControl": "no-cache", "lastModified": "2026-06-26T20:40:13.000Z", "contentLength": 86170, "httpStatusCode": 200}	7372399a-d956-403e-8c41-0cc6d5b6e4e1	\N	{}	\N	f	f
41a96005-e6a8-436b-8f35-8dfc83b48c92	therapist-assets	ba74c380-d26a-438d-962f-65c1425cde6f/logo	\N	2026-06-26 20:40:38.406798+00	2026-06-26 20:40:38.406798+00	2026-06-26 20:40:38.406798+00	{"eTag": "\\"224a3993065fe3acd33543e12ab8543f\\"", "size": 755348, "mimetype": "image/png", "cacheControl": "no-cache", "lastModified": "2026-06-26T20:40:39.000Z", "contentLength": 755348, "httpStatusCode": 200}	5f8cde9a-6958-4990-b3f5-95a5ff28e3b2	\N	{}	\N	f	f
9b7699d1-eecd-4c19-8da7-afbf357af2a8	therapist-assets	37a5bf82-e84b-4cb7-b8a4-4e78aed3148b/logo	\N	2026-07-07 12:07:03.971521+00	2026-07-07 12:07:03.971521+00	2026-07-07 12:07:03.971521+00	{"eTag": "\\"914af4b51726e8ce15609885d0057ff1\\"", "size": 56220, "mimetype": "image/webp", "cacheControl": "no-cache", "lastModified": "2026-07-07T12:07:04.000Z", "contentLength": 56220, "httpStatusCode": 200}	3c0b6243-94c4-4e19-a893-48e7544ec712	\N	{}	\N	f	f
\.


--
-- Data for Name: s3_multipart_uploads; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads" ("id", "in_progress_size", "upload_signature", "bucket_id", "key", "version", "owner_id", "created_at", "user_metadata", "metadata") FROM stdin;
\.


--
-- Data for Name: s3_multipart_uploads_parts; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."s3_multipart_uploads_parts" ("id", "upload_id", "size", "part_number", "bucket_id", "key", "etag", "owner_id", "version", "created_at") FROM stdin;
\.


--
-- Data for Name: vector_indexes; Type: TABLE DATA; Schema: storage; Owner: supabase_storage_admin
--

COPY "storage"."vector_indexes" ("id", "name", "bucket_id", "data_type", "dimension", "distance_metric", "metadata_configuration", "created_at", "updated_at") FROM stdin;
\.


--
-- Name: refresh_tokens_id_seq; Type: SEQUENCE SET; Schema: auth; Owner: supabase_auth_admin
--

SELECT pg_catalog.setval('"auth"."refresh_tokens_id_seq"', 1142, true);


--
-- Name: PlatformSettings_Id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('"public"."PlatformSettings_Id_seq"', 1, false);


--
-- PostgreSQL database dump complete
--

-- \unrestrict 41v7YjZQZQZKoQqYkoRv4hgdpn0LxJfTp0vJwQAa6ckJ9rTlI3QwcLCyxqlg6zh

RESET ALL;
